﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

   
    protected void lnkDownload_Click(object sender, EventArgs e)
    {
           try
      {

               Response.ContentType =

"application/vnd.ms-excel";
               string fileName = Server.MapPath("~\\Downloads\\SmashTackerV1.0.zip");  //Give path name\file name.



               Response.AppendHeader("Content-Disposition", "attachment; filename=SmashTackerV1.0.zip"); 

             //Specify the file name which needs to be displayed while prompting

              Response.TransmitFile(fileName);

             Response.End();

       }

       catch (Exception ex)
      {

           

      }
    }
}
