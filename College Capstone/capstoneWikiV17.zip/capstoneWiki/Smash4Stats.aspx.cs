﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Smash4Stats : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ViewStats temp = new ViewStats();


        DataSet ds = temp.SearchSmash4();
        GV.DataSource = ds;
        GV.DataMember = ds.Tables["SSBG4"].ToString();
        GV.DataBind();
    }
}