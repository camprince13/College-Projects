﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Super_Smash_Stat_Tracker
{
    public partial class AddBattleBrawl : Form
    {
        public AddBattleBrawl()
        {
            InitializeComponent();
        }

        public UserName IDBrawl;

        private void AddBattleBrawl_Load(object sender, EventArgs e)
        {
            CreateMyBorderlessWindow();
            MiscFunc.GBSound(5);
            lblUserName.Text = "User ID: " + IDBrawl.StrUserID;
        }

        //################################# Start Player Select ############################################

        private void cbNumberOfPlayers_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbNumberOfPlayers.SelectedIndex == 0)   //################################# 2 Players ############################################
            {
                pnlP4.Visible = false;
                pnlP3.Visible = false;
                pnlP4.Enabled = false;
                pnlP3.Enabled = false;
                pbVS2.Visible = false;
                pbVs3.Visible = false;
                txtP3NumOfKosForP1.Text = "0";
                txtP4NumOfKosForP1.Text = "0";
            }
            else if (cbNumberOfPlayers.SelectedIndex == 1)  //################################# 3 Players ############################################
            {
                pnlP4.Visible = false;
                pnlP3.Visible = true;
                pnlP4.Enabled = false;
                pnlP3.Enabled = true;
                pbVS2.Visible = true;
                pbVs3.Visible = false;
                txtP4NumOfKosForP1.Text = "0";
            }
            else if (cbNumberOfPlayers.SelectedIndex == 2)  //################################# 4 Players ############################################
            {
                pnlP4.Visible = true;
                pnlP3.Visible = true;
                pnlP4.Enabled = true;
                pnlP3.Enabled = true;
                pbVS2.Visible = true;
                pbVs3.Visible = true;
            }
        }

        //################################# End Player Select ############################################



        //################################# Start Player 1 Character Select ############################################

        private void cbP1Character_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbP1Character.Text != "")
            {
                pbP1.Image = Image.FromFile(@"Pictures\Brawl\ico\" + Character_Portraits.PortraitsBrawl(cbP1Character.Text));
            }
            else
            {
                pbP1.Image = Image.FromFile(@"Pictures\Smash_BlankCharacter.png");
            }
        }
        //################################# End Player 1 Character Select ############################################

        //################################# Start Player 2 Character Select ############################################
        private void cbP2Character_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbP2Character.Text != "")
            {
                pbP2.Image = Image.FromFile(@"Pictures\Brawl\ico\" + Character_Portraits.PortraitsBrawl(cbP2Character.Text));
            }
            else
            {
                pbP2.Image = Image.FromFile(@"Pictures\Smash_BlankCharacter.png");
            }
        }

        //################################# End Player 2 Character Select ############################################

        //################################# Start Player 3 Character Select ############################################
        private void cbP3Character_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbP3Character.Text != "")
            {
                pbP3.Image = Image.FromFile(@"Pictures\Brawl\ico\" + Character_Portraits.PortraitsBrawl(cbP3Character.Text));
            }
            else
            {
                pbP3.Image = Image.FromFile(@"Pictures\Smash_BlankCharacter.png");
            }
        }

        //################################# End Player 3 Character Select ############################################

        //################################# Start Player 4 Character Select ############################################
        private void cbP4Character_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbP4Character.Text != "")
            {
                pbP4.Image = Image.FromFile(@"Pictures\Brawl\ico\" + Character_Portraits.PortraitsBrawl(cbP4Character.Text));
            }
            else
            {
                pbP4.Image = Image.FromFile(@"Pictures\Smash_BlankCharacter.png");
            }
        }

        //################################# End Player 4 Character Select ############################################

        


        //################################# Start Submit ############################################
        private void btnSubmit_Click(object sender, EventArgs e)
        {
             if (pnlP3.Enabled && pnlP4.Enabled)  //################################# 4 Players ############################################
            {
                Addbattle addBrawl = new Addbattle();

                addBrawl.NumOfPlayers = cbNumberOfPlayers.Text;
                addBrawl.P1Character = cbP1Character.Text;
                addBrawl.P2Character = cbP2Character.Text;
                addBrawl.P3Character = cbP3Character.Text;
                addBrawl.P4Character = cbP4Character.Text;
                addBrawl.NumOfSds = txtNumOfSD.Text;
                addBrawl.P1TotalKos = txtNumOfKO.Text;
                addBrawl.P2KosForP1 = txtP2NumOfKosForP1.Text;
                addBrawl.P3KosForP1 = txtP3NumOfKosForP1.Text;
                addBrawl.P4KosForP1 = txtP4NumOfKosForP1.Text;
                addBrawl.P2KosAgainstP1 = txtP2NumOfKosAgainstP1.Text;
                addBrawl.P3KosAgainstP1 = txtP3NumOfKosAgainstP1.Text;
                addBrawl.P4KosAgainstP1 = txtP4NumOfKosAgainstP1.Text;
                addBrawl.BattleOutCome = cbBattleOutcome.Text;

                if (addBrawl.FeedBack.Contains("ERROR:"))
                {
                    lblFeedBack.Text = addBrawl.FeedBack;

        
                }

                else if (Convert.ToInt32(txtNumOfKO.Text) != Convert.ToInt32(txtP2NumOfKosForP1.Text) + Convert.ToInt32(txtP3NumOfKosForP1.Text) + Convert.ToInt32(txtP4NumOfKosForP1.Text))
                {
                    lblFeedBack.Text = "ERROR: Player 1'Number of Kos' does not match 'Number of kos for P1' fields.";
                }
                else
                {
                    lblFeedBack.Text = addBrawl.AddBattleBrawl() + addBrawl.AddBattlePlayer(IDBrawl.StrUserID);
                }

            }
            else if (pnlP3.Enabled && pnlP4.Enabled == false) //################################# 3 Players ############################################
            {
                Addbattle addBrawl = new Addbattle();

                addBrawl.NumOfPlayers = cbNumberOfPlayers.Text;
                addBrawl.P1Character = cbP1Character.Text;
                addBrawl.P2Character = cbP2Character.Text;
                addBrawl.P3Character = cbP3Character.Text;

                addBrawl.NumOfSds = txtNumOfSD.Text;
                addBrawl.P1TotalKos = txtNumOfKO.Text;
                addBrawl.P2KosForP1 = txtP2NumOfKosForP1.Text;
                addBrawl.P3KosForP1 = txtP3NumOfKosForP1.Text;

                addBrawl.P2KosAgainstP1 = txtP2NumOfKosAgainstP1.Text;
                addBrawl.P3KosAgainstP1 = txtP3NumOfKosAgainstP1.Text;
                addBrawl.BattleOutCome = cbBattleOutcome.Text;



                if (addBrawl.FeedBack.Contains("ERROR:"))
                {
                    lblFeedBack.Text = addBrawl.FeedBack;
                }
                else if (Convert.ToInt32(txtNumOfKO.Text) != Convert.ToInt32(txtP2NumOfKosForP1.Text) + Convert.ToInt32(txtP3NumOfKosForP1.Text))
                {
                    lblFeedBack.Text = "'Number of Kos' does not match 'Number of kos for P1' fields.";
                }
                else
                {
                    lblFeedBack.Text = addBrawl.AddBattleBrawl() + addBrawl.AddBattlePlayer(IDBrawl.StrUserID);
                }

            }

            else if (pnlP3.Enabled == false && pnlP4.Enabled == false) //################################# 2 Players ############################################
            {
                Addbattle addBrawl = new Addbattle();

                addBrawl.NumOfPlayers = cbNumberOfPlayers.Text;
                addBrawl.P1Character = cbP1Character.Text;
                addBrawl.P2Character = cbP2Character.Text;

                addBrawl.NumOfSds = txtNumOfSD.Text;
                addBrawl.P1TotalKos = txtNumOfKO.Text;
                addBrawl.P2KosForP1 = txtP2NumOfKosForP1.Text;

                addBrawl.P2KosAgainstP1 = txtP2NumOfKosAgainstP1.Text;
                addBrawl.BattleOutCome = cbBattleOutcome.Text;



                if (addBrawl.FeedBack.Contains("ERROR:"))
                {
                    lblFeedBack.Text = addBrawl.FeedBack;
                }
                else if (txtNumOfKO.Text != txtP2NumOfKosForP1.Text)
                {
                    lblFeedBack.Text = "'Number of Kos' does not match 'Number of kos for P1' fields.";
                }
                else
                {
                    lblFeedBack.Text = addBrawl.AddBattleBrawl() + addBrawl.AddBattlePlayer(IDBrawl.StrUserID);
                }

            }
        }

        //################################# End Submit ############################################



        private void btnClear_Click(object sender, EventArgs e)
        {
            cbNumberOfPlayers.SelectedIndex = -1;
            cbP1Character.SelectedIndex = -1;
            cbP2Character.SelectedIndex = -1;
            cbP3Character.SelectedIndex = -1;
            cbP4Character.SelectedIndex = -1;
            txtNumOfSD.Text = "";
            txtNumOfKO.Text = "";
            txtP2NumOfKosAgainstP1.Text = "";
            txtP3NumOfKosAgainstP1.Text = "";
            txtP4NumOfKosAgainstP1.Text = "";
            txtP2NumOfKosForP1.Text = "";
            txtP3NumOfKosForP1.Text = "";
            txtP4NumOfKosForP1.Text = "";
            cbBattleOutcome.SelectedIndex = -1;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            MiscFunc.GBSound(0);
            //MiscFunc.boop(5);
            this.Close();
            MiscFunc.ChooseSou(5);
        }



        public void CreateMyBorderlessWindow()
        {
            //this.FormBorderStyle = FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            this.StartPosition = FormStartPosition.CenterScreen;
            // Remove the control box so the form will only display client area. 
            this.ControlBox = false;
        }//End Seamless


        
    }
}
