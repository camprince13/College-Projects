﻿namespace Super_Smash_Stat_Tracker
{
    partial class AddBattleMelee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddBattleMelee));
            this.lblFeedBack = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pnlP1 = new System.Windows.Forms.Panel();
            this.txtNumOfKO = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNumOfSD = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pbP1 = new System.Windows.Forms.PictureBox();
            this.cbP1Character = new System.Windows.Forms.ComboBox();
            this.pnlP2 = new System.Windows.Forms.Panel();
            this.txtP2NumOfKosAgainstP1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtP2NumOfKosForP1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.pbP2 = new System.Windows.Forms.PictureBox();
            this.cbP2Character = new System.Windows.Forms.ComboBox();
            this.pnlP3 = new System.Windows.Forms.Panel();
            this.txtP3NumOfKosAgainstP1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtP3NumOfKosForP1 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.pbP3 = new System.Windows.Forms.PictureBox();
            this.cbP3Character = new System.Windows.Forms.ComboBox();
            this.pnlP4 = new System.Windows.Forms.Panel();
            this.txtP4NumOfKosAgainstP1 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtP4NumOfKosForP1 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.pbP4 = new System.Windows.Forms.PictureBox();
            this.cbP4Character = new System.Windows.Forms.ComboBox();
            this.pbVs3 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pbVS2 = new System.Windows.Forms.PictureBox();
            this.pbVs1 = new System.Windows.Forms.PictureBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.cbNumberOfPlayers = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbBattleOutcome = new System.Windows.Forms.ComboBox();
            this.lblUserName = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.pnlP1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbP1)).BeginInit();
            this.pnlP2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2)).BeginInit();
            this.pnlP3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3)).BeginInit();
            this.pnlP4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbVs3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbVS2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbVs1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblFeedBack
            // 
            this.lblFeedBack.AutoSize = true;
            this.lblFeedBack.BackColor = System.Drawing.Color.Transparent;
            this.lblFeedBack.ForeColor = System.Drawing.Color.White;
            this.lblFeedBack.Location = new System.Drawing.Point(133, 376);
            this.lblFeedBack.Name = "lblFeedBack";
            this.lblFeedBack.Size = new System.Drawing.Size(0, 13);
            this.lblFeedBack.TabIndex = 62;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(345, 12);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(342, 42);
            this.pictureBox8.TabIndex = 61;
            this.pictureBox8.TabStop = false;
            // 
            // pnlP1
            // 
            this.pnlP1.BackColor = System.Drawing.Color.Transparent;
            this.pnlP1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlP1.BackgroundImage")));
            this.pnlP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pnlP1.Controls.Add(this.txtNumOfKO);
            this.pnlP1.Controls.Add(this.label5);
            this.pnlP1.Controls.Add(this.txtNumOfSD);
            this.pnlP1.Controls.Add(this.label4);
            this.pnlP1.Controls.Add(this.pbP1);
            this.pnlP1.Controls.Add(this.cbP1Character);
            this.pnlP1.Location = new System.Drawing.Point(8, 121);
            this.pnlP1.Name = "pnlP1";
            this.pnlP1.Size = new System.Drawing.Size(181, 252);
            this.pnlP1.TabIndex = 60;
            // 
            // txtNumOfKO
            // 
            this.txtNumOfKO.Location = new System.Drawing.Point(46, 219);
            this.txtNumOfKO.Name = "txtNumOfKO";
            this.txtNumOfKO.Size = new System.Drawing.Size(100, 20);
            this.txtNumOfKO.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(56, 203);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Number of K.O.\'s:";
            // 
            // txtNumOfSD
            // 
            this.txtNumOfSD.Location = new System.Drawing.Point(46, 180);
            this.txtNumOfSD.Name = "txtNumOfSD";
            this.txtNumOfSD.Size = new System.Drawing.Size(100, 20);
            this.txtNumOfSD.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(62, 164);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Number of SD\'s:";
            // 
            // pbP1
            // 
            this.pbP1.BackColor = System.Drawing.Color.Transparent;
            this.pbP1.Location = new System.Drawing.Point(28, 56);
            this.pbP1.Name = "pbP1";
            this.pbP1.Size = new System.Drawing.Size(118, 96);
            this.pbP1.TabIndex = 9;
            this.pbP1.TabStop = false;
            // 
            // cbP1Character
            // 
            this.cbP1Character.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cbP1Character.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbP1Character.FormattingEnabled = true;
            this.cbP1Character.Items.AddRange(new object[] {
            "Bowser",
            "Captain Falcon",
            "Donkey Kong",
            "Dr.Mario",
            "Falco",
            "Fox",
            "Ganondorf",
            "Ice Climbers",
            "Jigglypuff",
            "Kirby",
            "Link",
            "Luigi",
            "Mario",
            "Marth",
            "Mewtwo",
            "Mr. Game & Watch",
            "Ness",
            "Peach",
            "Pichu",
            "Pikachu",
            "Roy",
            "Samus",
            "Yoshi",
            "Young Link",
            "Zelda/Sheik"});
            this.cbP1Character.Location = new System.Drawing.Point(28, 29);
            this.cbP1Character.Name = "cbP1Character";
            this.cbP1Character.Size = new System.Drawing.Size(118, 21);
            this.cbP1Character.TabIndex = 7;
            this.cbP1Character.SelectedIndexChanged += new System.EventHandler(this.cbP1Character_SelectedIndexChanged);
            // 
            // pnlP2
            // 
            this.pnlP2.BackColor = System.Drawing.Color.Transparent;
            this.pnlP2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlP2.BackgroundImage")));
            this.pnlP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pnlP2.Controls.Add(this.txtP2NumOfKosAgainstP1);
            this.pnlP2.Controls.Add(this.label6);
            this.pnlP2.Controls.Add(this.txtP2NumOfKosForP1);
            this.pnlP2.Controls.Add(this.label7);
            this.pnlP2.Controls.Add(this.pbP2);
            this.pnlP2.Controls.Add(this.cbP2Character);
            this.pnlP2.Location = new System.Drawing.Point(272, 121);
            this.pnlP2.Name = "pnlP2";
            this.pnlP2.Size = new System.Drawing.Size(181, 255);
            this.pnlP2.TabIndex = 59;
            // 
            // txtP2NumOfKosAgainstP1
            // 
            this.txtP2NumOfKosAgainstP1.Location = new System.Drawing.Point(49, 220);
            this.txtP2NumOfKosAgainstP1.Name = "txtP2NumOfKosAgainstP1";
            this.txtP2NumOfKosAgainstP1.Size = new System.Drawing.Size(100, 20);
            this.txtP2NumOfKosAgainstP1.TabIndex = 22;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(5, 204);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(144, 13);
            this.label6.TabIndex = 21;
            this.label6.Text = "Number of K.O.\'s Against P1:";
            // 
            // txtP2NumOfKosForP1
            // 
            this.txtP2NumOfKosForP1.Location = new System.Drawing.Point(49, 180);
            this.txtP2NumOfKosForP1.Name = "txtP2NumOfKosForP1";
            this.txtP2NumOfKosForP1.Size = new System.Drawing.Size(100, 20);
            this.txtP2NumOfKosForP1.TabIndex = 20;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(24, 164);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 13);
            this.label7.TabIndex = 19;
            this.label7.Text = "Number of K.O.\'s for P1:";
            // 
            // pbP2
            // 
            this.pbP2.BackColor = System.Drawing.Color.Transparent;
            this.pbP2.Location = new System.Drawing.Point(32, 56);
            this.pbP2.Name = "pbP2";
            this.pbP2.Size = new System.Drawing.Size(117, 96);
            this.pbP2.TabIndex = 18;
            this.pbP2.TabStop = false;
            // 
            // cbP2Character
            // 
            this.cbP2Character.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cbP2Character.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbP2Character.FormattingEnabled = true;
            this.cbP2Character.Items.AddRange(new object[] {
            "Bowser",
            "Captain Falcon",
            "Donkey Kong",
            "Dr.Mario",
            "Falco",
            "Fox",
            "Ganondorf",
            "Ice Climbers",
            "Jigglypuff",
            "Kirby",
            "Link",
            "Luigi",
            "Mario",
            "Marth",
            "Mewtwo",
            "Mr. Game & Watch",
            "Ness",
            "Peach",
            "Pichu",
            "Pikachu",
            "Roy",
            "Samus",
            "Yoshi",
            "Young Link",
            "Zelda/Sheik"});
            this.cbP2Character.Location = new System.Drawing.Point(32, 29);
            this.cbP2Character.Name = "cbP2Character";
            this.cbP2Character.Size = new System.Drawing.Size(117, 21);
            this.cbP2Character.TabIndex = 17;
            this.cbP2Character.SelectedIndexChanged += new System.EventHandler(this.cbP2Character_SelectedIndexChanged);
            // 
            // pnlP3
            // 
            this.pnlP3.BackColor = System.Drawing.Color.Transparent;
            this.pnlP3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlP3.BackgroundImage")));
            this.pnlP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pnlP3.Controls.Add(this.txtP3NumOfKosAgainstP1);
            this.pnlP3.Controls.Add(this.label8);
            this.pnlP3.Controls.Add(this.txtP3NumOfKosForP1);
            this.pnlP3.Controls.Add(this.label9);
            this.pnlP3.Controls.Add(this.pbP3);
            this.pnlP3.Controls.Add(this.cbP3Character);
            this.pnlP3.Location = new System.Drawing.Point(536, 121);
            this.pnlP3.Name = "pnlP3";
            this.pnlP3.Size = new System.Drawing.Size(183, 252);
            this.pnlP3.TabIndex = 58;
            // 
            // txtP3NumOfKosAgainstP1
            // 
            this.txtP3NumOfKosAgainstP1.Location = new System.Drawing.Point(51, 219);
            this.txtP3NumOfKosAgainstP1.Name = "txtP3NumOfKosAgainstP1";
            this.txtP3NumOfKosAgainstP1.Size = new System.Drawing.Size(100, 20);
            this.txtP3NumOfKosAgainstP1.TabIndex = 28;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(3, 203);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(144, 13);
            this.label8.TabIndex = 27;
            this.label8.Text = "Number of K.O.\'s Against P1:";
            // 
            // txtP3NumOfKosForP1
            // 
            this.txtP3NumOfKosForP1.Location = new System.Drawing.Point(51, 179);
            this.txtP3NumOfKosForP1.Name = "txtP3NumOfKosForP1";
            this.txtP3NumOfKosForP1.Size = new System.Drawing.Size(100, 20);
            this.txtP3NumOfKosForP1.TabIndex = 26;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(26, 163);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(121, 13);
            this.label9.TabIndex = 25;
            this.label9.Text = "Number of K.O.\'s for P1:";
            // 
            // pbP3
            // 
            this.pbP3.BackColor = System.Drawing.Color.Transparent;
            this.pbP3.Location = new System.Drawing.Point(30, 56);
            this.pbP3.Name = "pbP3";
            this.pbP3.Size = new System.Drawing.Size(121, 96);
            this.pbP3.TabIndex = 24;
            this.pbP3.TabStop = false;
            // 
            // cbP3Character
            // 
            this.cbP3Character.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cbP3Character.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbP3Character.FormattingEnabled = true;
            this.cbP3Character.Items.AddRange(new object[] {
            "Bowser",
            "Captain Falcon",
            "Donkey Kong",
            "Dr.Mario",
            "Falco",
            "Fox",
            "Ganondorf",
            "Ice Climbers",
            "Jigglypuff",
            "Kirby",
            "Link",
            "Luigi",
            "Mario",
            "Marth",
            "Mewtwo",
            "Mr. Game & Watch",
            "Ness",
            "Peach",
            "Pichu",
            "Pikachu",
            "Roy",
            "Samus",
            "Yoshi",
            "Young Link",
            "Zelda/Sheik"});
            this.cbP3Character.Location = new System.Drawing.Point(30, 29);
            this.cbP3Character.Name = "cbP3Character";
            this.cbP3Character.Size = new System.Drawing.Size(121, 21);
            this.cbP3Character.TabIndex = 23;
            this.cbP3Character.SelectedIndexChanged += new System.EventHandler(this.cbP3Character_SelectedIndexChanged);
            // 
            // pnlP4
            // 
            this.pnlP4.BackColor = System.Drawing.Color.Transparent;
            this.pnlP4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlP4.BackgroundImage")));
            this.pnlP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pnlP4.Controls.Add(this.txtP4NumOfKosAgainstP1);
            this.pnlP4.Controls.Add(this.label10);
            this.pnlP4.Controls.Add(this.txtP4NumOfKosForP1);
            this.pnlP4.Controls.Add(this.label11);
            this.pnlP4.Controls.Add(this.pbP4);
            this.pnlP4.Controls.Add(this.cbP4Character);
            this.pnlP4.Location = new System.Drawing.Point(801, 121);
            this.pnlP4.Name = "pnlP4";
            this.pnlP4.Size = new System.Drawing.Size(184, 252);
            this.pnlP4.TabIndex = 57;
            // 
            // txtP4NumOfKosAgainstP1
            // 
            this.txtP4NumOfKosAgainstP1.Location = new System.Drawing.Point(58, 219);
            this.txtP4NumOfKosAgainstP1.Name = "txtP4NumOfKosAgainstP1";
            this.txtP4NumOfKosAgainstP1.Size = new System.Drawing.Size(100, 20);
            this.txtP4NumOfKosAgainstP1.TabIndex = 34;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(7, 204);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(144, 13);
            this.label10.TabIndex = 33;
            this.label10.Text = "Number of K.O.\'s Against P1:";
            // 
            // txtP4NumOfKosForP1
            // 
            this.txtP4NumOfKosForP1.Location = new System.Drawing.Point(58, 180);
            this.txtP4NumOfKosForP1.Name = "txtP4NumOfKosForP1";
            this.txtP4NumOfKosForP1.Size = new System.Drawing.Size(100, 20);
            this.txtP4NumOfKosForP1.TabIndex = 32;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(30, 164);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(121, 13);
            this.label11.TabIndex = 31;
            this.label11.Text = "Number of K.O.\'s for P1:";
            // 
            // pbP4
            // 
            this.pbP4.BackColor = System.Drawing.Color.Transparent;
            this.pbP4.Location = new System.Drawing.Point(34, 56);
            this.pbP4.Name = "pbP4";
            this.pbP4.Size = new System.Drawing.Size(121, 96);
            this.pbP4.TabIndex = 30;
            this.pbP4.TabStop = false;
            // 
            // cbP4Character
            // 
            this.cbP4Character.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cbP4Character.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbP4Character.FormattingEnabled = true;
            this.cbP4Character.Items.AddRange(new object[] {
            "Bowser",
            "Captain Falcon",
            "Donkey Kong",
            "Dr.Mario",
            "Falco",
            "Fox",
            "Ganondorf",
            "Ice Climbers",
            "Jigglypuff",
            "Kirby",
            "Link",
            "Luigi",
            "Mario",
            "Marth",
            "Mewtwo",
            "Mr. Game & Watch",
            "Ness",
            "Peach",
            "Pichu",
            "Pikachu",
            "Roy",
            "Samus",
            "Yoshi",
            "Young Link",
            "Zelda/Sheik"});
            this.cbP4Character.Location = new System.Drawing.Point(34, 29);
            this.cbP4Character.Name = "cbP4Character";
            this.cbP4Character.Size = new System.Drawing.Size(121, 21);
            this.cbP4Character.TabIndex = 29;
            this.cbP4Character.SelectedIndexChanged += new System.EventHandler(this.cbP4Character_SelectedIndexChanged);
            // 
            // pbVs3
            // 
            this.pbVs3.BackColor = System.Drawing.Color.Transparent;
            this.pbVs3.Image = ((System.Drawing.Image)(resources.GetObject("pbVs3.Image")));
            this.pbVs3.InitialImage = null;
            this.pbVs3.Location = new System.Drawing.Point(724, 190);
            this.pbVs3.Name = "pbVs3";
            this.pbVs3.Size = new System.Drawing.Size(71, 45);
            this.pbVs3.TabIndex = 56;
            this.pbVs3.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(5, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 50;
            this.label3.Text = "(You)";
            // 
            // pbVS2
            // 
            this.pbVS2.BackColor = System.Drawing.Color.Transparent;
            this.pbVS2.Image = ((System.Drawing.Image)(resources.GetObject("pbVS2.Image")));
            this.pbVS2.InitialImage = null;
            this.pbVS2.Location = new System.Drawing.Point(459, 190);
            this.pbVS2.Name = "pbVS2";
            this.pbVS2.Size = new System.Drawing.Size(71, 45);
            this.pbVS2.TabIndex = 55;
            this.pbVS2.TabStop = false;
            // 
            // pbVs1
            // 
            this.pbVs1.BackColor = System.Drawing.Color.Transparent;
            this.pbVs1.Image = ((System.Drawing.Image)(resources.GetObject("pbVs1.Image")));
            this.pbVs1.InitialImage = null;
            this.pbVs1.Location = new System.Drawing.Point(195, 190);
            this.pbVs1.Name = "pbVs1";
            this.pbVs1.Size = new System.Drawing.Size(71, 45);
            this.pbVs1.TabIndex = 54;
            this.pbVs1.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(988, 563);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 53;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(493, 563);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 52;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(-2, 563);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSubmit.TabIndex = 51;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // cbNumberOfPlayers
            // 
            this.cbNumberOfPlayers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cbNumberOfPlayers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbNumberOfPlayers.FormattingEnabled = true;
            this.cbNumberOfPlayers.Items.AddRange(new object[] {
            "2",
            "3",
            "4"});
            this.cbNumberOfPlayers.Location = new System.Drawing.Point(136, 43);
            this.cbNumberOfPlayers.Name = "cbNumberOfPlayers";
            this.cbNumberOfPlayers.Size = new System.Drawing.Size(121, 21);
            this.cbNumberOfPlayers.TabIndex = 49;
            this.cbNumberOfPlayers.SelectedIndexChanged += new System.EventHandler(this.cbNumberOfPlayers_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(34, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 13);
            this.label2.TabIndex = 48;
            this.label2.Text = "Number of Players:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(47, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 63;
            this.label1.Text = "Battle Outcome:";
            // 
            // cbBattleOutcome
            // 
            this.cbBattleOutcome.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBattleOutcome.FormattingEnabled = true;
            this.cbBattleOutcome.Items.AddRange(new object[] {
            "Win",
            "Loss"});
            this.cbBattleOutcome.Location = new System.Drawing.Point(136, 79);
            this.cbBattleOutcome.Name = "cbBattleOutcome";
            this.cbBattleOutcome.Size = new System.Drawing.Size(121, 21);
            this.cbBattleOutcome.TabIndex = 64;
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.BackColor = System.Drawing.Color.Transparent;
            this.lblUserName.ForeColor = System.Drawing.Color.White;
            this.lblUserName.Location = new System.Drawing.Point(832, 41);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(0, 13);
            this.lblUserName.TabIndex = 65;
            // 
            // AddBattleMelee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1061, 586);
            this.Controls.Add(this.lblUserName);
            this.Controls.Add(this.cbBattleOutcome);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblFeedBack);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pnlP1);
            this.Controls.Add(this.pnlP2);
            this.Controls.Add(this.pnlP3);
            this.Controls.Add(this.pnlP4);
            this.Controls.Add(this.pbVs3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pbVS2);
            this.Controls.Add(this.pbVs1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.cbNumberOfPlayers);
            this.Controls.Add(this.label2);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddBattleMelee";
            this.Text = "AddBattleMelee";
            this.Load += new System.EventHandler(this.AddBattleMelee_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.pnlP1.ResumeLayout(false);
            this.pnlP1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbP1)).EndInit();
            this.pnlP2.ResumeLayout(false);
            this.pnlP2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbP2)).EndInit();
            this.pnlP3.ResumeLayout(false);
            this.pnlP3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbP3)).EndInit();
            this.pnlP4.ResumeLayout(false);
            this.pnlP4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbVs3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbVS2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbVs1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFeedBack;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Panel pnlP1;
        private System.Windows.Forms.TextBox txtNumOfKO;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNumOfSD;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pbP1;
        private System.Windows.Forms.ComboBox cbP1Character;
        private System.Windows.Forms.Panel pnlP2;
        private System.Windows.Forms.TextBox txtP2NumOfKosAgainstP1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtP2NumOfKosForP1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pbP2;
        private System.Windows.Forms.ComboBox cbP2Character;
        private System.Windows.Forms.Panel pnlP3;
        private System.Windows.Forms.TextBox txtP3NumOfKosAgainstP1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtP3NumOfKosForP1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pbP3;
        private System.Windows.Forms.ComboBox cbP3Character;
        private System.Windows.Forms.Panel pnlP4;
        private System.Windows.Forms.TextBox txtP4NumOfKosAgainstP1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtP4NumOfKosForP1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pbP4;
        private System.Windows.Forms.ComboBox cbP4Character;
        private System.Windows.Forms.PictureBox pbVs3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pbVS2;
        private System.Windows.Forms.PictureBox pbVs1;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.ComboBox cbNumberOfPlayers;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbBattleOutcome;
        public System.Windows.Forms.Label lblUserName;

    }
}