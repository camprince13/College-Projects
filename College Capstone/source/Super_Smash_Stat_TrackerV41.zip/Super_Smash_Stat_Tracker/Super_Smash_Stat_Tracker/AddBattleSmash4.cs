﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Super_Smash_Stat_Tracker
{
    public partial class AddBattleSmash4 : Form
    {
        public AddBattleSmash4()
        {
            InitializeComponent();
        }

        public UserName IDSmash4;

        private void AddBattleSmash4_Load(object sender, EventArgs e)
        {
            CreateMyBorderlessWindow();
            MiscFunc.GS4Sound(5);
            lblUserName.Text = "User ID: " + IDSmash4.StrUserID;
            pnlP5.Visible = false;
            pnlP6.Visible = false;
            pnlP7.Visible = false;
            pnlP8.Visible = false;
            pnlP5.Enabled = false;
            pnlP6.Enabled = false;
            pnlP7.Enabled = false;
            pnlP8.Enabled = false;
            pbVs4.Visible = false;
            pbVs5.Visible = false;
            pbVs6.Visible = false;
        }


        private void cbNumberOfPlayers_SelectedIndexChanged(object sender, EventArgs e)
        {
            //################################# Start Player Select ############################################

            if (cbNumberOfPlayers.SelectedIndex == 0)   //################################# 2 Players ############################################
            {
                pnlP3.Visible = false;
                pnlP4.Visible = false;
                pnlP3.Enabled = false;
                pnlP4.Enabled = false;
                pbVs2.Visible = false;
                pbVs3.Visible = false;


            }

            else if (cbNumberOfPlayers.SelectedIndex == 1)  //################################# 3 Players ############################################
            {
                pnlP3.Visible = true;
                pnlP4.Visible = false;
                pnlP3.Enabled = true;
                pnlP4.Enabled = false;
                pbVs2.Visible = true;
                pbVs3.Visible = false;

            }

            else if (cbNumberOfPlayers.SelectedIndex == 2)  //################################# 4 Players ############################################
            {
                pnlP3.Visible = true;
                pnlP4.Visible = true;
                pnlP3.Enabled = true;
                pnlP4.Enabled = true;
                pbVs2.Visible = true;
                pbVs3.Visible = true;

            }

        }

        //################################# End Player Select ############################################



        //################################# Start Character Select ############################################

        private void cbP1Character_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbP1Character.Text != "")
            {
                pbP1.Image = Image.FromFile(@"Pictures\Smash4\4ico\" + Character_Portraits.PortraitsSmash4(cbP1Character.Text));
            }
            else
            {
                pbP1.Image = Image.FromFile(@"Pictures\Smash_BlankCharacter.png");
            }
        }

        private void cbP2Character_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbP2Character.Text != "")
            {
                pbP2.Image = Image.FromFile(@"Pictures\Smash4\4ico\" + Character_Portraits.PortraitsSmash4(cbP2Character.Text));
            }
            else
            {
                pbP2.Image = Image.FromFile(@"Pictures\Smash_BlankCharacter.png");
            }
        }

        private void cbP3Character_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbP3Character.Text != "")
            {
                pbP3.Image = Image.FromFile(@"Pictures\Smash4\4ico\" + Character_Portraits.PortraitsSmash4(cbP3Character.Text));
            }
            else
            {
                pbP3.Image = Image.FromFile(@"Pictures\Smash_BlankCharacter.png");
            }
        }

        private void cbP4Character_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbP4Character.Text != "")
            {
                pbP4.Image = Image.FromFile(@"Pictures\Smash4\4ico\" + Character_Portraits.PortraitsSmash4(cbP4Character.Text));
            }
            else
            {
                pbP4.Image = Image.FromFile(@"Pictures\Smash_BlankCharacter.png");
            }
        }

        //################################# End Character Select ############################################



        //################################# Start Submit ############################################

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            
           if (pnlP3.Enabled && pnlP4.Enabled)  //################################# 4 Players ############################################
            {
                Addbattle addSmash4 = new Addbattle();

                addSmash4.NumOfPlayers = cbNumberOfPlayers.Text;
                addSmash4.P1Character = cbP1Character.Text;
                addSmash4.P2Character = cbP2Character.Text;
                addSmash4.P3Character = cbP3Character.Text;
                addSmash4.P4Character = cbP4Character.Text;
                addSmash4.NumOfSds = txtNumOfSD.Text;
                addSmash4.P1TotalKos = txtNumOfKO.Text;
                addSmash4.P2KosForP1 = txtP2NumOfKosForP1.Text;
                addSmash4.P3KosForP1 = txtP3NumOfKosForP1.Text;
                addSmash4.P4KosForP1 = txtP4NumOfKosForP1.Text;
                addSmash4.P2KosAgainstP1 = txtP2NumOfKosAgainstP1.Text;
                addSmash4.P3KosAgainstP1 = txtP3NumOfKosAgainstP1.Text;
                addSmash4.P4KosAgainstP1 = txtP4NumOfKosAgainstP1.Text;
                addSmash4.BattleOutCome = cbBattleOutcome.Text;

                if (addSmash4.FeedBack.Contains("ERROR:"))
                {
                    lblFeedBack.Text = addSmash4.FeedBack;


                }

                else if (Convert.ToInt32(txtNumOfKO.Text) != Convert.ToInt32(txtP2NumOfKosForP1.Text) + Convert.ToInt32(txtP3NumOfKosForP1.Text) + Convert.ToInt32(txtP4NumOfKosForP1.Text))
                {
                    lblFeedBack.Text = "ERROR: Player 1'Number of Kos' does not match 'Number of kos for P1' fields.";
                }
                else
                {
                    lblFeedBack.Text = addSmash4.AddBattleSmash4() + addSmash4.AddBattlePlayer(IDSmash4.StrUserID);
                }

            }
            else if (pnlP3.Enabled && pnlP4.Enabled == false) //################################# 3 Players ############################################
            {
                Addbattle addSmash4 = new Addbattle();

                addSmash4.NumOfPlayers = cbNumberOfPlayers.Text;
                addSmash4.P1Character = cbP1Character.Text;
                addSmash4.P2Character = cbP2Character.Text;
                addSmash4.P3Character = cbP3Character.Text;
                addSmash4.NumOfSds = txtNumOfSD.Text;
                addSmash4.P1TotalKos = txtNumOfKO.Text;
                addSmash4.P2KosForP1 = txtP2NumOfKosForP1.Text;
                addSmash4.P3KosForP1 = txtP3NumOfKosForP1.Text;
                addSmash4.P2KosAgainstP1 = txtP2NumOfKosAgainstP1.Text;
                addSmash4.P3KosAgainstP1 = txtP3NumOfKosAgainstP1.Text;
                addSmash4.BattleOutCome = cbBattleOutcome.Text;



                if (addSmash4.FeedBack.Contains("ERROR:"))
                {
                    lblFeedBack.Text = addSmash4.FeedBack;
                }
                else if (Convert.ToInt32(txtNumOfKO.Text) != Convert.ToInt32(txtP2NumOfKosForP1.Text) + Convert.ToInt32(txtP3NumOfKosForP1.Text))
                {
                    lblFeedBack.Text = "'Number of Kos' does not match 'Number of kos for P1' fields.";
                }
                else
                {
                    lblFeedBack.Text = addSmash4.AddBattleSmash4() + addSmash4.AddBattlePlayer(IDSmash4.StrUserID);
                }

            }

            else if (pnlP3.Enabled == false && pnlP4.Enabled == false) //################################# 2 Players ############################################
            {
                Addbattle addSmash4 = new Addbattle();

                addSmash4.NumOfPlayers = cbNumberOfPlayers.Text;
                addSmash4.P1Character = cbP1Character.Text;
                addSmash4.P2Character = cbP2Character.Text;
                addSmash4.NumOfSds = txtNumOfSD.Text;
                addSmash4.P1TotalKos = txtNumOfKO.Text;
                addSmash4.P2KosForP1 = txtP2NumOfKosForP1.Text;
                addSmash4.P2KosAgainstP1 = txtP2NumOfKosAgainstP1.Text;
                addSmash4.BattleOutCome = cbBattleOutcome.Text;



                if (addSmash4.FeedBack.Contains("ERROR:"))
                {
                    lblFeedBack.Text = addSmash4.FeedBack;
                }
                else if (txtNumOfKO.Text != txtP2NumOfKosForP1.Text)
                {
                    lblFeedBack.Text = "'Number of Kos' does not match 'Number of kos for P1' fields.";
                }
                else
                {
                    lblFeedBack.Text = addSmash4.AddBattleSmash4() + addSmash4.AddBattlePlayer(IDSmash4.StrUserID);
                }

            }
        }

               //################################# End Submit ############################################


        //################################# Start Clear ############################################

        private void btnClear_Click(object sender, EventArgs e)
        {
            cbNumberOfPlayers.SelectedIndex = -1;
            cbP1Character.SelectedIndex = -1;
            cbP2Character.SelectedIndex = -1;
            cbP3Character.SelectedIndex = -1;
            cbP4Character.SelectedIndex = -1;
            txtNumOfSD.Text = "";
            txtNumOfKO.Text = "";
            txtP2NumOfKosAgainstP1.Text = "";
            txtP3NumOfKosAgainstP1.Text = "";
            txtP4NumOfKosAgainstP1.Text = "";
            txtP2NumOfKosForP1.Text = "";
            txtP3NumOfKosForP1.Text = "";
            txtP4NumOfKosForP1.Text = "";
            cbBattleOutcome.SelectedIndex = -1;
        }

        //################################# End Clear ############################################
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
            MiscFunc.GS4Sound(0);
            //MiscFunc.boop(5);
            this.Close();
            MiscFunc.ChooseSou(5);
        }


        public void CreateMyBorderlessWindow()
        {
            //this.FormBorderStyle = FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            this.StartPosition = FormStartPosition.CenterScreen;
            // Remove the control box so the form will only display client area. 
            this.ControlBox = false;
        }

        //End Seamless



        }
    }

