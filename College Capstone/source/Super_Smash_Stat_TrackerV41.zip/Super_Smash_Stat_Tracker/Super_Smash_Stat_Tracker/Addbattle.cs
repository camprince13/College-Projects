﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Super_Smash_Stat_Tracker
{
    class Addbattle
    {
        private string numOfPlayers;
        private string p1Character;
        private string p2Character;
        private string p3Character;
        private string p4Character;
        private string numOfSds;
        private string p1TotalKos;
        private string p2KosForP1;
        private string p3KosForP1;
        private string p4KosForP1;
        private string p2KosAgainstP1;
        private string p3KosAgainstP1;
        private string p4KosAgainstP1;       
        private string battleOutcome;
        private string feedBack;

        public string NumOfPlayers
        {
            get { return numOfPlayers; }
            set
            {
                if (ValidationLibrary.isItFilledIn(value) == false)
                    feedBack += "ERROR: Select number of Players!" + "\n";
                numOfPlayers = value;
            }
        }

        public string P1Character
        {
            get { return p1Character; }
            set
            {
                if (ValidationLibrary.isItFilledIn(value) == false)
                    feedBack += "ERROR: P1 select a character!" + "\n";
                p1Character = value;
            }
        }

        public string P2Character
        {
            get { return p2Character; }
            set
            {
                if (ValidationLibrary.isItFilledIn(value) == false)
                    feedBack += "ERROR: P2 select a character!" + "\n"; 
                p2Character = value;
            }
        }

        public string P3Character
        {
            get { return p3Character; }
            set
            {
                if (ValidationLibrary.isItFilledIn(value) == false)
                    feedBack += "ERROR: P3 select a character!" + "\n";
                p3Character = value;
            }
        }

        public string P4Character
        {
            get { return p4Character; }
            set
            {
                if (ValidationLibrary.isItFilledIn(value) == false)
                    feedBack += "ERROR: P4 select a character!" + "\n"; 
                p4Character = value;
            }
        }
              

        public string NumOfSds
        {
            get { return numOfSds; }
            set {
                if (ValidationLibrary.isItFilledIn(value) == false)
                    feedBack += "ERROR: 'Number of SDs' cannot be left blank." + "\n";
                else if (ValidationLibrary.isItNumeric(value) == false)
                    feedBack += "ERROR: 'Number of SDs' must be numeric." + "\n"; 
                else if (ValidationLibrary.isItPositive(value) == false)
                    feedBack += "ERROR: 'Number of SDs' cannot be negative." + "\n";
                numOfSds = value;
            }
        }

        

        public string P2KosForP1
        {
            get { return p2KosForP1; }
            set
            {
                if (ValidationLibrary.isItFilledIn(value) == false)
                    feedBack += "ERROR: Player 2 'Number of Kos for P1' field cannot be left blank." + "\n";
                else if (ValidationLibrary.isItNumeric(value) == false)
                    feedBack += "ERROR: Player 2 'Number of Kos for P1' field must be numeric." + "\n";
                else if (ValidationLibrary.isItPositive(value) == false)
                    feedBack += "ERROR: Player 2 'Number of Kos for P1' cannot be negative." + "\n";
                p2KosForP1 = value;
            }
        }

        public string P3KosForP1
        {
            get { return p3KosForP1; }
            set
            {
                if (ValidationLibrary.isItFilledIn(value) == false)
                    feedBack += "ERROR: Player 3 'Number of Kos for P1' field cannot be left blank." + "\n";
                else if (ValidationLibrary.isItNumeric(value) == false)
                    feedBack += "ERROR: Player 3 'Number of Kos for P1' field must be numeric." + "\n";
                else if (ValidationLibrary.isItPositive(value) == false)
                    feedBack += "ERROR: Player 3 'Number of Kos for P1' cannot be negative." + "\n";
                p3KosForP1 = value;
            }
        }

        public string P4KosForP1
        {
            get { return p4KosForP1; }
            set
            {
                if (ValidationLibrary.isItFilledIn(value) == false)
                    feedBack += "ERROR: Player 4 'Number of Kos for P1' field cannot be left blank." + "\n";
                else if (ValidationLibrary.isItNumeric(value) == false)
                    feedBack += "ERROR: Player 4 'Number of Kos for P1' field must be numeric." + "\n";
                else if (ValidationLibrary.isItPositive(value) == false)
                    feedBack += "ERROR: Player 4 'Number of Kos for P1' cannot be negative." + "\n";
                p4KosForP1 = value;
            }
        }

       
        
        public string P2KosAgainstP1
        {
            get { return p2KosAgainstP1; }
            set {
                if (ValidationLibrary.isItFilledIn(value) == false)
                    feedBack += "ERROR: Player 2 'Number of Kos against P1' field can not be left blank." + "\n";
                else if (ValidationLibrary.isItNumeric(value) == false)
                    feedBack += "ERROR: Player 2 'Number of Kos against P1' field must be numeric." + "\n";
                else if (ValidationLibrary.isItPositive(value) == false)
                    feedBack += "ERROR: Player 2 'Number of Kos against P1' cannot be negative." + "\n";
                p2KosAgainstP1 = value;
            }
        }

        public string P3KosAgainstP1
        {
            get { return p3KosAgainstP1; }
            set
            {
                if (ValidationLibrary.isItFilledIn(value) == false)
                    feedBack += "ERROR: Player 3 'Number of Kos against P1' field can not be left blank." + "\n";
                else if (ValidationLibrary.isItNumeric(value) == false)
                    feedBack += "ERROR: Player 3 'Number of Kos against P1' field must be numeric." + "\n";
                else if (ValidationLibrary.isItPositive(value) == false)
                    feedBack += "ERROR: Player 3 'Number of Kos against P1' cannot be negative." + "\n";
                p3KosAgainstP1 = value;
            }
        }
        
        public string P4KosAgainstP1
        {
            get { return p4KosAgainstP1; }
            set
            {
                if (ValidationLibrary.isItFilledIn(value) == false)
                    feedBack += "ERROR: Player 4 'Number of Kos against P1' field can not be left blank." + "\n";
                else if (ValidationLibrary.isItNumeric(value) == false)
                    feedBack += "ERROR: Player 4 'Number of Kos against P1' field must be numeric." + "\n";
                else if (ValidationLibrary.isItPositive(value) == false)
                    feedBack += "ERROR: Player 4 'Number of Kos against P1' cannot be negative." + "\n";
                p4KosAgainstP1 = value;
            }
        }


    public string P1TotalKos
        {
            get { return p1TotalKos; }
            set
            {
                if (ValidationLibrary.isItFilledIn(value) == false)
                    feedBack += "ERROR: Player 1 'Number of Kos' cannot be left blank." + "\n";
                else if (ValidationLibrary.isItNumeric(value) == false)
                    feedBack += "ERROR: Player 1 'Number of Kos' must be numeric." + "\n";
                else if (ValidationLibrary.isItPositive(value) == false)
                    feedBack += "ERROR: Player 1 'Number of Kos' cannot be negative." + "\n";
                p1TotalKos = value;
            } 
          }

        public string BattleOutCome
        {
            get { return battleOutcome; }
            set { 
                 if (ValidationLibrary.isItFilledIn(value) == false)
                    feedBack += "ERROR: Battle outcome has not yet been selected." + "\n";
                battleOutcome = value; }
        }


        public string FeedBack
        {
            get { return feedBack; }
        }

        public Addbattle()
        {
            feedBack = "";
        }


        

        

        public string AddBattle64()
        {
            string strFeedBack = "";

            
            string strSQL = "UPDATE ssbg64 SET Wins+=@victory, Losses+=@loss, NumOfSDs+=@numOfSDs ,CaptainFalcon_+=@kosAgainstCF , DonkeyKong_+=@kosAgainstDK , Fox_+=@kosAgainstFox , JigglyPuff_+=@kosAgainstJP, Kirby_+=@kosAgainstKirby , Link_+=@kosAgainstLink , Luigi_+=@kosAgainstLuigi , Mario_+=@kosAgainstMario , Ness_+=@kosAgainstNess , Pikachu_+=@kosAgainstPika , Samus_+=@kosAgainstSamus, Yoshi_+=@kosAgainstYoshi WHERE Char=@P1Character";
            SqlConnection conn = new SqlConnection();

            string strConn = @ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            if (battleOutcome == "Win")
            {
                comm.Parameters.AddWithValue("@victory", +1);
                comm.Parameters.AddWithValue("@loss", 0);
                comm.Parameters.AddWithValue("@numOfSDs", NumOfSds);
                comm.Parameters.AddWithValue("@kosAgainstCF", DetermineKos.DetermineKosCF(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstDK", DetermineKos.DetermineKosDk(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstFox", DetermineKos.DetermineKosFox(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstJP", DetermineKos.DetermineKosJP(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstKirby", DetermineKos.DetermineKosKirby(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLink", DetermineKos.DetermineKosLink(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLuigi", DetermineKos.DetermineKosLuigi(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMario", DetermineKos.DetermineKosMario(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstNess", DetermineKos.DetermineKosNess(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstPika", DetermineKos.DetermineKosPika(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstSamus", DetermineKos.DetermineKosSamus(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstYoshi", DetermineKos.DetermineKosYoshi(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@P1Character", p1Character);
            }
            else if (battleOutcome == "Loss")
            {
                comm.Parameters.AddWithValue("@victory", 0);
                comm.Parameters.AddWithValue("@loss", +1);
                comm.Parameters.AddWithValue("@numOfSDs", NumOfSds);
                comm.Parameters.AddWithValue("@kosAgainstCF", DetermineKos.DetermineKosCF(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstDK", DetermineKos.DetermineKosDk(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstFox", DetermineKos.DetermineKosFox(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstJP", DetermineKos.DetermineKosJP(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstKirby", DetermineKos.DetermineKosKirby(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLink", DetermineKos.DetermineKosLink(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLuigi", DetermineKos.DetermineKosLuigi(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMario", DetermineKos.DetermineKosMario(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstNess", DetermineKos.DetermineKosNess(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstPika", DetermineKos.DetermineKosPika(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstSamus", DetermineKos.DetermineKosSamus(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstYoshi", DetermineKos.DetermineKosYoshi(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@P1Character", p1Character);
            }




            try
            {
                conn.Open();

                strFeedBack = comm.ExecuteNonQuery().ToString() + "Battle Added.";
                conn.Close();
            }
            catch (Exception err)
            {
                strFeedBack = "ERROR: " + err.Message;
            }

            return strFeedBack;
        }
    
        public string AddBattleMelee()
        {
            string strFeedBack = "";

            
            string strSQL = "UPDATE SSBGM SET Win+=@victory, Loss+=@loss , NumOfSDs+=@numOfSDs , Bowser_+=@kosAgainstBowser , CaptainFalcon_+=@kosAgainstCF , DonkeyKong_+=@kosAgainstDK , DrMario_+=@kosAgainstDrMario , Falco_+=@kosAgainstFalco , Fox_+=@kosAgainstFox , Ganondorf_+=@kosAgainstGanon , IceClimbers_+=@kosAgainstIce , Jigglypuff_+=@kosAgainstJP , Kirby_+=@kosAgainstKirby , Link_+=@kosAgainstLink , Luigi_+=@kosAgainstLuigi ,Mario_+=@kosAgainstMario , Marth_+=@kosAgainstMarth , Mewtwo_+=@kosAgainstMewtwo , MrGameWatch_+=@kosAgainstMrGameWatch , Ness_+=@kosAgainstNess , Peach_+=@kosAgainstPeach , Pichu_+=@kosAgainstPichu , Pikachu_+=@kosAgainstPika , Roy_+=@kosAgainstRoy , Samus_+=@kosAgainstSamus , Yoshi_+=@kosAgainstYoshi , YoungLink_+=@kosAgainstYoungLink , Zelda_Sheik_+=@kosAgainstZelda WHERE Char=@P1Character";

            SqlConnection conn = new SqlConnection();

            string strConn = @ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            if(battleOutcome == "Win")
            {
            comm.Parameters.AddWithValue("@victory", +1 );
            comm.Parameters.AddWithValue("@loss", 0);
            comm.Parameters.AddWithValue("@numOfSDs", NumOfSds);
            comm.Parameters.AddWithValue("@kosAgainstBowser", DetermineKos.DetermineKosBowser(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstCF", DetermineKos.DetermineKosCF(P2Character,P2KosForP1,P3Character,P3KosForP1,P4Character,P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstDK",  DetermineKos.DetermineKosDk(P2Character,P2KosForP1,P3Character,P3KosForP1,P4Character,P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstDrMario", DetermineKos.DetermineKosDrMario(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstFalco", DetermineKos.DetermineKosFalco(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstFox", DetermineKos.DetermineKosFox(P2Character,P2KosForP1,P3Character,P3KosForP1,P4Character,P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstGanon", DetermineKos.DetermineKosGanon(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstIce", DetermineKos.DetermineKosIce(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstJP", DetermineKos.DetermineKosJP(P2Character,P2KosForP1,P3Character,P3KosForP1,P4Character,P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstKirby", DetermineKos.DetermineKosKirby(P2Character,P2KosForP1,P3Character,P3KosForP1,P4Character,P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstLink", DetermineKos.DetermineKosLink(P2Character,P2KosForP1,P3Character,P3KosForP1,P4Character,P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstLuigi", DetermineKos.DetermineKosLuigi(P2Character,P2KosForP1,P3Character,P3KosForP1,P4Character,P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstMario", DetermineKos.DetermineKosMario(P2Character,P2KosForP1,P3Character,P3KosForP1,P4Character,P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstMarth", DetermineKos.DetermineKosMarth(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstMewtwo", DetermineKos.DetermineKosMewtwo(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstMrGameWatch", DetermineKos.DetermineKosMrGame(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstNess", DetermineKos.DetermineKosNess(P2Character,P2KosForP1,P3Character,P3KosForP1,P4Character,P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstPeach", DetermineKos.DetermineKosPeach(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstPichu", DetermineKos.DetermineKosPichu(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstPika", DetermineKos.DetermineKosPika(P2Character,P2KosForP1,P3Character,P3KosForP1,P4Character,P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstRoy", DetermineKos.DetermineKosRoy(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstSamus", DetermineKos.DetermineKosSamus(P2Character,P2KosForP1,P3Character,P3KosForP1,P4Character,P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstYoshi", DetermineKos.DetermineKosYoshi(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstYoungLink", DetermineKos.DetermineKosYoungLink(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
            comm.Parameters.AddWithValue("@kosAgainstZelda", DetermineKos.DetermineKosZeldaShiek(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
            comm.Parameters.AddWithValue("@P1Character", p1Character);
            }
            else if (battleOutcome == "Loss")
            {
                comm.Parameters.AddWithValue("@victory", 0);
                comm.Parameters.AddWithValue("@loss", +1);
                comm.Parameters.AddWithValue("@numOfSDs", NumOfSds);
                comm.Parameters.AddWithValue("@kosAgainstBowser", DetermineKos.DetermineKosBowser(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstCF", DetermineKos.DetermineKosCF(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstDK", DetermineKos.DetermineKosDk(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstDrMario", DetermineKos.DetermineKosDrMario(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstFalco", DetermineKos.DetermineKosFalco(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstFox", DetermineKos.DetermineKosFox(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstGanon", DetermineKos.DetermineKosGanon(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstIce", DetermineKos.DetermineKosIce(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstJP", DetermineKos.DetermineKosJP(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstKirby", DetermineKos.DetermineKosKirby(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLink", DetermineKos.DetermineKosLink(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLuigi", DetermineKos.DetermineKosLuigi(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMario", DetermineKos.DetermineKosMario(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMarth", DetermineKos.DetermineKosMarth(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMewtwo", DetermineKos.DetermineKosMewtwo(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMrGameWatch", DetermineKos.DetermineKosMrGame(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstNess", DetermineKos.DetermineKosNess(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstPeach", DetermineKos.DetermineKosPeach(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstPichu", DetermineKos.DetermineKosPichu(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstPika", DetermineKos.DetermineKosPika(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstRoy", DetermineKos.DetermineKosRoy(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstSamus", DetermineKos.DetermineKosSamus(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstYoshi", DetermineKos.DetermineKosYoshi(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstYoungLink", DetermineKos.DetermineKosYoungLink(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstZelda", DetermineKos.DetermineKosZeldaShiek(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@P1Character", p1Character);
            }




            try
            {
                conn.Open();

                strFeedBack = comm.ExecuteNonQuery().ToString() + "Battle Added.";
                conn.Close();
            }
            catch (Exception err)
            {
                strFeedBack = "ERROR: " + err.Message;
            }

            return strFeedBack;
        }

        public string AddBattleBrawl()
        {
            string strFeedBack = "";

            
            string strSQL = "UPDATE SSBGB SET Wins+=@victory, Losses+=@loss , NumOfSDs+=@numOfSDs , Bowser_+=@kosAgainstBowser , CaptainFalcon_+=@kosAgainstCF , DiddyKong_+=@kosAgainstDiddyKong , DonkeyKong_+=@kosAgainstDK ,  Falco_+=@kosAgainstFalco , Fox_+=@kosAgainstFox , Ganondorf_+=@kosAgainstGanon , IceClimbers_+=@kosAgainstIce , Ike_+=@kosAgainstIke ,Jigglypuff_+=@kosAgainstJP , KingDedede_+=@kosAgainstKingDedede , Kirby_+=@kosAgainstKirby , Link_+=@kosAgainstLink , Lucario_+=@kosAgainstLucario , Lucas_+=@kosAgainstLucas , Luigi_+=@kosAgainstLuigi , Mario_+=@kosAgainstMario , Marth_+=@kosAgainstMarth , Metaknight_+=@kosAgainstMetaknight , MrGameWatch_+=@kosAgainstMrGameWatch , Ness_+=@kosAgainstNess , Olimar_+=@kosAgainstOlimar ,Peach_+=@kosAgainstPeach , Pikachu_+=@kosAgainstPika , Pit_+=@kosAgainstPit , PokemonTrainer_+=@kosAgainstTrainer , ROB_+=@kosAgainstROB , Samus_and_Zero_Suit_+=@kosAgainstSamus , Snake_+=@kosAgainstSnake , Sonic_+=@kosAgainstSonic , ToonLink_+=@kosAgainstToonLink , Wario_+=@kosAgainstWario , Wolf_+=@kosAgainstWolf , Yoshi_+=@kosAgainstYoshi , Zelda_Sheik_+=@kosAgainstZelda WHERE Char=@P1Character";

            SqlConnection conn = new SqlConnection();

            string strConn = @ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            if (battleOutcome == "Win")
            {
                comm.Parameters.AddWithValue("@victory", +1);
                comm.Parameters.AddWithValue("@loss", 0);
                comm.Parameters.AddWithValue("@numOfSDs", NumOfSds);
                comm.Parameters.AddWithValue("@kosAgainstBowser", DetermineKos.DetermineKosBowser(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstCF", DetermineKos.DetermineKosCF(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstDiddyKong", DetermineKos.DetermineKosDiddyKong(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstDK", DetermineKos.DetermineKosDk(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstFalco", DetermineKos.DetermineKosFalco(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstFox", DetermineKos.DetermineKosFox(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstGanon", DetermineKos.DetermineKosGanon(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstIce", DetermineKos.DetermineKosIce(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstIke", DetermineKos.DetermineKosIke(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstJP", DetermineKos.DetermineKosJP(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstKingDedede", DetermineKos.DetermineKosDedede(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstKirby", DetermineKos.DetermineKosKirby(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLink", DetermineKos.DetermineKosLink(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLucario", DetermineKos.DetermineKosLucario(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLucas", DetermineKos.DetermineKosLucas(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLuigi", DetermineKos.DetermineKosLuigi(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMario", DetermineKos.DetermineKosMario(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMarth", DetermineKos.DetermineKosMarth(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMetaknight", DetermineKos.DetermineKosMetaknight(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMrGameWatch", DetermineKos.DetermineKosMrGame(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstNess", DetermineKos.DetermineKosNess(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstOlimar", DetermineKos.DetermineKosOlimar(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstPeach", DetermineKos.DetermineKosPeach(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));               
                comm.Parameters.AddWithValue("@kosAgainstPika", DetermineKos.DetermineKosPika(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstPit", DetermineKos.DetermineKosPit(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstTrainer", DetermineKos.DetermineKosPokemonTrainer(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstROB", DetermineKos.DetermineKosROB(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstSamus", DetermineKos.DetermineKosSamusAndZero(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstSnake", DetermineKos.DetermineKosSnake(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstSonic", DetermineKos.DetermineKosSonic(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstToonLink", DetermineKos.DetermineKosToonLink(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstWario", DetermineKos.DetermineKosWario(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstWolf", DetermineKos.DetermineKosWolf(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstYoshi", DetermineKos.DetermineKosYoshi(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));                
                comm.Parameters.AddWithValue("@kosAgainstZelda", DetermineKos.DetermineKosZeldaShiek(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@P1Character", p1Character);
            }
            else if (battleOutcome == "Loss")
            {
                comm.Parameters.AddWithValue("@victory", 0);
                comm.Parameters.AddWithValue("@loss", +1);
                comm.Parameters.AddWithValue("@numOfSDs", NumOfSds);
                comm.Parameters.AddWithValue("@kosAgainstBowser", DetermineKos.DetermineKosBowser(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstCF", DetermineKos.DetermineKosCF(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstDiddyKong", DetermineKos.DetermineKosDiddyKong(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstDK", DetermineKos.DetermineKosDk(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstFalco", DetermineKos.DetermineKosFalco(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstFox", DetermineKos.DetermineKosFox(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstGanon", DetermineKos.DetermineKosGanon(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstIce", DetermineKos.DetermineKosIce(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstIke", DetermineKos.DetermineKosIke(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstJP", DetermineKos.DetermineKosJP(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstKingDedede", DetermineKos.DetermineKosDedede(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstKirby", DetermineKos.DetermineKosKirby(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLink", DetermineKos.DetermineKosLink(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLucario", DetermineKos.DetermineKosLucario(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLucas", DetermineKos.DetermineKosLucas(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLuigi", DetermineKos.DetermineKosLuigi(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMario", DetermineKos.DetermineKosMario(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMarth", DetermineKos.DetermineKosMarth(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMetaknight", DetermineKos.DetermineKosMetaknight(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMrGameWatch", DetermineKos.DetermineKosMrGame(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstNess", DetermineKos.DetermineKosNess(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstOlimar", DetermineKos.DetermineKosOlimar(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstPeach", DetermineKos.DetermineKosPeach(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstPika", DetermineKos.DetermineKosPika(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstPit", DetermineKos.DetermineKosPit(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstTrainer", DetermineKos.DetermineKosPokemonTrainer(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstROB", DetermineKos.DetermineKosROB(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstSamus", DetermineKos.DetermineKosSamusAndZero(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstSnake", DetermineKos.DetermineKosSnake(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstSonic", DetermineKos.DetermineKosSonic(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstToonLink", DetermineKos.DetermineKosToonLink(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstWario", DetermineKos.DetermineKosWario(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstWolf", DetermineKos.DetermineKosWolf(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstYoshi", DetermineKos.DetermineKosYoshi(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstZelda", DetermineKos.DetermineKosZeldaShiek(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@P1Character", p1Character);
            }




            try
            {
                conn.Open();

                strFeedBack = comm.ExecuteNonQuery().ToString() + "Battle Added.";
                conn.Close();
            }
            catch (Exception err)
            {
                strFeedBack = "ERROR: " + err.Message;
            }

            return strFeedBack;
        }

        public string AddBattleSmash4()
        {
            string strFeedBack = "";

            
            string strSQL = "UPDATE SSBG4 SET Wins+=@victory, Losses+=@loss , NumOfSDs+=@numOfSDs , Bowser_+=@kosAgainstBowser , BowserJr_=@kosAgainstBowserJr ,CaptainFalcon_+=@kosAgainstCF , Charizard_+=@kosAgainstCharizard , DarkPit_+=@kosAgainstDarkPit ,DiddyKong_+=@kosAgainstDiddyKong , DonkeyKong_+=@kosAgainstDK , DrMario_+=@kosAgainstDrMario , DuckHunt_+=@kosAgainstDuckHunt , Falco_+=@kosAgainstFalco , Fox_+=@kosAgainstFox , Ganondorf_+=@kosAgainstGanon , Greninja_+=@kosAgainstGreninja , Ike_+=@kosAgainstIke ,Jigglypuff_+=@kosAgainstJP , KingDedede_+=@kosAgainstKingDedede , Kirby_+=@kosAgainstKirby , Link_+=@kosAgainstLink , LittleMac_+=@kosAgainstLittleMac ,Lucario_+=@kosAgainstLucario , Lucina_+=@kosAgainstLucina , Luigi_+=@kosAgainstLuigi , Mario_+=@kosAgainstMario , Marth_+=@kosAgainstMarth , MegaMan_+=@kosAgainstMegaMan , Metaknight_+=@kosAgainstMetaknight , MrGameWatch_+=@kosAgainstMrGameWatch , Ness_+=@kosAgainstNess , Olimar_+=@kosAgainstOlimar , PacMan_+=@kosAgainstPacMan , Palutena_+=@kosAgainstPalutena , Peach_+=@kosAgainstPeach , Pikachu_+=@kosAgainstPika , Pit_+=@kosAgainstPit , ROB_+=@kosAgainstROB , Robin_+=@kosAgainstRobin , RosalinaLuma_+=@kosagainstRosalinaLuma , Samus_+=@kosAgainstSamus , Sheik_+=@kosAgainstSheik , Shulk_+=@kosAgainstShulk , Sonic_+=@kosAgainstSonic , ToonLink_+=@kosAgainstToonLink , Villager_+=@kosAgainstVillager , Wario_+=@kosAgainstWario , WiiFitTrainer_+=@kosAgainstWiiFit , Yoshi_+=@kosAgainstYoshi , Zelda_+=@kosAgainstZelda , ZeroSuitSamus_+=@kosAgainstZeroSuit WHERE Char=@P1Character";

            SqlConnection conn = new SqlConnection();

            string strConn = @ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            if (battleOutcome == "Win")
            {
                comm.Parameters.AddWithValue("@victory", +1);
                comm.Parameters.AddWithValue("@loss", 0);
                comm.Parameters.AddWithValue("@numOfSDs", NumOfSds);
                comm.Parameters.AddWithValue("@kosAgainstBowser", DetermineKos.DetermineKosBowser(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstBowserJr", DetermineKos.DetermineKosBowserJr(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstCF", DetermineKos.DetermineKosCF(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstCharizard", DetermineKos.DetermineKosCharizard(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstDarkPit", DetermineKos.DetermineKosDarkPit(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstDiddyKong", DetermineKos.DetermineKosDiddyKong(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstDK", DetermineKos.DetermineKosDk(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstDrMario", DetermineKos.DetermineKosDrMario(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstDuckHunt", DetermineKos.DetermineKosDuckHunt(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstFalco", DetermineKos.DetermineKosFalco(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstFox", DetermineKos.DetermineKosFox(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstGanon", DetermineKos.DetermineKosGanon(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstGreninja", DetermineKos.DetermineKosGreninja(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstIke", DetermineKos.DetermineKosIke(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstJP", DetermineKos.DetermineKosJP(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstKingDedede", DetermineKos.DetermineKosDedede(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstKirby", DetermineKos.DetermineKosKirby(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLink", DetermineKos.DetermineKosLink(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLittleMac", DetermineKos.DetermineKosLittleMac(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLucario", DetermineKos.DetermineKosLucario(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLucina", DetermineKos.DetermineKosLucina(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLuigi", DetermineKos.DetermineKosLuigi(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMario", DetermineKos.DetermineKosMario(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMarth", DetermineKos.DetermineKosMarth(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMegaMan", DetermineKos.DetermineKosMegaMan(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMetaknight", DetermineKos.DetermineKosMetaknight(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMrGameWatch", DetermineKos.DetermineKosMrGame(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstNess", DetermineKos.DetermineKosNess(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstOlimar", DetermineKos.DetermineKosOlimar(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstPacMan", DetermineKos.DetermineKosPacMan(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstPalutena", DetermineKos.DetermineKosPalutena(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstPeach", DetermineKos.DetermineKosPeach(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));               
                comm.Parameters.AddWithValue("@kosAgainstPika", DetermineKos.DetermineKosPika(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstPit", DetermineKos.DetermineKosPit(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstROB", DetermineKos.DetermineKosROB(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstRobin", DetermineKos.DetermineKosRobin(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstRosalinaLuma", DetermineKos.DetermineKosRosalina(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstSamus", DetermineKos.DetermineKosSamus(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstSheik", DetermineKos.DetermineKosSheik(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstShulk", DetermineKos.DetermineKosShulk(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstSonic", DetermineKos.DetermineKosSonic(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstToonLink", DetermineKos.DetermineKosToonLink(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstVillager", DetermineKos.DetermineKosVillager(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstWario", DetermineKos.DetermineKosWario(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstWiiFit", DetermineKos.DetermineKosWiiFit(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstYoshi", DetermineKos.DetermineKosYoshi(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));                
                comm.Parameters.AddWithValue("@kosAgainstZelda", DetermineKos.DetermineKosZelda(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstZeroSuit", DetermineKos.DetermineKosZeroSuit(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@P1Character", p1Character);
            }
            else if (battleOutcome == "Loss")
            {
                comm.Parameters.AddWithValue("@victory", 0);
                comm.Parameters.AddWithValue("@loss", +1);
                comm.Parameters.AddWithValue("@numOfSDs", NumOfSds);
                comm.Parameters.AddWithValue("@kosAgainstBowser", DetermineKos.DetermineKosBowser(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstBowserJr", DetermineKos.DetermineKosBowserJr(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstCF", DetermineKos.DetermineKosCF(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstCharizard", DetermineKos.DetermineKosCharizard(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstDarkPit", DetermineKos.DetermineKosDarkPit(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstDiddyKong", DetermineKos.DetermineKosDiddyKong(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstDK", DetermineKos.DetermineKosDk(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstDrMario", DetermineKos.DetermineKosDrMario(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstDuckHunt", DetermineKos.DetermineKosDuckHunt(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstFalco", DetermineKos.DetermineKosFalco(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstFox", DetermineKos.DetermineKosFox(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstGanon", DetermineKos.DetermineKosGanon(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstGreninja", DetermineKos.DetermineKosGreninja(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstIke", DetermineKos.DetermineKosIke(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstJP", DetermineKos.DetermineKosJP(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstKingDedede", DetermineKos.DetermineKosDedede(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstKirby", DetermineKos.DetermineKosKirby(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLink", DetermineKos.DetermineKosLink(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLittleMac", DetermineKos.DetermineKosLittleMac(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLucario", DetermineKos.DetermineKosLucario(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLucina", DetermineKos.DetermineKosLucina(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstLuigi", DetermineKos.DetermineKosLuigi(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMario", DetermineKos.DetermineKosMario(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMarth", DetermineKos.DetermineKosMarth(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMegaMan", DetermineKos.DetermineKosMegaMan(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMetaknight", DetermineKos.DetermineKosMetaknight(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstMrGameWatch", DetermineKos.DetermineKosMrGame(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstNess", DetermineKos.DetermineKosNess(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstOlimar", DetermineKos.DetermineKosOlimar(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstPacMan", DetermineKos.DetermineKosPacMan(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstPalutena", DetermineKos.DetermineKosPalutena(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstPeach", DetermineKos.DetermineKosPeach(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstPika", DetermineKos.DetermineKosPika(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstPit", DetermineKos.DetermineKosPit(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstROB", DetermineKos.DetermineKosROB(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstRobin", DetermineKos.DetermineKosRobin(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstRosalinaLuma", DetermineKos.DetermineKosRosalina(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstSamus", DetermineKos.DetermineKosSamus(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstSheik", DetermineKos.DetermineKosSheik(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstShulk", DetermineKos.DetermineKosShulk(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstSonic", DetermineKos.DetermineKosSonic(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstToonLink", DetermineKos.DetermineKosToonLink(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstVillager", DetermineKos.DetermineKosVillager(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstWario", DetermineKos.DetermineKosWario(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstWiiFit", DetermineKos.DetermineKosWiiFit(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstYoshi", DetermineKos.DetermineKosYoshi(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstZelda", DetermineKos.DetermineKosZelda(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@kosAgainstZeroSuit", DetermineKos.DetermineKosZeroSuit(P2Character, P2KosForP1, P3Character, P3KosForP1, P4Character, P4KosForP1));
                comm.Parameters.AddWithValue("@P1Character", p1Character);
            }

            try
            {
                conn.Open();

                strFeedBack = comm.ExecuteNonQuery().ToString() + "Battle Added.";
                conn.Close();
            }
            catch (Exception err)
            {
                strFeedBack = "ERROR: " + err.Message;
            }

            return strFeedBack;
        }


        public string AddBattlePlayer(string strID)
        {
            string feedBack = "";

           

            string strSQL = "UPDATE SSBPT Set Win+=@Wins , Loss+=@Losses , TotKos+=@TotKos , TotSDs+=@TotSDs WHERE User_ID=@UserID";

            SqlConnection conn = new SqlConnection();

            string strConn = ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;


            if (BattleOutCome == "Win")
            {
                comm.Parameters.AddWithValue("@Wins", +1);
                comm.Parameters.AddWithValue("@Losses", 0);
                comm.Parameters.AddWithValue("@TotKos", P1TotalKos);
                comm.Parameters.AddWithValue("@TotSDs", NumOfSds);
                comm.Parameters.AddWithValue("@UserID", strID);
            }

            else if (BattleOutCome == "Loss")
            {
                comm.Parameters.AddWithValue("@Wins", 0);
                comm.Parameters.AddWithValue("@Losses", +1);
                comm.Parameters.AddWithValue("@TotKos", P1TotalKos);
                comm.Parameters.AddWithValue("@TotSDs", NumOfSds);
                comm.Parameters.AddWithValue("@UserID", strID);
            }
            try
            {
                conn.Open();

                feedBack = comm.ExecuteNonQuery().ToString() + "Battle Added to Player Table" ;
                conn.Close();
            }
            catch (Exception err)
            {
                feedBack = "ERROR: " + err.Message;
            }

            return feedBack;
        }
        
    }
}
