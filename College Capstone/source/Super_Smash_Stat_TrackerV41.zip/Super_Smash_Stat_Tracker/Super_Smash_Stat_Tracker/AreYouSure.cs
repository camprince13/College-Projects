﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Super_Smash_Stat_Tracker
{
    public partial class AreYouSure : Form
    {
        public AreYouSure()
        {
            InitializeComponent();
        }

        UserName DeleteID = new UserName();

        private void AreYouSure_Load(object sender, EventArgs e)
        {
            label1.Text = "This will Perminently Delete your account \n and exit the program. \n\n Do you still wish to continue?";
        }

        private void btnYes_Click(object sender, EventArgs e)
        {
            UserRegistration temp = new UserRegistration();

            temp.DeleteUser(DeleteID.StrUserID);
            Environment.Exit(1);
        }

        private void btnNo_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
