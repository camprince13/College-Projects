﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using System.Text;

namespace Super_Smash_Stat_Tracker
{
    class Character_Portraits
    {
        //############################## End Smash64 character pics ########################
        
        public static string Portraits64(string tempCharacter)
        {
           string tempPlayerImg;

        if (tempCharacter == "Captain Falcon")
            {
                tempPlayerImg = "Smash64_CaptainFalcon.png";
            }
            else if (tempCharacter == "Donkey Kong")
            {
                tempPlayerImg = "Smash64_DonkeyKong.png";
            }
            else if (tempCharacter == "Fox")
            {
                tempPlayerImg = "Smash64_Fox.png";
            }
            else if (tempCharacter == "Jigglypuff")
            {
                tempPlayerImg = "Smash64_Jigglypuff.png";
            }
            else if (tempCharacter == "Kirby")
            {
                tempPlayerImg = "Smash64_Kirby.png";
            }
            else if (tempCharacter == "Link")
            {
                tempPlayerImg = "Smash64_Link.png";
            }
            else if (tempCharacter == "Luigi")
            {
                tempPlayerImg = "Smash64_Luigi.png";
            }
            else if (tempCharacter == "Mario")
            {
                tempPlayerImg = "Smash64_Mario.png";
            }
            else if (tempCharacter == "Ness")
            {
                tempPlayerImg = "Smash64_Ness.png";
            }
            else if (tempCharacter == "Pikachu")
            {
                tempPlayerImg = "Smash64_Pikachu.png";
            }
            else if (tempCharacter == "Samus")
            {
                tempPlayerImg = "Smash64_Samus.png";
            }
            else if (tempCharacter == "Yoshi")
            {
                tempPlayerImg = "Smash64_Yoshi.png";
            }
            else
            {
                tempPlayerImg = "";
            }

            return tempPlayerImg;
        }

        //############################## End Smash64 character pics ########################


        //############################## Start Melee character pics ########################
        public static string PortraitsMelee(string tempCharacter)
        {
            string tempPlayerImg;

            if (tempCharacter == "Bowser")
            {
                tempPlayerImg = "Ssbm_Bowser.png";
            }

            else if (tempCharacter == "Captain Falcon")
            {
                tempPlayerImg = "Ssbm_CaptainFalcon.png";
            }
            else if (tempCharacter == "Donkey Kong")
            {
                tempPlayerImg = "Ssbm_DonkeyKong.png";
            }
            else if (tempCharacter == "Dr.Mario")
            {
                tempPlayerImg = "Ssbm_DrMario.png";
            }
            else if (tempCharacter == "Falco")
            {
                tempPlayerImg = "Ssbm_Falco.png";
            }
            else if (tempCharacter == "Fox")
            {
                tempPlayerImg = "Ssbm_Fox.png";
            }
            else if (tempCharacter == "Ganondorf")
            {
                tempPlayerImg = "Ssbm_Ganondorf.png";
            }
            else if (tempCharacter == "Ice Climbers")
            {
                tempPlayerImg = "Ssbm_IceClimbers.png";
            }
            else if (tempCharacter == "Jigglypuff")
            {
                tempPlayerImg = "Ssbm_Jigglypuff.png";
            }
            else if (tempCharacter == "Kirby")
            {
                tempPlayerImg = "Ssbm_Kirby.png";
            }
            else if (tempCharacter == "Link")
            {
                tempPlayerImg = "Ssbm_Link.png";
            }
            else if (tempCharacter == "Luigi")
            {
                tempPlayerImg = "Ssbm_Luigi.png";
            }
            else if (tempCharacter == "Mario")
            {
                tempPlayerImg = "Ssbm_Mario.png";
            }
            else if (tempCharacter == "Marth")
            {
                tempPlayerImg = "Ssbm_Marth.png";
            }
            else if (tempCharacter == "Mewtwo")
            {
                tempPlayerImg = "Ssbm_Mewtwo.png";
            }
            else if (tempCharacter == "Mr. Game & Watch")
            {
                tempPlayerImg = "Ssbm_Game&Watch.png";
            }
            else if (tempCharacter == "Ness")
            {
                tempPlayerImg = "Ssbm_Ness.png";
            }
            else if (tempCharacter == "Peach")
            {
                tempPlayerImg = "Ssbm_Peach.png";
            }
            else if (tempCharacter == "Pichu")
            {
                tempPlayerImg = "Ssbm_Pichu.png";
            }
            else if (tempCharacter == "Pikachu")
            {
                tempPlayerImg = "Ssbm_Pikachu.png";
            }
            else if (tempCharacter == "Roy")
            {
                tempPlayerImg = "Ssbm_Roy.png";
            }
            else if (tempCharacter == "Samus")
            {
                tempPlayerImg = "Ssbm_Samus.png";
            }
            else if (tempCharacter == "Yoshi")
            {
                tempPlayerImg = "Ssbm_Yoshi.png";
            }
            else if (tempCharacter == "Young Link")
            {
                tempPlayerImg = "Ssbm_YoungLink.png";
            }
            else if (tempCharacter == "Zelda/Sheik")
            {
                tempPlayerImg = "Ssbm_Zelda.png";
            }
            else 
            {
                tempPlayerImg = "";
            }


            return tempPlayerImg;
        }

        //############################## End Melee character pics ########################



        //############################## Start Brawl character pics ########################
        public static string PortraitsBrawl(string tempCharacter)
        {
            string tempPlayerImg;

            if (tempCharacter == "Bowser")
            {
                tempPlayerImg = "Bowser.png";
            }
            else if (tempCharacter == "Captain Falcon")
            {
                tempPlayerImg = "CaptainFalcon.png";
            }
            else if (tempCharacter == "Diddy Kong")
            {
                tempPlayerImg = "DiddyKong.png";
            }
            else if (tempCharacter == "Donkey Kong")
            {
                tempPlayerImg = "DonkeyKong.png";
            }
            else if (tempCharacter == "Falco")
            {
                tempPlayerImg = "Falco.png";
            }
            else if (tempCharacter == "Fox")
            {
                tempPlayerImg = "Fox.png";
            }
            else if (tempCharacter == "Ganondorf")
            {
                tempPlayerImg = "Ganondorf.png";
            }
            else if (tempCharacter == "Ice Climbers")
            {
                tempPlayerImg = "IceClimbers.png";
            }
            else if (tempCharacter == "Ike")
            {
                tempPlayerImg = "Ike.png";
            }
            else if (tempCharacter == "Jigglypuff")
            {
                tempPlayerImg = "Jigglypuff.png";
            }
            else if (tempCharacter == "King Dedede")
            {
                tempPlayerImg = "KingDedede.png";
            }
            else if (tempCharacter == "Kirby")
            {
                tempPlayerImg = "Kirby.png";
            }
            else if (tempCharacter == "Link")
            {
                tempPlayerImg = "Link.png";
            }
            else if (tempCharacter == "Lucario")
            {
                tempPlayerImg = "Lucario.png";
            }
            else if (tempCharacter == "Lucas")
            {
                tempPlayerImg = "Lucas.png";
            }
            else if (tempCharacter == "Luigi")
            {
                tempPlayerImg = "Luigi.png";
            }
            else if (tempCharacter == "Mario")
            {
                tempPlayerImg = "Mario.png";
            }
            else if (tempCharacter == "Marth")
            {
                tempPlayerImg = "Marth.png";
            }
            else if (tempCharacter == "Metaknight")
            {
                tempPlayerImg = "MetaKnight.png";
            }
            else if (tempCharacter == "Mr. Game & Watch")
            {
                tempPlayerImg = "MrGameWatch.png";
            }
            else if (tempCharacter == "Ness")
            {
                tempPlayerImg = "Ness.png";
            }
            else if (tempCharacter == "Olimar")
            {
                tempPlayerImg = "Olimar.png";
            }
            else if (tempCharacter == "Peach")
            {
                tempPlayerImg = "Peach.png";
            }
            else if (tempCharacter == "Pikachu")
            {
                tempPlayerImg = "Pikachu.png";
            }
            else if (tempCharacter == "Pit")
            {
                tempPlayerImg = "Pit.png";
            }
            else if (tempCharacter == "Pokemon Trainer")
            {
                tempPlayerImg = "PokemonTrainer.png";
            }
            else if (tempCharacter == "R.O.B")
            {
                tempPlayerImg = "ROB.png";
            }
            else if (tempCharacter == "Samus/Zero Suit Samus")
            {
                tempPlayerImg = "Samus.png";
            }
            else if (tempCharacter == "Snake")
            {
                tempPlayerImg = "Snake.png";
            }
            else if (tempCharacter == "Sonic")
            {
                tempPlayerImg = "Sonic.png";
            }
            else if (tempCharacter == "Toon Link")
            {
                tempPlayerImg = "ToonLink.png";
            }
            else if (tempCharacter == "Wolf")
            {
                tempPlayerImg = "Wolf.png";
            }
            else if (tempCharacter == "Wario")
            {
                tempPlayerImg = "Wario.png";
            }
            else if (tempCharacter == "Yoshi")
            {
                tempPlayerImg = "Yoshi.png";
            }
            else if (tempCharacter == "Young Link")
            {
                tempPlayerImg = "YoungLink.png";
            }
            else if (tempCharacter == "Zelda/Sheik")
            {
                tempPlayerImg = "ZeldaSheik.png";
            }
            else
            {
                tempPlayerImg = "";
            }


            return tempPlayerImg;
        }

        //############################## End Brawl character pics ########################

        //############################## Start Smash4 character pics ########################
        public static string PortraitsSmash4(string tempCharacter)
        {
            string tempPlayerImg;

            if (tempCharacter == "Bowser")
            {
                tempPlayerImg = "Bowser.png";
            }
            else if (tempCharacter == "Bowser Jr.")
            {
                tempPlayerImg = "BowserJr.png";
            }
            else if (tempCharacter == "Captain Falcon")
            {
                tempPlayerImg = "CaptainFalcon.png";
            }
            else if (tempCharacter == "Charizard")
            {
                tempPlayerImg = "Charizard.png";
            }
            else if (tempCharacter == "Dark Pit")
            {
                tempPlayerImg = "DarkPit.png";
            }
            else if (tempCharacter == "Diddy Kong")
            {
                tempPlayerImg = "DiddyKong.png";
            }
            else if (tempCharacter == "Donkey Kong")
            {
                tempPlayerImg = "DonkeyKong.png";
            }
            else if (tempCharacter == "Dr. Mario")
            {
                tempPlayerImg = "DrMario.png";
            }
            else if (tempCharacter == "Duck Hunt")
            {
                tempPlayerImg = "DuckHunt.png";
            }
            else if (tempCharacter == "Falco")
            {
                tempPlayerImg = "Falco.png";
            }
            else if (tempCharacter == "Fox")
            {
                tempPlayerImg = "Fox.png";
            }
            else if (tempCharacter == "Ganondorf")
            {
                tempPlayerImg = "Ganondorf.png";
            }
            else if (tempCharacter == "Greninja")
            {
                tempPlayerImg = "Greninja.png";
            }
            else if (tempCharacter == "Ike")
            {
                tempPlayerImg = "Ike.png";
            }
            else if (tempCharacter == "Ike")
            {
                tempPlayerImg = "Ike.png";
            }
            else if (tempCharacter == "Jigglypuff")
            {
                tempPlayerImg = "Jigglypuff.png";
            }
            else if (tempCharacter == "King Dedede")
            {
                tempPlayerImg = "KingDedede.png";
            }
            else if (tempCharacter == "Kirby")
            {
                tempPlayerImg = "Kirby.png";
            }
            else if (tempCharacter == "Link")
            {
                tempPlayerImg = "Link.png";
            }
            else if (tempCharacter == "Little Mac")
            {
                tempPlayerImg = "LittleMac.png";
            }
            else if (tempCharacter == "Lucario")
            {
                tempPlayerImg = "Lucario.png";
            }
            else if (tempCharacter == "Lucina")
            {
                tempPlayerImg = "Lucina.png";
            }
            else if (tempCharacter == "Luigi")
            {
                tempPlayerImg = "Luigi.png";
            }
            else if (tempCharacter == "Mario")
            {
                tempPlayerImg = "Mario.png";
            }
            else if (tempCharacter == "Marth")
            {
                tempPlayerImg = "Marth.png";
            }
            else if (tempCharacter == "Mega Man")
            {
                tempPlayerImg = "MegaMan.png";
            }
            else if (tempCharacter == "Metaknight")
            {
                tempPlayerImg = "MetaKnight.png";
            }
            else if (tempCharacter == "Mr. Game & Watch")
            {
                tempPlayerImg = "MrGameWatch.png";
            }
            else if (tempCharacter == "Ness")
            {
                tempPlayerImg = "Ness.png";
            }
            else if (tempCharacter == "Olimar")
            {
                tempPlayerImg = "Olimar.png";
            }
            else if (tempCharacter == "Pac-Man")
            {
                tempPlayerImg = "PacMan.png";
            }
            else if (tempCharacter == "Palutena")
            {
                tempPlayerImg = "Palutena.png";
            }
            else if (tempCharacter == "Peach")
            {
                tempPlayerImg = "Peach.png";
            }
            else if (tempCharacter == "Pikachu")
            {
                tempPlayerImg = "Pikachu.png";
            }
            else if (tempCharacter == "Pit")
            {
                tempPlayerImg = "Pit.png";
            }
            else if (tempCharacter == "R.O.B")
            {
                tempPlayerImg = "ROB.png";
            }
            else if (tempCharacter == "Robin")
            {
                tempPlayerImg = "Robin.png";
            }
            else if (tempCharacter == "Rosalina & Luma")
            {
                tempPlayerImg = "Rosalina&Luma.png";
            }
            else if (tempCharacter == "Samus")
            {
                tempPlayerImg = "Samus.png";
            }
            else if (tempCharacter == "Sheik")
            {
                tempPlayerImg = "Sheik.png";
            }
            else if (tempCharacter == "Shulk")
            {
                tempPlayerImg = "Shulk.png";
            }
            else if (tempCharacter == "Sonic")
            {
                tempPlayerImg = "Sonic.png";
            }
            else if (tempCharacter == "Toon Link")
            {
                tempPlayerImg = "ToonLink.png";
            }
            else if (tempCharacter == "Villager")
            {
                tempPlayerImg = "Villager.png";
            }
            else if (tempCharacter == "Wario")
            {
                tempPlayerImg = "Wario.png";
            }
            else if (tempCharacter == "Wii Fit Trainer")
            {
                tempPlayerImg = "WiiFitTrainer.png";
            }
            else if (tempCharacter == "Yoshi")
            {
                tempPlayerImg = "Yoshi.png";
            }
            else if (tempCharacter == "Zelda")
            {
                tempPlayerImg = "Zelda.png";
            }
            else if (tempCharacter == "Zero Suit Samus")
            {
                tempPlayerImg = "ZeroSuit.png";
            }
            else
            {
                tempPlayerImg = "";
            }


            return tempPlayerImg;
        }

        //############################## End Smash4 character pics ########################
    }

    
}
