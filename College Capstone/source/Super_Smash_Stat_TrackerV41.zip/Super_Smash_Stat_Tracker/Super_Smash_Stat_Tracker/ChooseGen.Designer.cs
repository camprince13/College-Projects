﻿namespace Super_Smash_Stat_Tracker
{
    partial class ChooseGen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChooseGen));
            this.label1 = new System.Windows.Forms.Label();
            this.btnAddBattle64 = new System.Windows.Forms.Button();
            this.btnViewStat64 = new System.Windows.Forms.Button();
            this.btnViewMatchup64 = new System.Windows.Forms.Button();
            this.btnHelp3 = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnViewMatchupMelee = new System.Windows.Forms.Button();
            this.btnViewStatMelee = new System.Windows.Forms.Button();
            this.btnAddBattlesMelee = new System.Windows.Forms.Button();
            this.btnViewMatchupBrawl = new System.Windows.Forms.Button();
            this.btnViewStatBrawl = new System.Windows.Forms.Button();
            this.btnAddBattlesBrawl = new System.Windows.Forms.Button();
            this.btnbtnViewMatchup4 = new System.Windows.Forms.Button();
            this.btnViewStat4 = new System.Windows.Forms.Button();
            this.btnAddBattles4 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.lblUserName = new System.Windows.Forms.Label();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnPlayerStats = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(203, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(467, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "Choose your Generation!";
            // 
            // btnAddBattle64
            // 
            this.btnAddBattle64.Location = new System.Drawing.Point(79, 124);
            this.btnAddBattle64.Name = "btnAddBattle64";
            this.btnAddBattle64.Size = new System.Drawing.Size(75, 23);
            this.btnAddBattle64.TabIndex = 1;
            this.btnAddBattle64.Text = "Add Battles";
            this.btnAddBattle64.UseVisualStyleBackColor = true;
            this.btnAddBattle64.Click += new System.EventHandler(this.btnAddBattle64_Click);
            // 
            // btnViewStat64
            // 
            this.btnViewStat64.Location = new System.Drawing.Point(79, 166);
            this.btnViewStat64.Name = "btnViewStat64";
            this.btnViewStat64.Size = new System.Drawing.Size(75, 23);
            this.btnViewStat64.TabIndex = 2;
            this.btnViewStat64.Text = "View Stat";
            this.btnViewStat64.UseVisualStyleBackColor = true;
            this.btnViewStat64.Click += new System.EventHandler(this.btnViewStat64_Click);
            // 
            // btnViewMatchup64
            // 
            this.btnViewMatchup64.Location = new System.Drawing.Point(70, 210);
            this.btnViewMatchup64.Name = "btnViewMatchup64";
            this.btnViewMatchup64.Size = new System.Drawing.Size(92, 23);
            this.btnViewMatchup64.TabIndex = 3;
            this.btnViewMatchup64.Text = "View Matchup";
            this.btnViewMatchup64.UseVisualStyleBackColor = true;
            this.btnViewMatchup64.Click += new System.EventHandler(this.btnViewMatchup64_Click);
            // 
            // btnHelp3
            // 
            this.btnHelp3.Location = new System.Drawing.Point(-2, 362);
            this.btnHelp3.Name = "btnHelp3";
            this.btnHelp3.Size = new System.Drawing.Size(75, 23);
            this.btnHelp3.TabIndex = 4;
            this.btnHelp3.Text = "Help";
            this.btnHelp3.UseVisualStyleBackColor = true;
            this.btnHelp3.Click += new System.EventHandler(this.btnHelp3_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(799, 362);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnViewMatchupMelee
            // 
            this.btnViewMatchupMelee.Location = new System.Drawing.Point(270, 210);
            this.btnViewMatchupMelee.Name = "btnViewMatchupMelee";
            this.btnViewMatchupMelee.Size = new System.Drawing.Size(105, 23);
            this.btnViewMatchupMelee.TabIndex = 8;
            this.btnViewMatchupMelee.Text = "View Matchup";
            this.btnViewMatchupMelee.UseVisualStyleBackColor = true;
            this.btnViewMatchupMelee.Click += new System.EventHandler(this.btnViewMatchupMelee_Click);
            // 
            // btnViewStatMelee
            // 
            this.btnViewStatMelee.Location = new System.Drawing.Point(288, 166);
            this.btnViewStatMelee.Name = "btnViewStatMelee";
            this.btnViewStatMelee.Size = new System.Drawing.Size(75, 23);
            this.btnViewStatMelee.TabIndex = 7;
            this.btnViewStatMelee.Text = "View Stat";
            this.btnViewStatMelee.UseVisualStyleBackColor = true;
            this.btnViewStatMelee.Click += new System.EventHandler(this.btnViewStatMelee_Click);
            // 
            // btnAddBattlesMelee
            // 
            this.btnAddBattlesMelee.Location = new System.Drawing.Point(288, 124);
            this.btnAddBattlesMelee.Name = "btnAddBattlesMelee";
            this.btnAddBattlesMelee.Size = new System.Drawing.Size(75, 23);
            this.btnAddBattlesMelee.TabIndex = 6;
            this.btnAddBattlesMelee.Text = "Add Battles";
            this.btnAddBattlesMelee.UseVisualStyleBackColor = true;
            this.btnAddBattlesMelee.Click += new System.EventHandler(this.btnAddBattlesMelee_Click);
            // 
            // btnViewMatchupBrawl
            // 
            this.btnViewMatchupBrawl.Location = new System.Drawing.Point(483, 210);
            this.btnViewMatchupBrawl.Name = "btnViewMatchupBrawl";
            this.btnViewMatchupBrawl.Size = new System.Drawing.Size(104, 23);
            this.btnViewMatchupBrawl.TabIndex = 11;
            this.btnViewMatchupBrawl.Text = "View Matchup";
            this.btnViewMatchupBrawl.UseVisualStyleBackColor = true;
            this.btnViewMatchupBrawl.Click += new System.EventHandler(this.btnViewMatchupBrawl_Click);
            // 
            // btnViewStatBrawl
            // 
            this.btnViewStatBrawl.Location = new System.Drawing.Point(497, 166);
            this.btnViewStatBrawl.Name = "btnViewStatBrawl";
            this.btnViewStatBrawl.Size = new System.Drawing.Size(75, 23);
            this.btnViewStatBrawl.TabIndex = 10;
            this.btnViewStatBrawl.Text = "View Stat";
            this.btnViewStatBrawl.UseVisualStyleBackColor = true;
            this.btnViewStatBrawl.Click += new System.EventHandler(this.btnViewStatBrawl_Click);
            // 
            // btnAddBattlesBrawl
            // 
            this.btnAddBattlesBrawl.Location = new System.Drawing.Point(497, 124);
            this.btnAddBattlesBrawl.Name = "btnAddBattlesBrawl";
            this.btnAddBattlesBrawl.Size = new System.Drawing.Size(75, 23);
            this.btnAddBattlesBrawl.TabIndex = 9;
            this.btnAddBattlesBrawl.Text = "Add Battles";
            this.btnAddBattlesBrawl.UseVisualStyleBackColor = true;
            this.btnAddBattlesBrawl.Click += new System.EventHandler(this.btnAddBattlesBrawl_Click);
            // 
            // btnbtnViewMatchup4
            // 
            this.btnbtnViewMatchup4.Location = new System.Drawing.Point(695, 210);
            this.btnbtnViewMatchup4.Name = "btnbtnViewMatchup4";
            this.btnbtnViewMatchup4.Size = new System.Drawing.Size(101, 23);
            this.btnbtnViewMatchup4.TabIndex = 14;
            this.btnbtnViewMatchup4.Text = "View Matchup";
            this.btnbtnViewMatchup4.UseVisualStyleBackColor = true;
            this.btnbtnViewMatchup4.Click += new System.EventHandler(this.btnbtnViewMatchup4_Click);
            // 
            // btnViewStat4
            // 
            this.btnViewStat4.Location = new System.Drawing.Point(706, 166);
            this.btnViewStat4.Name = "btnViewStat4";
            this.btnViewStat4.Size = new System.Drawing.Size(75, 23);
            this.btnViewStat4.TabIndex = 13;
            this.btnViewStat4.Text = "View Stat";
            this.btnViewStat4.UseVisualStyleBackColor = true;
            this.btnViewStat4.Click += new System.EventHandler(this.btnViewStat4_Click);
            // 
            // btnAddBattles4
            // 
            this.btnAddBattles4.Location = new System.Drawing.Point(706, 124);
            this.btnAddBattles4.Name = "btnAddBattles4";
            this.btnAddBattles4.Size = new System.Drawing.Size(75, 23);
            this.btnAddBattles4.TabIndex = 12;
            this.btnAddBattles4.Text = "Add Battles";
            this.btnAddBattles4.UseVisualStyleBackColor = true;
            this.btnAddBattles4.Click += new System.EventHandler(this.btnAddBattles4_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(24, 60);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(182, 58);
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(229, 60);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(200, 58);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 16;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(452, 60);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(180, 58);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 17;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(655, 60);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(182, 58);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox4.TabIndex = 18;
            this.pictureBox4.TabStop = false;
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.BackColor = System.Drawing.Color.Transparent;
            this.lblUserName.ForeColor = System.Drawing.Color.White;
            this.lblUserName.Location = new System.Drawing.Point(688, 15);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(0, 13);
            this.lblUserName.TabIndex = 19;
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(775, 5);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(99, 23);
            this.btnEdit.TabIndex = 20;
            this.btnEdit.Text = "Edit Account";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnPlayerStats
            // 
            this.btnPlayerStats.Location = new System.Drawing.Point(786, 30);
            this.btnPlayerStats.Name = "btnPlayerStats";
            this.btnPlayerStats.Size = new System.Drawing.Size(75, 23);
            this.btnPlayerStats.TabIndex = 21;
            this.btnPlayerStats.Text = "Player Stats";
            this.btnPlayerStats.UseVisualStyleBackColor = true;
            this.btnPlayerStats.Click += new System.EventHandler(this.btnPlayerStats_Click);
            // 
            // ChooseGen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(873, 384);
            this.Controls.Add(this.btnPlayerStats);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.lblUserName);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnbtnViewMatchup4);
            this.Controls.Add(this.btnViewStat4);
            this.Controls.Add(this.btnAddBattles4);
            this.Controls.Add(this.btnViewMatchupBrawl);
            this.Controls.Add(this.btnViewStatBrawl);
            this.Controls.Add(this.btnAddBattlesBrawl);
            this.Controls.Add(this.btnViewMatchupMelee);
            this.Controls.Add(this.btnViewStatMelee);
            this.Controls.Add(this.btnAddBattlesMelee);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnHelp3);
            this.Controls.Add(this.btnViewMatchup64);
            this.Controls.Add(this.btnViewStat64);
            this.Controls.Add(this.btnAddBattle64);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ChooseGen";
            this.Text = "ChooseGen";
            this.Load += new System.EventHandler(this.ChooseGen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAddBattle64;
        private System.Windows.Forms.Button btnViewStat64;
        private System.Windows.Forms.Button btnViewMatchup64;
        private System.Windows.Forms.Button btnHelp3;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnViewMatchupMelee;
        private System.Windows.Forms.Button btnViewStatMelee;
        private System.Windows.Forms.Button btnAddBattlesMelee;
        private System.Windows.Forms.Button btnViewMatchupBrawl;
        private System.Windows.Forms.Button btnViewStatBrawl;
        private System.Windows.Forms.Button btnAddBattlesBrawl;
        private System.Windows.Forms.Button btnbtnViewMatchup4;
        private System.Windows.Forms.Button btnViewStat4;
        private System.Windows.Forms.Button btnAddBattles4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        public System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnPlayerStats;
    }
}