﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Media;

namespace Super_Smash_Stat_Tracker
{
    public partial class ChooseGen : Form
    {
        public ChooseGen()
        {
            InitializeComponent();
        }

        public UserName IDGen;

        //Main Sound

        //boop

        private void ChooseGen_Load(object sender, EventArgs e)
        {
             lblUserName.Text = "User ID: " + IDGen.StrUserID;
             MiscFunc.ChooseSou(5);//player.PlayLooping();
        }

        

        private void btnExit_Click(object sender, EventArgs e)
        {
            MiscFunc.ChooseSou(0);
            this.Close();
        }

        private void btnViewMatchupMelee_Click(object sender, EventArgs e)
        {
            MatchUpMelee temp = new MatchUpMelee();

            temp.Show();
        }

        private void btnAddBattle64_Click(object sender, EventArgs e)
        {
            MiscFunc.boop(5);
            AddBattle64 temp = new AddBattle64();
            temp.IDSmash64 = IDGen;
            temp.Show();
        }

        private void btnViewStat64_Click(object sender, EventArgs e)
        {
            ViewStats64 temp = new ViewStats64();
            temp.Show();
        }

        private void btnViewMatchup64_Click(object sender, EventArgs e)
        {
            MatchUp64 temp = new MatchUp64();
            temp.Show();
        }

        private void btnAddBattlesMelee_Click(object sender, EventArgs e)
        {
            MiscFunc.boop(5);
            AddBattleMelee temp = new AddBattleMelee();
            temp.IDMelee = IDGen;
            temp.Show();
        }

        private void btnViewStatMelee_Click(object sender, EventArgs e)
        {
            ViewStatsMelee temp = new ViewStatsMelee();
            temp.Show();
        }

        private void btnAddBattlesBrawl_Click(object sender, EventArgs e)
        {
            MiscFunc.boop(5);
            AddBattleBrawl temp = new AddBattleBrawl();
            temp.IDBrawl = IDGen;
            temp.Show();
        }

        private void btnViewStatBrawl_Click(object sender, EventArgs e)
        {
            ViewStatsBrawl temp = new ViewStatsBrawl();
            temp.Show();
        }

        private void btnViewMatchupBrawl_Click(object sender, EventArgs e)
        {
            MatchUpBrawl temp = new MatchUpBrawl();
            temp.Show();
        }

        private void btnAddBattles4_Click(object sender, EventArgs e)
        {
            MiscFunc.boop(5);
            AddBattleSmash4 temp = new AddBattleSmash4();
            temp.IDSmash4 = IDGen;
            temp.Show();
        }

        private void btnViewStat4_Click(object sender, EventArgs e)
        {
            ViewStatsSmash4 temp = new ViewStatsSmash4();
            temp.Show();
        }

        private void btnbtnViewMatchup4_Click(object sender, EventArgs e)
        {
            MatchUpSmash4 temp = new MatchUpSmash4();
            temp.Show();
        }

        private void btnHelp3_Click(object sender, EventArgs e)
        {
            //player.Stop();//Had problem with on exit, on help button for now 
            MiscFunc.openwiki(7);
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            Edit temp = new Edit();
            temp.EditID = IDGen;
            temp.Show();

        }

        private void btnPlayerStats_Click(object sender, EventArgs e)
        {
            PlayerStats temp = new PlayerStats();
            temp.PlayerID = IDGen;
            temp.Show();
        }

        

        //static void OnProcessExit(object sender, EventArgs e)
        //{
        //   player.Stop();
        //}

        
        
        
    }
}
