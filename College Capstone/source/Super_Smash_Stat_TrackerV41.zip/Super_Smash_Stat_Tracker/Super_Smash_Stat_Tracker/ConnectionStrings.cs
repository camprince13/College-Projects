﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Super_Smash_Stat_Tracker
{
    class ConnectionStrings
    {

        public static string ConnectionToUserDatabase()
        {
                        return  "Server=sql.neit.edu;Database=SE255_CPrince;User Id=SE255_CPrince;Password=001295039;";
                
        }

       


    }
}
