﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Super_Smash_Stat_Tracker
{
    public partial class CreateAnAccount : Form
    {
        public CreateAnAccount()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            UserRegistration newUser = new UserRegistration();

            newUser.UserName = txtUserNameRegi.Text;
            newUser.Password = txtPasswordRegi.Text;
            newUser.ReEnteredPass = txtPassword2Regi.Text;

            if (newUser.FeedBack.Contains("ERROR:"))
            {
                lblFeedBack.Text = newUser.FeedBack;
            }
            else if (txtPasswordRegi.Text != txtPassword2Regi.Text)
            {
                lblFeedBack.Text = "ERROR: Re-Entered password does not match original.";
            }
            else
            {
                lblFeedBack.Text = newUser.CreateAccount();
                btnCreate.Enabled = false;
            }
            
                
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnHelp2_Click(object sender, EventArgs e)
        {
            MiscFunc.openwiki(7);
        }

        
    }
}
