﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Super_Smash_Stat_Tracker
{
    class DetermineKos
    {
        //################################# Start Mega Man determination ############################################
        public static int DetermineKosBowser(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstBowser = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Bowser" || p3Character == "Bowser" || p4Character == "Bowser")
            {
                if (p2Character == "Bowser" && p3Character != "Bowser" && p4Character != "Bowser")
                {
                    kosAgainstBowser = p2NumOfKosForP1;
                }
                else if (p2Character != "Bowser" && p3Character == "Bowser" && p4Character != "Bowser")
                {
                    kosAgainstBowser = p3NumOfKosForP1;
                }
                else if (p2Character != "Bowser" && p3Character != "Bowser" && p4Character == "Bowser")
                {
                    kosAgainstBowser = p4NumOfKosForP1;
                }
                else if (p2Character == "Bowser" && p3Character == "Bowser" && p4Character != "Bowser")
                {
                    kosAgainstBowser = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Bowser" && p3Character != "Bowser" && p4Character == "Bowser")
                {
                    kosAgainstBowser = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Bowser" && p3Character == "Bowser" && p4Character == "Bowser")
                {
                    kosAgainstBowser = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Bowser" && p3Character == "Bowser" && p4Character == "Bowser")
                {
                    kosAgainstBowser = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstBowser;

        }

        //################################# End Bowser determination ############################################


        //################################# Start Bowser Jr. determination ############################################
        public static int DetermineKosBowserJr(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstBowserJr = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Bowser Jr." || p3Character == "Bowser Jr." || p4Character == "Bowser Jr.")
            {
                if (p2Character == "Bowser Jr." && p3Character != "Bowser Jr." && p4Character != "Bowser Jr.")
                {
                    kosAgainstBowserJr = p2NumOfKosForP1;
                }
                else if (p2Character != "Bowser Jr." && p3Character == "Bowser Jr." && p4Character != "Bowser Jr.")
                {
                    kosAgainstBowserJr = p3NumOfKosForP1;
                }
                else if (p2Character != "Bowser Jr." && p3Character != "Bowser Jr." && p4Character == "Bowser Jr.")
                {
                    kosAgainstBowserJr = p4NumOfKosForP1;
                }
                else if (p2Character == "Bowser Jr." && p3Character == "Bowser Jr." && p4Character != "Bowser Jr.")
                {
                    kosAgainstBowserJr = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Bowser Jr." && p3Character != "Bowser Jr." && p4Character == "Bowser Jr.")
                {
                    kosAgainstBowserJr = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Bowser Jr." && p3Character == "Bowser Jr." && p4Character == "Bowser Jr.")
                {
                    kosAgainstBowserJr = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Bowser Jr." && p3Character == "Bowser Jr." && p4Character == "Bowser Jr.")
                {
                    kosAgainstBowserJr = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstBowserJr;

        }

        //################################# End Bowser Jr. determination ############################################



        //################################# Start Captian Falcon determination ############################################
        public static int DetermineKosCF(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstCF = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Captain Falcon" || p3Character == "Captain Falcon" || p4Character == "Captain Falcon")
            {
                if (p2Character == "Captain Falcon" && p3Character != "Captain Falcon" && p4Character != "Captain Falcon")
                {
                    kosAgainstCF = p2NumOfKosForP1;
                }
                else if (p2Character != "Captain Falcon" && p3Character == "Captain Falcon" && p4Character != "Captain Falcon")
                {
                    kosAgainstCF = p3NumOfKosForP1;
                }
                else if (p2Character != "Captain Falcon" && p3Character != "Captain Falcon" && p4Character == "Captain Falcon")
                {
                    kosAgainstCF = p4NumOfKosForP1;
                }
                else if (p2Character == "Captain Falcon" && p3Character == "Captain Falcon" && p4Character != "Captain Falcon")
                {
                    kosAgainstCF = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Captain Falcon" && p3Character != "Captain Falcon" && p4Character == "Captain Falcon")
                {
                    kosAgainstCF = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Captain Falcon" && p3Character == "Captain Falcon" && p4Character == "Captain Falcon")
                {
                    kosAgainstCF = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Captain Falcon" && p3Character == "Captain Falcon" && p4Character == "Captain Falcon")
                {
                    kosAgainstCF = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

  

            return kosAgainstCF;

        }

        //################################# End Captian Falcon determination ############################################



        //################################# Start Charizard determination ############################################
        public static int DetermineKosCharizard(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstCharizard = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Charizard" || p3Character == "Charizard" || p4Character == "Charizard")
            {
                if (p2Character == "Charizard" && p3Character != "Charizard" && p4Character != "Charizard")
                {
                    kosAgainstCharizard = p2NumOfKosForP1;
                }
                else if (p2Character != "Charizard" && p3Character == "Charizard" && p4Character != "Charizard")
                {
                    kosAgainstCharizard = p3NumOfKosForP1;
                }
                else if (p2Character != "Charizard" && p3Character != "Charizard" && p4Character == "Charizard")
                {
                    kosAgainstCharizard = p4NumOfKosForP1;
                }
                else if (p2Character == "Charizard" && p3Character == "Charizard" && p4Character != "Charizard")
                {
                    kosAgainstCharizard = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Charizard" && p3Character != "Charizard" && p4Character == "Charizard")
                {
                    kosAgainstCharizard = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Charizard" && p3Character == "Charizard" && p4Character == "Charizard")
                {
                    kosAgainstCharizard = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Charizard" && p3Character == "Charizard" && p4Character == "Charizard")
                {
                    kosAgainstCharizard = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstCharizard;

        }

        //################################# End Charizard determination ############################################



        //################################# Start Dark Pit determination ############################################
        public static int DetermineKosDarkPit(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstDarkPit = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Dark Pit" || p3Character == "Dark Pit" || p4Character == "Dark Pit")
            {
                if (p2Character == "Dark Pit" && p3Character != "Dark Pit" && p4Character != "Dark Pit")
                {
                    kosAgainstDarkPit = p2NumOfKosForP1;
                }
                else if (p2Character != "Dark Pit" && p3Character == "Dark Pit" && p4Character != "Dark Pit")
                {
                    kosAgainstDarkPit = p3NumOfKosForP1;
                }
                else if (p2Character != "Dark Pit" && p3Character != "Dark Pit" && p4Character == "Dark Pit")
                {
                    kosAgainstDarkPit = p4NumOfKosForP1;
                }
                else if (p2Character == "Dark Pit" && p3Character == "Dark Pit" && p4Character != "Dark Pit")
                {
                    kosAgainstDarkPit = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Dark Pit" && p3Character != "Dark Pit" && p4Character == "Dark Pit")
                {
                    kosAgainstDarkPit = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Dark Pit" && p3Character == "Dark Pit" && p4Character == "Dark Pit")
                {
                    kosAgainstDarkPit = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Dark Pit" && p3Character == "Dark Pit" && p4Character == "Dark Pit")
                {
                    kosAgainstDarkPit = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstDarkPit;

        }

        //################################# End Dark Pit determination ############################################



        //################################# Start DiddyKong determination ############################################
        public static int DetermineKosDiddyKong(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstDiddy = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Diddy Kong" || p3Character == "Diddy Kong" || p4Character == "Diddy Kong")
            {
                if (p2Character == "Diddy Kong" && p3Character != "Diddy Kong" && p4Character != "Diddy Kong")
                {
                    kosAgainstDiddy = p2NumOfKosForP1;
                }
                else if (p2Character != "Diddy Kong" && p3Character == "Diddy Kong" && p4Character != "Diddy Kong")
                {
                    kosAgainstDiddy = p3NumOfKosForP1;
                }
                else if (p2Character != "Diddy Kong" && p3Character != "Diddy Kong" && p4Character == "Diddy Kong")
                {
                    kosAgainstDiddy = p4NumOfKosForP1;
                }
                else if (p2Character == "Diddy Kong" && p3Character == "Diddy Kong" && p4Character != "Diddy Kong")
                {
                    kosAgainstDiddy = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Diddy Kong" && p3Character != "Diddy Kong" && p4Character == "Diddy Kong")
                {
                    kosAgainstDiddy = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Diddy Kong" && p3Character == "Diddy Kong" && p4Character == "Diddy Kong")
                {
                    kosAgainstDiddy = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Diddy Kong" && p3Character == "Diddy Kong" && p4Character == "Diddy Kong")
                {
                    kosAgainstDiddy = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstDiddy;

        }

        //################################# End Diddy Kong determination ############################################



        //################################# Start Donkey Kong determination ############################################
        public static int DetermineKosDk(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstDK = 0;
            

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            

            if (p2Character == "Donkey Kong" || p3Character == "Donkey Kong" || p4Character == "Donkey Kong")
            {
                if (p2Character == "Donkey Kong" && p3Character != "Donkey Kong" && p4Character != "Donkey Kong")
                {
                    kosAgainstDK = p2NumOfKosForP1;
                }
                else if (p2Character != "Donkey Kong" && p3Character == "Donkey Kong" && p4Character != "Donkey Kong")
                {
                    kosAgainstDK = p3NumOfKosForP1;
                }
                else if (p2Character != "Donkey Kong" && p3Character != "Donkey Kong" && p4Character == "Donkey Kong")
                {
                    kosAgainstDK = p4NumOfKosForP1;
                }
                else if (p2Character == "Donkey Kong" && p3Character == "Donkey Kong" && p4Character != "Donkey Kong")
                {
                    kosAgainstDK = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Donkey Kong" && p3Character != "Donkey Kong" && p4Character == "Donkey Kong")
                {
                    kosAgainstDK = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Donkey Kong" && p3Character == "Donkey Kong" && p4Character == "Donkey Kong")
                {
                    kosAgainstDK = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Donkey Kong" && p3Character == "Donkey Kong" && p4Character == "Donkey Kong")
                {
                    kosAgainstDK = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstDK;

        }

        //################################# End Donkey Kong determination ############################################



        //################################# Start Dr. Mario determination ############################################
        public static int DetermineKosDrMario(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstDrMario = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Dr.Mario" || p3Character == "Dr.Mario" || p4Character == "Dr.Mario")
            {
                if (p2Character == "Dr.Mario" && p3Character != "Dr.Mario" && p4Character != "Dr.Mario")
                {
                    kosAgainstDrMario = p2NumOfKosForP1;
                }
                else if (p2Character != "Dr.Mario" && p3Character == "Dr.Mario" && p4Character != "Dr.Mario")
                {
                    kosAgainstDrMario = p3NumOfKosForP1;
                }
                else if (p2Character != "Dr.Mario" && p3Character != "Dr.Mario" && p4Character == "Dr.Mario")
                {
                    kosAgainstDrMario = p4NumOfKosForP1;
                }
                else if (p2Character == "Dr.Mario" && p3Character == "Dr.Mario" && p4Character != "Dr.Mario")
                {
                    kosAgainstDrMario = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Dr.Mario" && p3Character != "Dr.Mario" && p4Character == "Dr.Mario")
                {
                    kosAgainstDrMario = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Dr.Mario" && p3Character == "Dr.Mario" && p4Character == "Dr.Mario")
                {
                    kosAgainstDrMario = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Dr.Mario" && p3Character == "Dr.Mario" && p4Character == "Dr.Mario")
                {
                    kosAgainstDrMario = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstDrMario;

        }

        //################################# End Dr.Mario determination ############################################



        //################################# Start Duck Hunt determination ############################################
        public static int DetermineKosDuckHunt(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstDuckHunt = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Duck Hunt" || p3Character == "Duck Hunt" || p4Character == "Duck Hunt")
            {
                if (p2Character == "Duck Hunt" && p3Character != "Duck Hunt" && p4Character != "Duck Hunt")
                {
                    kosAgainstDuckHunt = p2NumOfKosForP1;
                }
                else if (p2Character != "Duck Hunt" && p3Character == "Duck Hunt" && p4Character != "Duck Hunt")
                {
                    kosAgainstDuckHunt = p3NumOfKosForP1;
                }
                else if (p2Character != "Duck Hunt" && p3Character != "Duck Hunt" && p4Character == "Duck Hunt")
                {
                    kosAgainstDuckHunt = p4NumOfKosForP1;
                }
                else if (p2Character == "Duck Hunt" && p3Character == "Duck Hunt" && p4Character != "Duck Hunt")
                {
                    kosAgainstDuckHunt = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Duck Hunt" && p3Character != "Duck Hunt" && p4Character == "Duck Hunt")
                {
                    kosAgainstDuckHunt = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Duck Hunt" && p3Character == "Duck Hunt" && p4Character == "Duck Hunt")
                {
                    kosAgainstDuckHunt = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Duck Hunt" && p3Character == "Duck Hunt" && p4Character == "Duck Hunt")
                {
                    kosAgainstDuckHunt = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstDuckHunt;

        }

        //################################# End Duck Hunt determination ############################################



        //################################# Start Falco determination ############################################
        public static int DetermineKosFalco(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstFalco = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Falco" || p3Character == "Falco" || p4Character == "Falco")
            {
                if (p2Character == "Falco" && p3Character != "Falco" && p4Character != "Falco")
                {
                    kosAgainstFalco = p2NumOfKosForP1;
                }
                else if (p2Character != "Falco" && p3Character == "Falco" && p4Character != "Falco")
                {
                    kosAgainstFalco = p3NumOfKosForP1;
                }
                else if (p2Character != "Falco" && p3Character != "Falco" && p4Character == "Falco")
                {
                    kosAgainstFalco = p4NumOfKosForP1;
                }
                else if (p2Character == "Falco" && p3Character == "Falco" && p4Character != "Falco")
                {
                    kosAgainstFalco = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Falco" && p3Character != "Falco" && p4Character == "Falco")
                {
                    kosAgainstFalco = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Falco" && p3Character == "Falco" && p4Character == "Falco")
                {
                    kosAgainstFalco = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Falco" && p3Character == "Falco" && p4Character == "Falco")
                {
                    kosAgainstFalco = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstFalco;

        }

        //################################# End Falco determination ############################################



        //################################# Start Fox determination ############################################
        public static int DetermineKosFox(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstFox = 0;
            

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Fox" || p3Character == "Fox" || p4Character == "Fox")
            {
                if (p2Character == "Fox" && p3Character != "Fox" && p4Character != "Fox")
                {
                    kosAgainstFox = p2NumOfKosForP1;
                }
                else if (p2Character != "Fox" && p3Character == "Fox" && p4Character != "Fox")
                {
                    kosAgainstFox = p3NumOfKosForP1;
                }
                else if (p2Character != "Fox" && p3Character != "Fox" && p4Character == "Fox")
                {
                    kosAgainstFox = p4NumOfKosForP1;
                }
                else if (p2Character == "Fox" && p3Character == "Fox" && p4Character != "Fox")
                {
                    kosAgainstFox = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Fox" && p3Character != "Fox" && p4Character == "Fox")
                {
                    kosAgainstFox = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Fox" && p3Character == "Fox" && p4Character == "Fox")
                {
                    kosAgainstFox = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Fox" && p3Character == "Fox" && p4Character == "Fox")
                {
                    kosAgainstFox = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstFox;

        }

        //################################# End Fox determination ############################################



        //################################# Start Ganon determination ############################################
        public static int DetermineKosGanon(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstGanon = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Ganondorf" || p3Character == "Ganondorf" || p4Character == "Ganondorf")
            {
                if (p2Character == "Ganondorf" && p3Character != "Ganondorf" && p4Character != "Ganondorf")
                {
                    kosAgainstGanon = p2NumOfKosForP1;
                }
                else if (p2Character != "Ganondorf" && p3Character == "Ganondorf" && p4Character != "Ganondorf")
                {
                    kosAgainstGanon = p3NumOfKosForP1;
                }
                else if (p2Character != "Ganondorf" && p3Character != "Ganondorf" && p4Character == "Ganondorf")
                {
                    kosAgainstGanon = p4NumOfKosForP1;
                }
                else if (p2Character == "Ganondorf" && p3Character == "Ganondorf" && p4Character != "Ganondorf")
                {
                    kosAgainstGanon = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Ganondorf" && p3Character != "Ganondorf" && p4Character == "Ganondorf")
                {
                    kosAgainstGanon = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Ganondorf" && p3Character == "Ganondorf" && p4Character == "Ganondorf")
                {
                    kosAgainstGanon = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Ganondorf" && p3Character == "Ganondorf" && p4Character == "Ganondorf")
                {
                    kosAgainstGanon = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstGanon;

        }

        //################################# End Ganondorf determination ############################################



        //################################# Start Greninja determination ############################################
        public static int DetermineKosGreninja(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstGreninja = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Greninja" || p3Character == "Greninja" || p4Character == "Greninja")
            {
                if (p2Character == "Greninja" && p3Character != "Greninja" && p4Character != "Greninja")
                {
                    kosAgainstGreninja = p2NumOfKosForP1;
                }
                else if (p2Character != "Greninja" && p3Character == "Greninja" && p4Character != "Greninja")
                {
                    kosAgainstGreninja = p3NumOfKosForP1;
                }
                else if (p2Character != "Greninja" && p3Character != "Greninja" && p4Character == "Greninja")
                {
                    kosAgainstGreninja = p4NumOfKosForP1;
                }
                else if (p2Character == "Greninja" && p3Character == "Greninja" && p4Character != "Greninja")
                {
                    kosAgainstGreninja = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Greninja" && p3Character != "Greninja" && p4Character == "Greninja")
                {
                    kosAgainstGreninja = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Greninja" && p3Character == "Greninja" && p4Character == "Greninja")
                {
                    kosAgainstGreninja = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Greninja" && p3Character == "Greninja" && p4Character == "Greninja")
                {
                    kosAgainstGreninja = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstGreninja;

        }

        //################################# End Greninja determination ############################################



        //################################# Start Ice Climbers determination ############################################
        public static int DetermineKosIce(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstIce = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Ice Climbers" || p3Character == "Ice Climbers" || p4Character == "Ice Climbers")
            {
                if (p2Character == "Ice Climbers" && p3Character != "Ice Climbers" && p4Character != "Ice Climbers")
                {
                    kosAgainstIce = p2NumOfKosForP1;
                }
                else if (p2Character != "Ice Climbers" && p3Character == "Ice Climbers" && p4Character != "Ice Climbers")
                {
                    kosAgainstIce = p3NumOfKosForP1;
                }
                else if (p2Character != "Ice Climbers" && p3Character != "Ice Climbers" && p4Character == "Ice Climbers")
                {
                    kosAgainstIce = p4NumOfKosForP1;
                }
                else if (p2Character == "Ice Climbers" && p3Character == "Ice Climbers" && p4Character != "Ice Climbers")
                {
                    kosAgainstIce = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Ice Climbers" && p3Character != "Ice Climbers" && p4Character == "Ice Climbers")
                {
                    kosAgainstIce = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Ice Climbers" && p3Character == "Ice Climbers" && p4Character == "Ice Climbers")
                {
                    kosAgainstIce = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Ice Climbers" && p3Character == "Ice Climbers" && p4Character == "Ice Climbers")
                {
                    kosAgainstIce = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstIce;

        }

        //################################# End Ice Climbers determination ############################################



        //################################# Start Ike determination ############################################
        public static int DetermineKosIke(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstIke = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Ike" || p3Character == "Ike" || p4Character == "Ike")
            {
                if (p2Character == "Ike" && p3Character != "Ike" && p4Character != "Ike")
                {
                    kosAgainstIke = p2NumOfKosForP1;
                }
                else if (p2Character != "Ike" && p3Character == "Ike" && p4Character != "Ike")
                {
                    kosAgainstIke = p3NumOfKosForP1;
                }
                else if (p2Character != "Ike" && p3Character != "Ike" && p4Character == "Ike")
                {
                    kosAgainstIke = p4NumOfKosForP1;
                }
                else if (p2Character == "Ike" && p3Character == "Ike" && p4Character != "Ike")
                {
                    kosAgainstIke = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Ike" && p3Character != "Ike" && p4Character == "Ike")
                {
                    kosAgainstIke = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Ike" && p3Character == "Ike" && p4Character == "Ike")
                {
                    kosAgainstIke = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Ike" && p3Character == "Ike" && p4Character == "Ike")
                {
                    kosAgainstIke = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstIke;

        }

        //################################# End Ike determination ############################################



        //################################# Start Puff determination ############################################
        public static int DetermineKosJP(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstPuff = 0;
            

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Jigglypuff" || p3Character == "Jigglypuff" || p4Character == "Jigglypuff")
            {
                if (p2Character == "Jigglypuff" && p3Character != "Jigglypuff" && p4Character != "Jigglypuff")
                {
                    kosAgainstPuff = p2NumOfKosForP1;
                }
                else if (p2Character != "Jigglypuff" && p3Character == "Jigglypuff" && p4Character != "Jigglypuff")
                {
                    kosAgainstPuff = p3NumOfKosForP1;
                }
                else if (p2Character != "Jigglypuff" && p3Character != "Jigglypuff" && p4Character == "Jigglypuff")
                {
                    kosAgainstPuff = p4NumOfKosForP1;
                }
                else if (p2Character == "Jigglypuff" && p3Character == "Jigglypuff" && p4Character != "Jigglypuff")
                {
                    kosAgainstPuff = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Jigglypuff" && p3Character != "Jigglypuff" && p4Character == "Jigglypuff")
                {
                    kosAgainstPuff = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Jigglypuff" && p3Character == "Jigglypuff" && p4Character == "Jigglypuff")
                {
                    kosAgainstPuff = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Jigglypuff" && p3Character == "Jigglypuff" && p4Character == "Jigglypuff")
                {
                    kosAgainstPuff = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstPuff;

        }

        //################################# End Puff determination ############################################



        //################################# Start King Dedede determination ############################################
        public static int DetermineKosDedede(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstDedede = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "King Dedede" || p3Character == "King Dedede" || p4Character == "King Dedede")
            {
                if (p2Character == "King Dedede" && p3Character != "King Dedede" && p4Character != "King Dedede")
                {
                    kosAgainstDedede = p2NumOfKosForP1;
                }
                else if (p2Character != "King Dedede" && p3Character == "King Dedede" && p4Character != "King Dedede")
                {
                    kosAgainstDedede = p3NumOfKosForP1;
                }
                else if (p2Character != "King Dedede" && p3Character != "King Dedede" && p4Character == "King Dedede")
                {
                    kosAgainstDedede = p4NumOfKosForP1;
                }
                else if (p2Character == "King Dedede" && p3Character == "King Dedede" && p4Character != "King Dedede")
                {
                    kosAgainstDedede = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "King Dedede" && p3Character != "King Dedede" && p4Character == "King Dedede")
                {
                    kosAgainstDedede = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "King Dedede" && p3Character == "King Dedede" && p4Character == "King Dedede")
                {
                    kosAgainstDedede = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "King Dedede" && p3Character == "King Dedede" && p4Character == "King Dedede")
                {
                    kosAgainstDedede = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstDedede;

        }

        //################################# End King Dedede determination ############################################

        //################################# Start Kirby determination ############################################
        public static int DetermineKosKirby(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstKirby = 0;
            

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Kirby" || p3Character == "Kirby" || p4Character == "Kirby")
            {
                if (p2Character == "Kirby" && p3Character != "Kirby" && p4Character != "Kirby")
                {
                    kosAgainstKirby = p2NumOfKosForP1;
                }
                else if (p2Character != "Kirby" && p3Character == "Kirby" && p4Character != "Kirby")
                {
                    kosAgainstKirby = p3NumOfKosForP1;
                }
                else if (p2Character != "Kirby" && p3Character != "Kirby" && p4Character == "Kirby")
                {
                    kosAgainstKirby = p4NumOfKosForP1;
                }
                else if (p2Character == "Kirby" && p3Character == "Kirby" && p4Character != "Kirby")
                {
                    kosAgainstKirby = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Kirby" && p3Character != "Kirby" && p4Character == "Kirby")
                {
                    kosAgainstKirby = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Kirby" && p3Character == "Kirby" && p4Character == "Kirby")
                {
                    kosAgainstKirby = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Kirby" && p3Character == "Kirby" && p4Character == "Kirby")
                {
                    kosAgainstKirby = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstKirby;

        }

        //################################# End Kirby determination ############################################



        //################################# Start Link determination ############################################
        public static int DetermineKosLink(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstLink = 0;
            

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Link" || p3Character == "Link" || p4Character == "Link")
            {
                if (p2Character == "Link" && p3Character != "Link" && p4Character != "Link")
                {
                    kosAgainstLink = p2NumOfKosForP1;
                }
                else if (p2Character != "Link" && p3Character == "Link" && p4Character != "Link")
                {
                    kosAgainstLink = p3NumOfKosForP1;
                }
                else if (p2Character != "Link" && p3Character != "Link" && p4Character == "Link")
                {
                    kosAgainstLink = p4NumOfKosForP1;
                }
                else if (p2Character == "Link" && p3Character == "Link" && p4Character != "Link")
                {
                    kosAgainstLink = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Link" && p3Character != "Link" && p4Character == "Link")
                {
                    kosAgainstLink = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Link" && p3Character == "Link" && p4Character == "Link")
                {
                    kosAgainstLink = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Link" && p3Character == "Link" && p4Character == "Link")
                {
                    kosAgainstLink = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstLink;

        }

        //################################# End Link determination ############################################



        //################################# Start Little Mac determination ############################################
        public static int DetermineKosLittleMac(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstLittle = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Little Mac" || p3Character == "Little Mac" || p4Character == "Little Mac")
            {
                if (p2Character == "Little Mac" && p3Character != "Little Mac" && p4Character != "Little Mac")
                {
                    kosAgainstLittle = p2NumOfKosForP1;
                }
                else if (p2Character != "Little Mac" && p3Character == "Little Mac" && p4Character != "Little Mac")
                {
                    kosAgainstLittle = p3NumOfKosForP1;
                }
                else if (p2Character != "Little Mac" && p3Character != "Little Mac" && p4Character == "Little Mac")
                {
                    kosAgainstLittle = p4NumOfKosForP1;
                }
                else if (p2Character == "Little Mac" && p3Character == "Little Mac" && p4Character != "Little Mac")
                {
                    kosAgainstLittle = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Little Mac" && p3Character != "Little Mac" && p4Character == "Little Mac")
                {
                    kosAgainstLittle = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Little Mac" && p3Character == "Little Mac" && p4Character == "Little Mac")
                {
                    kosAgainstLittle = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Little Mac" && p3Character == "Little Mac" && p4Character == "Little Mac")
                {
                    kosAgainstLittle = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstLittle;

        }

        //################################# End Little Mac determination ############################################



        //################################# Start Lucario determination ############################################
        public static int DetermineKosLucario(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstLucario = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Lucario" || p3Character == "Lucario" || p4Character == "Lucario")
            {
                if (p2Character == "Lucario" && p3Character != "Lucario" && p4Character != "Lucario")
                {
                    kosAgainstLucario = p2NumOfKosForP1;
                }
                else if (p2Character != "Lucario" && p3Character == "Lucario" && p4Character != "Lucario")
                {
                    kosAgainstLucario = p3NumOfKosForP1;
                }
                else if (p2Character != "Lucario" && p3Character != "Lucario" && p4Character == "Lucario")
                {
                    kosAgainstLucario = p4NumOfKosForP1;
                }
                else if (p2Character == "Lucario" && p3Character == "Lucario" && p4Character != "Lucario")
                {
                    kosAgainstLucario = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Lucario" && p3Character != "Lucario" && p4Character == "Lucario")
                {
                    kosAgainstLucario = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Lucario" && p3Character == "Lucario" && p4Character == "Lucario")
                {
                    kosAgainstLucario = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Lucario" && p3Character == "Lucario" && p4Character == "Lucario")
                {
                    kosAgainstLucario = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstLucario;

        }

        //################################# End Lucario determination ############################################



        //################################# Start Lucas determination ############################################
        public static int DetermineKosLucas(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstLucas = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Lucas" || p3Character == "Lucas" || p4Character == "Lucas")
            {
                if (p2Character == "Lucas" && p3Character != "Lucas" && p4Character != "Lucas")
                {
                    kosAgainstLucas = p2NumOfKosForP1;
                }
                else if (p2Character != "Lucas" && p3Character == "Lucas" && p4Character != "Lucas")
                {
                    kosAgainstLucas = p3NumOfKosForP1;
                }
                else if (p2Character != "Lucas" && p3Character != "Lucas" && p4Character == "Lucas")
                {
                    kosAgainstLucas = p4NumOfKosForP1;
                }
                else if (p2Character == "Lucas" && p3Character == "Lucas" && p4Character != "Lucas")
                {
                    kosAgainstLucas = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Lucas" && p3Character != "Lucas" && p4Character == "Lucas")
                {
                    kosAgainstLucas = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Lucas" && p3Character == "Lucas" && p4Character == "Lucas")
                {
                    kosAgainstLucas = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Lucas" && p3Character == "Lucas" && p4Character == "Lucas")
                {
                    kosAgainstLucas = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstLucas;

        }

        //################################# End Lucas determination ############################################



        //################################# Start Lucina determination ############################################
        public static int DetermineKosLucina(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstLucina = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Lucina" || p3Character == "Lucina" || p4Character == "Lucina")
            {
                if (p2Character == "Lucina" && p3Character != "Lucina" && p4Character != "Lucina")
                {
                    kosAgainstLucina = p2NumOfKosForP1;
                }
                else if (p2Character != "Lucina" && p3Character == "Lucina" && p4Character != "Lucina")
                {
                    kosAgainstLucina = p3NumOfKosForP1;
                }
                else if (p2Character != "Lucina" && p3Character != "Lucina" && p4Character == "Lucina")
                {
                    kosAgainstLucina = p4NumOfKosForP1;
                }
                else if (p2Character == "Lucina" && p3Character == "Lucina" && p4Character != "Lucina")
                {
                    kosAgainstLucina = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Lucina" && p3Character != "Lucina" && p4Character == "Lucina")
                {
                    kosAgainstLucina = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Lucina" && p3Character == "Lucina" && p4Character == "Lucina")
                {
                    kosAgainstLucina = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Lucina" && p3Character == "Lucina" && p4Character == "Lucina")
                {
                    kosAgainstLucina = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstLucina;

        }

        //################################# End Lucina determination ############################################

        //################################# Start Luigi determination ############################################
        public static int DetermineKosLuigi(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstLuigi = 0;
            

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Luigi" || p3Character == "Luigi" || p4Character == "Luigi")
            {
                if (p2Character == "Luigi" && p3Character != "Luigi" && p4Character != "Luigi")
                {
                    kosAgainstLuigi = p2NumOfKosForP1;
                }
                else if (p2Character != "Luigi" && p3Character == "Luigi" && p4Character != "Luigi")
                {
                    kosAgainstLuigi = p3NumOfKosForP1;
                }
                else if (p2Character != "Luigi" && p3Character != "Luigi" && p4Character == "Luigi")
                {
                    kosAgainstLuigi = p4NumOfKosForP1;
                }
                else if (p2Character == "Luigi" && p3Character == "Luigi" && p4Character != "Luigi")
                {
                    kosAgainstLuigi = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Luigi" && p3Character != "Luigi" && p4Character == "Luigi")
                {
                    kosAgainstLuigi = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Luigi" && p3Character == "Luigi" && p4Character == "Luigi")
                {
                    kosAgainstLuigi = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Luigi" && p3Character == "Luigi" && p4Character == "Luigi")
                {
                    kosAgainstLuigi = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstLuigi;

        }

        //################################# End Luigi determination ############################################



        //################################# Start Mario determination ############################################
        public static int DetermineKosMario(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstMario = 0;
            

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Mario" || p3Character == "Mario" || p4Character == "Mario")
            {
                if (p2Character == "Mario" && p3Character != "Mario" && p4Character != "Mario")
                {
                    kosAgainstMario = p2NumOfKosForP1;
                }
                else if (p2Character != "Mario" && p3Character == "Mario" && p4Character != "Mario")
                {
                    kosAgainstMario = p3NumOfKosForP1;
                }
                else if (p2Character != "Mario" && p3Character != "Mario" && p4Character == "Mario")
                {
                    kosAgainstMario = p4NumOfKosForP1;
                }
                else if (p2Character == "Mario" && p3Character == "Mario" && p4Character != "Mario")
                {
                    kosAgainstMario = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Mario" && p3Character != "Mario" && p4Character == "Mario")
                {
                    kosAgainstMario = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Mario" && p3Character == "Mario" && p4Character == "Mario")
                {
                    kosAgainstMario = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Mario" && p3Character == "Mario" && p4Character == "Mario")
                {
                    kosAgainstMario = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstMario;

        }

        //################################# End Mario determination ############################################



        //################################# Start Marth determination ############################################
        public static int DetermineKosMarth(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstMarth = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Marth" || p3Character == "Marth" || p4Character == "Marth")
            {
                if (p2Character == "Marth" && p3Character != "Marth" && p4Character != "Marth")
                {
                    kosAgainstMarth = p2NumOfKosForP1;
                }
                else if (p2Character != "Marth" && p3Character == "Marth" && p4Character != "Marth")
                {
                    kosAgainstMarth = p3NumOfKosForP1;
                }
                else if (p2Character != "Marth" && p3Character != "Marth" && p4Character == "Marth")
                {
                    kosAgainstMarth = p4NumOfKosForP1;
                }
                else if (p2Character == "Marth" && p3Character == "Marth" && p4Character != "Marth")
                {
                    kosAgainstMarth = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Marth" && p3Character != "Marth" && p4Character == "Marth")
                {
                    kosAgainstMarth = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Marth" && p3Character == "Marth" && p4Character == "Marth")
                {
                    kosAgainstMarth = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Marth" && p3Character == "Marth" && p4Character == "Marth")
                {
                    kosAgainstMarth = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstMarth;

        }

        //################################# End Marth determination ############################################



        //################################# Start Mega Man determination ############################################
        public static int DetermineKosMegaMan(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstMegaMan = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Mega Man" || p3Character == "Mega Man" || p4Character == "Mega Man")
            {
                if (p2Character == "Mega Man" && p3Character != "Mega Man" && p4Character != "Mega Man")
                {
                    kosAgainstMegaMan = p2NumOfKosForP1;
                }
                else if (p2Character != "Mega Man" && p3Character == "Mega Man" && p4Character != "Mega Man")
                {
                    kosAgainstMegaMan = p3NumOfKosForP1;
                }
                else if (p2Character != "Mega Man" && p3Character != "Mega Man" && p4Character == "Mega Man")
                {
                    kosAgainstMegaMan = p4NumOfKosForP1;
                }
                else if (p2Character == "Mega Man" && p3Character == "Mega Man" && p4Character != "Mega Man")
                {
                    kosAgainstMegaMan = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Mega Man" && p3Character != "Mega Man" && p4Character == "Mega Man")
                {
                    kosAgainstMegaMan = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Mega Man" && p3Character == "Mega Man" && p4Character == "Mega Man")
                {
                    kosAgainstMegaMan = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Mega Man" && p3Character == "Mega Man" && p4Character == "Mega Man")
                {
                    kosAgainstMegaMan = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstMegaMan;

        }

        //################################# End Mega Man determination ############################################



        //################################# Start MetaKnight determination ############################################
        public static int DetermineKosMetaknight(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstMetaknight = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Metaknight" || p3Character == "Metaknight" || p4Character == "Metaknight")
            {
                if (p2Character == "Metaknight" && p3Character != "Metaknight" && p4Character != "Metaknight")
                {
                    kosAgainstMetaknight = p2NumOfKosForP1;
                }
                else if (p2Character != "Metaknight" && p3Character == "Metaknight" && p4Character != "Metaknight")
                {
                    kosAgainstMetaknight = p3NumOfKosForP1;
                }
                else if (p2Character != "Metaknight" && p3Character != "Metaknight" && p4Character == "Metaknight")
                {
                    kosAgainstMetaknight = p4NumOfKosForP1;
                }
                else if (p2Character == "Metaknight" && p3Character == "Metaknight" && p4Character != "Metaknight")
                {
                    kosAgainstMetaknight = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Metaknight" && p3Character != "Metaknight" && p4Character == "Metaknight")
                {
                    kosAgainstMetaknight = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Metaknight" && p3Character == "Metaknight" && p4Character == "Metaknight")
                {
                    kosAgainstMetaknight = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Metaknight" && p3Character == "Metaknight" && p4Character == "Metaknight")
                {
                    kosAgainstMetaknight = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstMetaknight;

        }

        //################################# End Metaknight determination ############################################



        //################################# Start Mewtwo determination ############################################
        public static int DetermineKosMewtwo(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstMewtwo = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Mewtwo" || p3Character == "Mewtwo" || p4Character == "Mewtwo")
            {
                if (p2Character == "Mewtwo" && p3Character != "Mewtwo" && p4Character != "Mewtwo")
                {
                    kosAgainstMewtwo = p2NumOfKosForP1;
                }
                else if (p2Character != "Mewtwo" && p3Character == "Mewtwo" && p4Character != "Mewtwo")
                {
                    kosAgainstMewtwo = p3NumOfKosForP1;
                }
                else if (p2Character != "Mewtwo" && p3Character != "Mewtwo" && p4Character == "Mewtwo")
                {
                    kosAgainstMewtwo = p4NumOfKosForP1;
                }
                else if (p2Character == "Mewtwo" && p3Character == "Mewtwo" && p4Character != "Mewtwo")
                {
                    kosAgainstMewtwo = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Mewtwo" && p3Character != "Mewtwo" && p4Character == "Mewtwo")
                {
                    kosAgainstMewtwo = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Mewtwo" && p3Character == "Mewtwo" && p4Character == "Mewtwo")
                {
                    kosAgainstMewtwo = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Mewtwo" && p3Character == "Mewtwo" && p4Character == "Mewtwo")
                {
                    kosAgainstMewtwo = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstMewtwo;

        }

        //################################# End Mewtwo determination ############################################



        //################################# Start Mr. Game & Watch determination ############################################
        public static int DetermineKosMrGame(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstMrGame = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Mr. Game & Watch" || p3Character == "Mr. Game & Watch" || p4Character == "Mr. Game & Watch")
            {
                if (p2Character == "Mr. Game & Watch" && p3Character != "Mr. Game & Watch" && p4Character != "Mr. Game & Watch")
                {
                    kosAgainstMrGame = p2NumOfKosForP1;
                }
                else if (p2Character != "Mr. Game & Watch" && p3Character == "Mr. Game & Watch" && p4Character != "Mr. Game & Watch")
                {
                    kosAgainstMrGame = p3NumOfKosForP1;
                }
                else if (p2Character != "Mr. Game & Watch" && p3Character != "Mr. Game & Watch" && p4Character == "Mr. Game & Watch")
                {
                    kosAgainstMrGame = p4NumOfKosForP1;
                }
                else if (p2Character == "Mr. Game & Watch" && p3Character == "Mr. Game & Watch" && p4Character != "Mr. Game & Watch")
                {
                    kosAgainstMrGame = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Mr. Game & Watch" && p3Character != "Mr. Game & Watch" && p4Character == "Mr. Game & Watch")
                {
                    kosAgainstMrGame = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Mr. Game & Watch" && p3Character == "Mr. Game & Watch" && p4Character == "Mr. Game & Watch")
                {
                    kosAgainstMrGame = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Mr. Game & Watch" && p3Character == "Mr. Game & Watch" && p4Character == "Mr. Game & Watch")
                {
                    kosAgainstMrGame = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstMrGame;

        }

        //################################# End Mr. Game & Watch determination ############################################



        //################################# Start Ness determination ############################################
        public static int DetermineKosNess(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstNess = 0;
           

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Ness" || p3Character == "Ness" || p4Character == "Ness")
            {
                if (p2Character == "Ness" && p3Character != "Ness" && p4Character != "Ness")
                {
                    kosAgainstNess = p2NumOfKosForP1;
                }
                else if (p2Character != "Ness" && p3Character == "Ness" && p4Character != "Ness")
                {
                    kosAgainstNess = p3NumOfKosForP1;
                }
                else if (p2Character != "Ness" && p3Character != "Ness" && p4Character == "Ness")
                {
                    kosAgainstNess = p4NumOfKosForP1;
                }
                else if (p2Character == "Ness" && p3Character == "Ness" && p4Character != "Ness")
                {
                    kosAgainstNess = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Ness" && p3Character != "Ness" && p4Character == "Ness")
                {
                    kosAgainstNess = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Ness" && p3Character == "Ness" && p4Character == "Ness")
                {
                    kosAgainstNess = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Ness" && p3Character == "Ness" && p4Character == "Ness")
                {
                    kosAgainstNess = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstNess;

        }

        //################################# End Ness determination ############################################



        //################################# Start Olimar determination ############################################
        public static int DetermineKosOlimar(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstOlimar = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Olimar" || p3Character == "Olimar" || p4Character == "Olimar")
            {
                if (p2Character == "Olimar" && p3Character != "Olimar" && p4Character != "Olimar")
                {
                    kosAgainstOlimar = p2NumOfKosForP1;
                }
                else if (p2Character != "Olimar" && p3Character == "Olimar" && p4Character != "Olimar")
                {
                    kosAgainstOlimar = p3NumOfKosForP1;
                }
                else if (p2Character != "Olimar" && p3Character != "Olimar" && p4Character == "Olimar")
                {
                    kosAgainstOlimar = p4NumOfKosForP1;
                }
                else if (p2Character == "Olimar" && p3Character == "Olimar" && p4Character != "Olimar")
                {
                    kosAgainstOlimar = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Olimar" && p3Character != "Olimar" && p4Character == "Olimar")
                {
                    kosAgainstOlimar = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Olimar" && p3Character == "Olimar" && p4Character == "Olimar")
                {
                    kosAgainstOlimar = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Olimar" && p3Character == "Olimar" && p4Character == "Olimar")
                {
                    kosAgainstOlimar = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstOlimar;

        }

        //################################# End Olimar determination ############################################



        //################################# Start Pac Man determination ############################################
        public static int DetermineKosPacMan(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstPacMan = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Pac-Man" || p3Character == "Pac-Man" || p4Character == "Pac-Man")
            {
                if (p2Character == "Pac-Man" && p3Character != "Pac-Man" && p4Character != "Pac-Man")
                {
                    kosAgainstPacMan = p2NumOfKosForP1;
                }
                else if (p2Character != "Pac-Man" && p3Character == "Pac-Man" && p4Character != "Pac-Man")
                {
                    kosAgainstPacMan = p3NumOfKosForP1;
                }
                else if (p2Character != "Pac-Man" && p3Character != "Pac-Man" && p4Character == "Pac-Man")
                {
                    kosAgainstPacMan = p4NumOfKosForP1;
                }
                else if (p2Character == "Pac-Man" && p3Character == "Pac-Man" && p4Character != "Pac-Man")
                {
                    kosAgainstPacMan = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Pac-Man" && p3Character != "Pac-Man" && p4Character == "Pac-Man")
                {
                    kosAgainstPacMan = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Pac-Man" && p3Character == "Pac-Man" && p4Character == "Pac-Man")
                {
                    kosAgainstPacMan = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Pac-Man" && p3Character == "Pac-Man" && p4Character == "Pac-Man")
                {
                    kosAgainstPacMan = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstPacMan;

        }

        //################################# End Pac Man determination ############################################



        //################################# Start Palutena determination ############################################
        public static int DetermineKosPalutena(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstPalutena = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Palutena" || p3Character == "Palutena" || p4Character == "Palutena")
            {
                if (p2Character == "Palutena" && p3Character != "Palutena" && p4Character != "Palutena")
                {
                    kosAgainstPalutena = p2NumOfKosForP1;
                }
                else if (p2Character != "Palutena" && p3Character == "Palutena" && p4Character != "Palutena")
                {
                    kosAgainstPalutena = p3NumOfKosForP1;
                }
                else if (p2Character != "Palutena" && p3Character != "Palutena" && p4Character == "Palutena")
                {
                    kosAgainstPalutena = p4NumOfKosForP1;
                }
                else if (p2Character == "Palutena" && p3Character == "Palutena" && p4Character != "Palutena")
                {
                    kosAgainstPalutena = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Palutena" && p3Character != "Palutena" && p4Character == "Palutena")
                {
                    kosAgainstPalutena = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Palutena" && p3Character == "Palutena" && p4Character == "Palutena")
                {
                    kosAgainstPalutena = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Palutena" && p3Character == "Palutena" && p4Character == "Palutena")
                {
                    kosAgainstPalutena = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstPalutena;

        }

        //################################# End Palutena determination ############################################



        //################################# Start Peach determination ############################################
        public static int DetermineKosPeach(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstPeach = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Peach" || p3Character == "Peach" || p4Character == "Peach")
            {
                if (p2Character == "Peach" && p3Character != "Peach" && p4Character != "Peach")
                {
                    kosAgainstPeach = p2NumOfKosForP1;
                }
                else if (p2Character != "Peach" && p3Character == "Peach" && p4Character != "Peach")
                {
                    kosAgainstPeach = p3NumOfKosForP1;
                }
                else if (p2Character != "Peach" && p3Character != "Peach" && p4Character == "Peach")
                {
                    kosAgainstPeach = p4NumOfKosForP1;
                }
                else if (p2Character == "Peach" && p3Character == "Peach" && p4Character != "Peach")
                {
                    kosAgainstPeach = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Peach" && p3Character != "Peach" && p4Character == "Peach")
                {
                    kosAgainstPeach = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Peach" && p3Character == "Peach" && p4Character == "Peach")
                {
                    kosAgainstPeach = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Peach" && p3Character == "Peach" && p4Character == "Peach")
                {
                    kosAgainstPeach = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstPeach;

        }

        //################################# End Peach determination ############################################



        //################################# Start Pichu determination ############################################
        public static int DetermineKosPichu(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstPichu = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Pichu" || p3Character == "Pichu" || p4Character == "Pichu")
            {
                if (p2Character == "Pichu" && p3Character != "Pichu" && p4Character != "Pichu")
                {
                    kosAgainstPichu = p2NumOfKosForP1;
                }
                else if (p2Character != "Pichu" && p3Character == "Pichu" && p4Character != "Pichu")
                {
                    kosAgainstPichu = p3NumOfKosForP1;
                }
                else if (p2Character != "Pichu" && p3Character != "Pichu" && p4Character == "Pichu")
                {
                    kosAgainstPichu = p4NumOfKosForP1;
                }
                else if (p2Character == "Pichu" && p3Character == "Pichu" && p4Character != "Pichu")
                {
                    kosAgainstPichu = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Pichu" && p3Character != "Pichu" && p4Character == "Pichu")
                {
                    kosAgainstPichu = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Pichu" && p3Character == "Pichu" && p4Character == "Pichu")
                {
                    kosAgainstPichu = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Pichu" && p3Character == "Pichu" && p4Character == "Pichu")
                {
                    kosAgainstPichu = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstPichu;

        }

        //################################# End Pichu determination ############################################



        //################################# Start Pikachu determination ############################################
        public static int DetermineKosPika(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstPika = 0;
            

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Pikachu" || p3Character == "Pikachu" || p4Character == "Pikachu")
            {
                if (p2Character == "Pikachu" && p3Character != "Pikachu" && p4Character != "Pikachu")
                {
                    kosAgainstPika = p2NumOfKosForP1;
                }
                else if (p2Character != "Pikachu" && p3Character == "Pikachu" && p4Character != "Pikachu")
                {
                    kosAgainstPika = p3NumOfKosForP1;
                }
                else if (p2Character != "Pikachu" && p3Character != "Pikachu" && p4Character == "Pikachu")
                {
                    kosAgainstPika = p4NumOfKosForP1;
                }
                else if (p2Character == "Pikachu" && p3Character == "Pikachu" && p4Character != "Pikachu")
                {
                    kosAgainstPika = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Pikachu" && p3Character != "Pikachu" && p4Character == "Pikachu")
                {
                    kosAgainstPika = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Pikachu" && p3Character == "Pikachu" && p4Character == "Pikachu")
                {
                    kosAgainstPika = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Pikachu" && p3Character == "Pikachu" && p4Character == "Pikachu")
                {
                    kosAgainstPika = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstPika;

        }

        //################################# End Pikachu determination ############################################



        //################################# Start Pit determination ############################################
        public static int DetermineKosPit(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstPit = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Pit" || p3Character == "Pit" || p4Character == "Pit")
            {
                if (p2Character == "Pit" && p3Character != "Pit" && p4Character != "Pit")
                {
                    kosAgainstPit = p2NumOfKosForP1;
                }
                else if (p2Character != "Pit" && p3Character == "Pit" && p4Character != "Pit")
                {
                    kosAgainstPit = p3NumOfKosForP1;
                }
                else if (p2Character != "Pit" && p3Character != "Pit" && p4Character == "Pit")
                {
                    kosAgainstPit = p4NumOfKosForP1;
                }
                else if (p2Character == "Pit" && p3Character == "Pit" && p4Character != "Pit")
                {
                    kosAgainstPit = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Pit" && p3Character != "Pit" && p4Character == "Pit")
                {
                    kosAgainstPit = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Pit" && p3Character == "Pit" && p4Character == "Pit")
                {
                    kosAgainstPit = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Pit" && p3Character == "Pit" && p4Character == "Pit")
                {
                    kosAgainstPit = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstPit;

        }

        //################################# End Pit determination ############################################



        //################################# Start Pokemon Trainer determination ############################################
        public static int DetermineKosPokemonTrainer(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstPokemonTrainer = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Pokemon Trainer" || p3Character == "Pokemon Trainer" || p4Character == "Pokemon Trainer")
            {
                if (p2Character == "Pokemon Trainer" && p3Character != "Pokemon Trainer" && p4Character != "Pokemon Trainer")
                {
                    kosAgainstPokemonTrainer = p2NumOfKosForP1;
                }
                else if (p2Character != "Pokemon Trainer" && p3Character == "Pokemon Trainer" && p4Character != "Pokemon Trainer")
                {
                    kosAgainstPokemonTrainer = p3NumOfKosForP1;
                }
                else if (p2Character != "Pokemon Trainer" && p3Character != "Pokemon Trainer" && p4Character == "Pokemon Trainer")
                {
                    kosAgainstPokemonTrainer = p4NumOfKosForP1;
                }
                else if (p2Character == "Pokemon Trainer" && p3Character == "Pokemon Trainer" && p4Character != "Pokemon Trainer")
                {
                    kosAgainstPokemonTrainer = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Pokemon Trainer" && p3Character != "Pokemon Trainer" && p4Character == "Pokemon Trainer")
                {
                    kosAgainstPokemonTrainer = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Pokemon Trainer" && p3Character == "Pokemon Trainer" && p4Character == "Pokemon Trainer")
                {
                    kosAgainstPokemonTrainer = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Pokemon Trainer" && p3Character == "Pokemon Trainer" && p4Character == "Pokemon Trainer")
                {
                    kosAgainstPokemonTrainer = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstPokemonTrainer;

        }

        //################################# End Pokemon Trainer determination ############################################



        //################################# Start Rob determination ############################################
        public static int DetermineKosROB(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstROB = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "R.O.B" || p3Character == "R.O.B" || p4Character == "R.O.B")
            {
                if (p2Character == "R.O.B" && p3Character != "R.O.B" && p4Character != "R.O.B")
                {
                    kosAgainstROB = p2NumOfKosForP1;
                }
                else if (p2Character != "R.O.B" && p3Character == "R.O.B" && p4Character != "R.O.B")
                {
                    kosAgainstROB = p3NumOfKosForP1;
                }
                else if (p2Character != "R.O.B" && p3Character != "R.O.B" && p4Character == "R.O.B")
                {
                    kosAgainstROB = p4NumOfKosForP1;
                }
                else if (p2Character == "R.O.B" && p3Character == "R.O.B" && p4Character != "R.O.B")
                {
                    kosAgainstROB = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "R.O.B" && p3Character != "R.O.B" && p4Character == "R.O.B")
                {
                    kosAgainstROB = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "R.O.B" && p3Character == "R.O.B" && p4Character == "R.O.B")
                {
                    kosAgainstROB = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "R.O.B" && p3Character == "R.O.B" && p4Character == "R.O.B")
                {
                    kosAgainstROB = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstROB;

        }

        //################################# End ROB determination ############################################



        //################################# Start Robin determination ############################################
        public static int DetermineKosRobin(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstRobin = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Robin" || p3Character == "Robin" || p4Character == "Robin")
            {
                if (p2Character == "Robin" && p3Character != "Robin" && p4Character != "Robin")
                {
                    kosAgainstRobin = p2NumOfKosForP1;
                }
                else if (p2Character != "Robin" && p3Character == "Robin" && p4Character != "Robin")
                {
                    kosAgainstRobin = p3NumOfKosForP1;
                }
                else if (p2Character != "Robin" && p3Character != "Robin" && p4Character == "Robin")
                {
                    kosAgainstRobin = p4NumOfKosForP1;
                }
                else if (p2Character == "Robin" && p3Character == "Robin" && p4Character != "Robin")
                {
                    kosAgainstRobin = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Robin" && p3Character != "Robin" && p4Character == "Robin")
                {
                    kosAgainstRobin = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Robin" && p3Character == "Robin" && p4Character == "Robin")
                {
                    kosAgainstRobin = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Robin" && p3Character == "Robin" && p4Character == "Robin")
                {
                    kosAgainstRobin = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstRobin;

        }

        //################################# End Robin determination ############################################



        //################################# Start Rosalina & Luma determination ############################################
        public static int DetermineKosRosalina(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstRosalina = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Rosalina & Luma" || p3Character == "Rosalina & Luma" || p4Character == "Rosalina & Luma")
            {
                if (p2Character == "Rosalina & Luma" && p3Character != "Rosalina & Luma" && p4Character != "Rosalina & Luma")
                {
                    kosAgainstRosalina = p2NumOfKosForP1;
                }
                else if (p2Character != "Rosalina & Luma" && p3Character == "Rosalina & Luma" && p4Character != "Rosalina & Luma")
                {
                    kosAgainstRosalina = p3NumOfKosForP1;
                }
                else if (p2Character != "Rosalina & Luma" && p3Character != "Rosalina & Luma" && p4Character == "Rosalina & Luma")
                {
                    kosAgainstRosalina = p4NumOfKosForP1;
                }
                else if (p2Character == "Rosalina & Luma" && p3Character == "Rosalina & Luma" && p4Character != "Rosalina & Luma")
                {
                    kosAgainstRosalina = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Rosalina & Luma" && p3Character != "Rosalina & Luma" && p4Character == "Rosalina & Luma")
                {
                    kosAgainstRosalina = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Rosalina & Luma" && p3Character == "Rosalina & Luma" && p4Character == "Rosalina & Luma")
                {
                    kosAgainstRosalina = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Rosalina & Luma" && p3Character == "Rosalina & Luma" && p4Character == "Rosalina & Luma")
                {
                    kosAgainstRosalina = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstRosalina;

        }

        //################################# End Rosalina determination ############################################



        //################################# Start Roy determination ############################################
        public static int DetermineKosRoy(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstRoy = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Roy" || p3Character == "Roy" || p4Character == "Roy")
            {
                if (p2Character == "Roy" && p3Character != "Roy" && p4Character != "Roy")
                {
                    kosAgainstRoy = p2NumOfKosForP1;
                }
                else if (p2Character != "Roy" && p3Character == "Roy" && p4Character != "Roy")
                {
                    kosAgainstRoy = p3NumOfKosForP1;
                }
                else if (p2Character != "Roy" && p3Character != "Roy" && p4Character == "Roy")
                {
                    kosAgainstRoy = p4NumOfKosForP1;
                }
                else if (p2Character == "Roy" && p3Character == "Roy" && p4Character != "Roy")
                {
                    kosAgainstRoy = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Roy" && p3Character != "Roy" && p4Character == "Roy")
                {
                    kosAgainstRoy = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Roy" && p3Character == "Roy" && p4Character == "Roy")
                {
                    kosAgainstRoy = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Roy" && p3Character == "Roy" && p4Character == "Roy")
                {
                    kosAgainstRoy = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstRoy;

        }

        //################################# End Roy determination ############################################



        //################################# Start Samus determination ############################################
        public static int DetermineKosSamus(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstSamus = 0;
            

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Samus" || p3Character == "Samus" || p4Character == "Samus")
            {
                if (p2Character == "Samus" && p3Character != "Samus" && p4Character != "Samus")
                {
                    kosAgainstSamus = p2NumOfKosForP1;
                }
                else if (p2Character != "Samus" && p3Character == "Samus" && p4Character != "Samus")
                {
                    kosAgainstSamus = p3NumOfKosForP1;
                }
                else if (p2Character != "Samus" && p3Character != "Samus" && p4Character == "Samus")
                {
                    kosAgainstSamus = p4NumOfKosForP1;
                }
                else if (p2Character == "Samus" && p3Character == "Samus" && p4Character != "Samus")
                {
                    kosAgainstSamus = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Samus" && p3Character != "Samus" && p4Character == "Samus")
                {
                    kosAgainstSamus = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Samus" && p3Character == "Samus" && p4Character == "Samus")
                {
                    kosAgainstSamus = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Samus" && p3Character == "Samus" && p4Character == "Samus")
                {
                    kosAgainstSamus = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstSamus;

        }

        //################################# End Samus determination ############################################



        //################################# Start Samus/Zero determination ############################################
        public static int DetermineKosSamusAndZero(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstSamusandZero = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Samus/Zero Suit Samus" || p3Character == "Samus/Zero Suit Samus" || p4Character == "Samus/Zero Suit Samus")
            {
                if (p2Character == "Samus/Zero Suit Samus" && p3Character != "Samus/Zero Suit Samus" && p4Character != "Samus/Zero Suit Samus")
                {
                    kosAgainstSamusandZero = p2NumOfKosForP1;
                }
                else if (p2Character != "Samus/Zero Suit Samus" && p3Character == "Samus/Zero Suit Samus" && p4Character != "Samus/Zero Suit Samus")
                {
                    kosAgainstSamusandZero = p3NumOfKosForP1;
                }
                else if (p2Character != "Samus/Zero Suit Samus" && p3Character != "Samus/Zero Suit Samus" && p4Character == "Samus/Zero Suit Samus")
                {
                    kosAgainstSamusandZero = p4NumOfKosForP1;
                }
                else if (p2Character == "Samus/Zero Suit Samus" && p3Character == "Samus/Zero Suit Samus" && p4Character != "Samus/Zero Suit Samus")
                {
                    kosAgainstSamusandZero = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Samus/Zero Suit Samus" && p3Character != "Samus/Zero Suit Samus" && p4Character == "Samus/Zero Suit Samus")
                {
                    kosAgainstSamusandZero = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Samus/Zero Suit Samus" && p3Character == "Samus/Zero Suit Samus" && p4Character == "Samus/Zero Suit Samus")
                {
                    kosAgainstSamusandZero = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Samus/Zero Suit Samus" && p3Character == "Samus/Zero Suit Samus" && p4Character == "Samus/Zero Suit Samus")
                {
                    kosAgainstSamusandZero = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstSamusandZero;

        }

        //################################# End Samus/Zero determination ############################################



        //################################# Start Sheik determination ############################################
        public static int DetermineKosSheik(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstSheik = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Sheik" || p3Character == "Sheik" || p4Character == "Sheik")
            {
                if (p2Character == "Sheik" && p3Character != "Sheik" && p4Character != "Sheik")
                {
                    kosAgainstSheik = p2NumOfKosForP1;
                }
                else if (p2Character != "Sheik" && p3Character == "Sheik" && p4Character != "Sheik")
                {
                    kosAgainstSheik = p3NumOfKosForP1;
                }
                else if (p2Character != "Sheik" && p3Character != "Sheik" && p4Character == "Sheik")
                {
                    kosAgainstSheik = p4NumOfKosForP1;
                }
                else if (p2Character == "Sheik" && p3Character == "Sheik" && p4Character != "Sheik")
                {
                    kosAgainstSheik = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Sheik" && p3Character != "Sheik" && p4Character == "Sheik")
                {
                    kosAgainstSheik = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Sheik" && p3Character == "Sheik" && p4Character == "Sheik")
                {
                    kosAgainstSheik = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Sheik" && p3Character == "Sheik" && p4Character == "Sheik")
                {
                    kosAgainstSheik = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstSheik;

        }

        //################################# End Sheik determination ############################################



        //################################# Start Shulk determination ############################################
        public static int DetermineKosShulk(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstShulk = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Shulk" || p3Character == "Shulk" || p4Character == "Shulk")
            {
                if (p2Character == "Shulk" && p3Character != "Shulk" && p4Character != "Shulk")
                {
                    kosAgainstShulk = p2NumOfKosForP1;
                }
                else if (p2Character != "Shulk" && p3Character == "Shulk" && p4Character != "Shulk")
                {
                    kosAgainstShulk = p3NumOfKosForP1;
                }
                else if (p2Character != "Shulk" && p3Character != "Shulk" && p4Character == "Shulk")
                {
                    kosAgainstShulk = p4NumOfKosForP1;
                }
                else if (p2Character == "Shulk" && p3Character == "Shulk" && p4Character != "Shulk")
                {
                    kosAgainstShulk = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Shulk" && p3Character != "Shulk" && p4Character == "Shulk")
                {
                    kosAgainstShulk = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Shulk" && p3Character == "Shulk" && p4Character == "Shulk")
                {
                    kosAgainstShulk = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Shulk" && p3Character == "Shulk" && p4Character == "Shulk")
                {
                    kosAgainstShulk = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstShulk;

        }

        //################################# End Shulk determination ############################################


        //################################# Start Snake determination ############################################
        public static int DetermineKosSnake(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstSnake = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Snake" || p3Character == "Snake" || p4Character == "Snake")
            {
                if (p2Character == "Snake" && p3Character != "Snake" && p4Character != "Snake")
                {
                    kosAgainstSnake = p2NumOfKosForP1;
                }
                else if (p2Character != "Snake" && p3Character == "Snake" && p4Character != "Snake")
                {
                    kosAgainstSnake = p3NumOfKosForP1;
                }
                else if (p2Character != "Snake" && p3Character != "Snake" && p4Character == "Snake")
                {
                    kosAgainstSnake = p4NumOfKosForP1;
                }
                else if (p2Character == "Snake" && p3Character == "Snake" && p4Character != "Snake")
                {
                    kosAgainstSnake = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Snake" && p3Character != "Snake" && p4Character == "Snake")
                {
                    kosAgainstSnake = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Snake" && p3Character == "Snake" && p4Character == "Snake")
                {
                    kosAgainstSnake = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Snake" && p3Character == "Snake" && p4Character == "Snake")
                {
                    kosAgainstSnake = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstSnake;

        }

        //################################# End Snake determination ############################################



        //################################# Start Sonic determination ############################################
        public static int DetermineKosSonic(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstSonic = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Sonic" || p3Character == "Sonic" || p4Character == "Sonic")
            {
                if (p2Character == "Sonic" && p3Character != "Sonic" && p4Character != "Sonic")
                {
                    kosAgainstSonic = p2NumOfKosForP1;
                }
                else if (p2Character != "Sonic" && p3Character == "Sonic" && p4Character != "Sonic")
                {
                    kosAgainstSonic = p3NumOfKosForP1;
                }
                else if (p2Character != "Sonic" && p3Character != "Sonic" && p4Character == "Sonic")
                {
                    kosAgainstSonic = p4NumOfKosForP1;
                }
                else if (p2Character == "Sonic" && p3Character == "Sonic" && p4Character != "Sonic")
                {
                    kosAgainstSonic = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Sonic" && p3Character != "Sonic" && p4Character == "Sonic")
                {
                    kosAgainstSonic = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Sonic" && p3Character == "Sonic" && p4Character == "Sonic")
                {
                    kosAgainstSonic = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Sonic" && p3Character == "Sonic" && p4Character == "Sonic")
                {
                    kosAgainstSonic = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstSonic;

        }

        //################################# End Sonic determination ############################################



        //################################# Start Toon Link determination ############################################
        public static int DetermineKosToonLink(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstToonLink = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Toon Link" || p3Character == "Toon Link" || p4Character == "Toon Link")
            {
                if (p2Character == "Toon Link" && p3Character != "Toon Link" && p4Character != "Toon Link")
                {
                    kosAgainstToonLink = p2NumOfKosForP1;
                }
                else if (p2Character != "Toon Link" && p3Character == "Toon Link" && p4Character != "Toon Link")
                {
                    kosAgainstToonLink = p3NumOfKosForP1;
                }
                else if (p2Character != "Toon Link" && p3Character != "Toon Link" && p4Character == "Toon Link")
                {
                    kosAgainstToonLink = p4NumOfKosForP1;
                }
                else if (p2Character == "Toon Link" && p3Character == "Toon Link" && p4Character != "Toon Link")
                {
                    kosAgainstToonLink = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Toon Link" && p3Character != "Toon Link" && p4Character == "Toon Link")
                {
                    kosAgainstToonLink = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Toon Link" && p3Character == "Toon Link" && p4Character == "Toon Link")
                {
                    kosAgainstToonLink = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Toon Link" && p3Character == "Toon Link" && p4Character == "Toon Link")
                {
                    kosAgainstToonLink = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstToonLink;

        }

        //################################# End Toon Link determination ############################################



        //################################# Start Villager determination ############################################
        public static int DetermineKosVillager(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstVillager = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Villager" || p3Character == "Villager" || p4Character == "Villager")
            {
                if (p2Character == "Villager" && p3Character != "Villager" && p4Character != "Villager")
                {
                    kosAgainstVillager = p2NumOfKosForP1;
                }
                else if (p2Character != "Villager" && p3Character == "Villager" && p4Character != "Villager")
                {
                    kosAgainstVillager = p3NumOfKosForP1;
                }
                else if (p2Character != "Villager" && p3Character != "Villager" && p4Character == "Villager")
                {
                    kosAgainstVillager = p4NumOfKosForP1;
                }
                else if (p2Character == "Villager" && p3Character == "Villager" && p4Character != "Villager")
                {
                    kosAgainstVillager = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Villager" && p3Character != "Villager" && p4Character == "Villager")
                {
                    kosAgainstVillager = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Villager" && p3Character == "Villager" && p4Character == "Villager")
                {
                    kosAgainstVillager = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Villager" && p3Character == "Villager" && p4Character == "Villager")
                {
                    kosAgainstVillager = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstVillager;

        }

        //################################# End Villager determination ############################################



        //################################# Start Wario determination ############################################
        public static int DetermineKosWario(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstWario = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Wario" || p3Character == "Wario" || p4Character == "Wario")
            {
                if (p2Character == "Wario" && p3Character != "Wario" && p4Character != "Wario")
                {
                    kosAgainstWario = p2NumOfKosForP1;
                }
                else if (p2Character != "Wario" && p3Character == "Wario" && p4Character != "Wario")
                {
                    kosAgainstWario = p3NumOfKosForP1;
                }
                else if (p2Character != "Wario" && p3Character != "Wario" && p4Character == "Wario")
                {
                    kosAgainstWario = p4NumOfKosForP1;
                }
                else if (p2Character == "Wario" && p3Character == "Wario" && p4Character != "Wario")
                {
                    kosAgainstWario = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Wario" && p3Character != "Wario" && p4Character == "Wario")
                {
                    kosAgainstWario = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Wario" && p3Character == "Wario" && p4Character == "Wario")
                {
                    kosAgainstWario = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Wario" && p3Character == "Wario" && p4Character == "Wario")
                {
                    kosAgainstWario = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstWario;

        }

        //################################# End Wario determination ############################################



        //################################# Start Wii Fit determination ############################################
        public static int DetermineKosWiiFit(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstWiiFit = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Wii Fit Trainer" || p3Character == "Wii Fit Trainer" || p4Character == "Wii Fit Trainer")
            {
                if (p2Character == "Wii Fit Trainer" && p3Character != "Wii Fit Trainer" && p4Character != "Wii Fit Trainer")
                {
                    kosAgainstWiiFit = p2NumOfKosForP1;
                }
                else if (p2Character != "Wii Fit Trainer" && p3Character == "Wii Fit Trainer" && p4Character != "Wii Fit Trainer")
                {
                    kosAgainstWiiFit = p3NumOfKosForP1;
                }
                else if (p2Character != "Wii Fit Trainer" && p3Character != "Wii Fit Trainer" && p4Character == "Wii Fit Trainer")
                {
                    kosAgainstWiiFit = p4NumOfKosForP1;
                }
                else if (p2Character == "Wii Fit Trainer" && p3Character == "Wii Fit Trainer" && p4Character != "Wii Fit Trainer")
                {
                    kosAgainstWiiFit = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Wii Fit Trainer" && p3Character != "Wii Fit Trainer" && p4Character == "Wii Fit Trainer")
                {
                    kosAgainstWiiFit = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Wii Fit Trainer" && p3Character == "Wii Fit Trainer" && p4Character == "Wii Fit Trainer")
                {
                    kosAgainstWiiFit = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Wii Fit Trainer" && p3Character == "Wii Fit Trainer" && p4Character == "Wii Fit Trainer")
                {
                    kosAgainstWiiFit = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstWiiFit;

        }

        //################################# End Wii Fit Trainer determination ############################################



        //################################# Start Wolf determination ############################################
        public static int DetermineKosWolf(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstWolf = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Wolf" || p3Character == "Wolf" || p4Character == "Wolf")
            {
                if (p2Character == "Wolf" && p3Character != "Wolf" && p4Character != "Wolf")
                {
                    kosAgainstWolf = p2NumOfKosForP1;
                }
                else if (p2Character != "Wolf" && p3Character == "Wolf" && p4Character != "Wolf")
                {
                    kosAgainstWolf = p3NumOfKosForP1;
                }
                else if (p2Character != "Wolf" && p3Character != "Wolf" && p4Character == "Wolf")
                {
                    kosAgainstWolf = p4NumOfKosForP1;
                }
                else if (p2Character == "Wolf" && p3Character == "Wolf" && p4Character != "Wolf")
                {
                    kosAgainstWolf = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Wolf" && p3Character != "Wolf" && p4Character == "Wolf")
                {
                    kosAgainstWolf = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Wolf" && p3Character == "Wolf" && p4Character == "Wolf")
                {
                    kosAgainstWolf = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Wolf" && p3Character == "Wolf" && p4Character == "Wolf")
                {
                    kosAgainstWolf = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstWolf;

        }

        //################################# End Wolf determination ############################################



        //################################# Start Yoshi determination ############################################
        public static int DetermineKosYoshi(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstYoshi = 0;
            

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Yoshi" || p3Character == "Yoshi" || p4Character == "Yoshi")
            {
                if (p2Character == "Yoshi" && p3Character != "Yoshi" && p4Character != "Yoshi")
                {
                    kosAgainstYoshi = p2NumOfKosForP1;
                }
                else if (p2Character != "Yoshi" && p3Character == "Yoshi" && p4Character != "Yoshi")
                {
                    kosAgainstYoshi = p3NumOfKosForP1;
                }
                else if (p2Character != "Yoshi" && p3Character != "Yoshi" && p4Character == "Yoshi")
                {
                    kosAgainstYoshi = p4NumOfKosForP1;
                }
                else if (p2Character == "Yoshi" && p3Character == "Yoshi" && p4Character != "Yoshi")
                {
                    kosAgainstYoshi = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Yoshi" && p3Character != "Yoshi" && p4Character == "Yoshi")
                {
                    kosAgainstYoshi = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Yoshi" && p3Character == "Yoshi" && p4Character == "Yoshi")
                {
                    kosAgainstYoshi = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Yoshi" && p3Character == "Yoshi" && p4Character == "Yoshi")
                {
                    kosAgainstYoshi = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstYoshi;

        }

        //################################# End Yoshi determination ############################################



        //################################# Start Young Link determination ############################################
        public static int DetermineKosYoungLink(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstYoungLink = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Young Link" || p3Character == "Young Link" || p4Character == "Young Link")
            {
                if (p2Character == "Young Link" && p3Character != "Young Link" && p4Character != "Young Link")
                {
                    kosAgainstYoungLink = p2NumOfKosForP1;
                }
                else if (p2Character != "Young Link" && p3Character == "Young Link" && p4Character != "Young Link")
                {
                    kosAgainstYoungLink = p3NumOfKosForP1;
                }
                else if (p2Character != "Young Link" && p3Character != "Young Link" && p4Character == "Young Link")
                {
                    kosAgainstYoungLink = p4NumOfKosForP1;
                }
                else if (p2Character == "Young Link" && p3Character == "Young Link" && p4Character != "Young Link")
                {
                    kosAgainstYoungLink = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Young Link" && p3Character != "Young Link" && p4Character == "Young Link")
                {
                    kosAgainstYoungLink = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Young Link" && p3Character == "Young Link" && p4Character == "Young Link")
                {
                    kosAgainstYoungLink = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Young Link" && p3Character == "Young Link" && p4Character == "Young Link")
                {
                    kosAgainstYoungLink = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstYoungLink;

        }

        //################################# End Young Link determination ############################################



        //################################# Start Zelda/Shiek determination ############################################
        public static int DetermineKosZeldaShiek(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstZeldaShiek = 0;

            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);

            if (p2Character == "Zelda/Shiek" || p3Character == "Zelda/Shiek" || p4Character == "Zelda/Shiek")
            {
                if (p2Character == "Zelda/Shiek" && p3Character != "Zelda/Shiek" && p4Character != "Zelda/Shiek")
                {
                    kosAgainstZeldaShiek = p2NumOfKosForP1;
                }
                else if (p2Character != "Zelda/Shiek" && p3Character == "Zelda/Shiek" && p4Character != "Zelda/Shiek")
                {
                    kosAgainstZeldaShiek = p3NumOfKosForP1;
                }
                else if (p2Character != "Zelda/Shiek" && p3Character != "Zelda/Shiek" && p4Character == "Zelda/Shiek")
                {
                    kosAgainstZeldaShiek = p4NumOfKosForP1;
                }
                else if (p2Character == "Zelda/Shiek" && p3Character == "Zelda/Shiek" && p4Character != "Zelda/Shiek")
                {
                    kosAgainstZeldaShiek = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Zelda/Shiek" && p3Character != "Zelda/Shiek" && p4Character == "Zelda/Shiek")
                {
                    kosAgainstZeldaShiek = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Zelda/Shiek" && p3Character == "Zelda/Shiek" && p4Character == "Zelda/Shiek")
                {
                    kosAgainstZeldaShiek = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Zelda/Shiek" && p3Character == "Zelda/Shiek" && p4Character == "Zelda/Shiek")
                {
                    kosAgainstZeldaShiek = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }



            return kosAgainstZeldaShiek;

        }

        //################################# End Zelda/Shiek determination ############################################



        //################################# Start Zelda determination ############################################
        public static int DetermineKosZelda(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstZelda = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Zelda" || p3Character == "Zelda" || p4Character == "Zelda")
            {
                if (p2Character == "Zelda" && p3Character != "Zelda" && p4Character != "Zelda")
                {
                    kosAgainstZelda = p2NumOfKosForP1;
                }
                else if (p2Character != "Zelda" && p3Character == "Zelda" && p4Character != "Zelda")
                {
                    kosAgainstZelda = p3NumOfKosForP1;
                }
                else if (p2Character != "Zelda" && p3Character != "Zelda" && p4Character == "Zelda")
                {
                    kosAgainstZelda = p4NumOfKosForP1;
                }
                else if (p2Character == "Zelda" && p3Character == "Zelda" && p4Character != "Zelda")
                {
                    kosAgainstZelda = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Zelda" && p3Character != "Zelda" && p4Character == "Zelda")
                {
                    kosAgainstZelda = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Zelda" && p3Character == "Zelda" && p4Character == "Zelda")
                {
                    kosAgainstZelda = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Zelda" && p3Character == "Zelda" && p4Character == "Zelda")
                {
                    kosAgainstZelda = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstZelda;

        }

        //################################# End Zelda determination ############################################



        //################################# Start Zero Suit determination ############################################
        public static int DetermineKosZeroSuit(string p2Character, string p2KosForP1, string p3Character, string p3KosForP1, string p4Character, string p4KosForP1)
        {
            int kosAgainstZeroSuit = 0;


            int p2NumOfKosForP1 = Convert.ToInt32(p2KosForP1);
            int p3NumOfKosForP1 = Convert.ToInt32(p3KosForP1);
            int p4NumOfKosForP1 = Convert.ToInt32(p4KosForP1);



            if (p2Character == "Zero Suit Samus" || p3Character == "Zero Suit Samus" || p4Character == "Zero Suit Samus")
            {
                if (p2Character == "Zero Suit Samus" && p3Character != "Zero Suit Samus" && p4Character != "Zero Suit Samus")
                {
                    kosAgainstZeroSuit = p2NumOfKosForP1;
                }
                else if (p2Character != "Zero Suit Samus" && p3Character == "Zero Suit Samus" && p4Character != "Zero Suit Samus")
                {
                    kosAgainstZeroSuit = p3NumOfKosForP1;
                }
                else if (p2Character != "Zero Suit Samus" && p3Character != "Zero Suit Samus" && p4Character == "Zero Suit Samus")
                {
                    kosAgainstZeroSuit = p4NumOfKosForP1;
                }
                else if (p2Character == "Zero Suit Samus" && p3Character == "Zero Suit Samus" && p4Character != "Zero Suit Samus")
                {
                    kosAgainstZeroSuit = p2NumOfKosForP1 + p3NumOfKosForP1;
                }
                else if (p2Character == "Zero Suit Samus" && p3Character != "Zero Suit Samus" && p4Character == "Zero Suit Samus")
                {
                    kosAgainstZeroSuit = p2NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character != "Zero Suit Samus" && p3Character == "Zero Suit Samus" && p4Character == "Zero Suit Samus")
                {
                    kosAgainstZeroSuit = p3NumOfKosForP1 + p4NumOfKosForP1;
                }
                else if (p2Character == "Zero Suit Samus" && p3Character == "Zero Suit Samus" && p4Character == "Zero Suit Samus")
                {
                    kosAgainstZeroSuit = p2NumOfKosForP1 + p3NumOfKosForP1 + p4NumOfKosForP1;
                }

            }

            return kosAgainstZeroSuit;

        }

        //################################# End Zero Suit determination ############################################
    }
}
