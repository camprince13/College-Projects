﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Super_Smash_Stat_Tracker
{
    public partial class Edit : Form
    {
        public Edit()
        {
            InitializeComponent();
        }

        public UserName EditID;

        private void Edit_Load(object sender, EventArgs e)
        {
            UserRegistration temp = new UserRegistration();

            lblUserName.Text = "User ID: " + EditID.StrUserID;
            txtUserName.Text = temp.EditName(EditID.StrUserID);
            txtPassword.Text = temp.EditPass(EditID.StrUserID);
        }


        private void btnEdit_Click(object sender, EventArgs e)
        {
            UserRegistration Edit = new UserRegistration();

            Edit.UserName = txtUserName.Text;
            Edit.Password = txtPassword.Text;
            Edit.ReEnteredPass = txtPassword2.Text;

            if (Edit.FeedBack.Contains("ERROR:"))
            {
                lblFeedBack.Text = Edit.FeedBack;
            }
            else if (txtPassword.Text != txtPassword2.Text)
            {
                lblFeedBack.Text = "ERROR: Re-Entered password does not match original.";
            }
            else
            {
                lblFeedBack.Text = Edit.UpdateUser(EditID.StrUserID);

            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            UserName temp = new UserName();



            lblFeedBack.Text = temp.ResetUser(EditID.StrUserID);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            AreYouSure temp = new AreYouSure();
            temp.Show();
        }

        private void btnHelp2_Click(object sender, EventArgs e)
        {
            MiscFunc.openwiki(7);
        }

        

        
    }
}
