﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Super_Smash_Stat_Tracker
{
    public partial class Login : Form
    {
        

        public Login()
        {
            InitializeComponent();
            
        }

        
       

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        

        public void btnLogin_Click(object sender, EventArgs e)
        {
            lblFeedBack.Text = "";
            UserName ID = new UserName();
            ID.StrUserID = GetUserID(txtUserName.Text, txtPassword.Text); 
                                       

            string LoginInfo = UserLogin(txtUserName.Text, txtPassword.Text);
            if (LoginInfo == txtPassword.Text && txtPassword.Text != "" && txtUserName.Text != "")
            {

                lblFeedBack.Text = ID.StrUserID;
                ChooseGen temp = new ChooseGen();
                temp.IDGen = ID;
                lblFeedBack.Visible = false;
                temp.Show();
                
            }

            else 
            {
                lblFeedBack.Visible = true;
                lblFeedBack.Text = "Invalid Login Info!";
            }
            
           
        }

        private void btnRegi_Click(object sender, EventArgs e)
        {
            CreateAnAccount temp = new CreateAnAccount();

            temp.Show();
        }
    
    
        private string UserLogin(string strUser, string strPass)
        {
            string PassWord = "";

            SqlDataReader dr;
     

            SqlCommand comm = new SqlCommand();

            String StrSQL = "SELECT Pass FROM ssbpt WHERE (Name=@Name AND Pass=@Pass)";

            

            comm.Parameters.AddWithValue("@Name", strUser);
            comm.Parameters.AddWithValue("@Pass", strPass);

            SqlConnection conn = new SqlConnection();

            string strConn = ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            comm.Connection = conn;
            comm.CommandText = StrSQL;

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                PassWord = Convert.ToString(dr["Pass"]); 
            }

            conn.Close();

            return PassWord;

}

        private string GetUserID(string strUser , string strPass)
        {
            string UserID = "";

            SqlDataReader dr;


            SqlCommand comm = new SqlCommand();

            String StrSQL = "SELECT User_ID FROM ssbpt WHERE (Name=@Name AND Pass=@Pass)";



            comm.Parameters.AddWithValue("@Name", strUser);
            comm.Parameters.AddWithValue("@Pass", strPass);

            SqlConnection conn = new SqlConnection();

            string strConn = ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            comm.Connection = conn;
            comm.CommandText = StrSQL;

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                UserID = Convert.ToString(dr["User_ID"]);
            }

            conn.Close();

            return UserID;
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            MiscFunc.openwiki(7);
        }
        

        
}
}