﻿namespace Super_Smash_Stat_Tracker
{
    partial class MatchUp64
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MatchUp64));
            this.btnHelp = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblOPDesc = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbOpChar = new System.Windows.Forms.ComboBox();
            this.lblYourDesc = new System.Windows.Forms.Label();
            this.cbYouChar = new System.Windows.Forms.ComboBox();
            this.lblKos = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.lblWins = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblLosses = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblOpKos = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblOpLosses = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblOpWins = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnHelp
            // 
            this.btnHelp.Location = new System.Drawing.Point(1, 262);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(75, 23);
            this.btnHelp.TabIndex = 6;
            this.btnHelp.Text = "Help";
            this.btnHelp.UseVisualStyleBackColor = true;
            this.btnHelp.Click += new System.EventHandler(this.btnHelp_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(639, 262);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.BackColor = System.Drawing.Color.Transparent;
            this.lblDescription.ForeColor = System.Drawing.Color.White;
            this.lblDescription.Location = new System.Drawing.Point(386, 105);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(91, 13);
            this.lblDescription.TabIndex = 28;
            this.lblDescription.Text = "Short Description:";
            // 
            // lblOPDesc
            // 
            this.lblOPDesc.AutoSize = true;
            this.lblOPDesc.BackColor = System.Drawing.Color.Transparent;
            this.lblOPDesc.ForeColor = System.Drawing.Color.White;
            this.lblOPDesc.Location = new System.Drawing.Point(480, 105);
            this.lblOPDesc.Name = "lblOPDesc";
            this.lblOPDesc.Size = new System.Drawing.Size(0, 13);
            this.lblOPDesc.TabIndex = 27;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(34, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 13);
            this.label4.TabIndex = 26;
            this.label4.Text = "Short Description:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(34, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 13);
            this.label3.TabIndex = 25;
            this.label3.Text = "Your Character:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(387, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 24;
            this.label2.Text = "Opponent:";
            // 
            // cbOpChar
            // 
            this.cbOpChar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbOpChar.FormattingEnabled = true;
            this.cbOpChar.Items.AddRange(new object[] {
            "Captain Falcon",
            "Donkey Kong",
            "Fox",
            "Jigglypuff",
            "Kirby",
            "Link",
            "Luigi",
            "Mario",
            "Ness",
            "Pikachu",
            "Samus",
            "Yoshi"});
            this.cbOpChar.Location = new System.Drawing.Point(450, 73);
            this.cbOpChar.Name = "cbOpChar";
            this.cbOpChar.Size = new System.Drawing.Size(121, 21);
            this.cbOpChar.TabIndex = 23;
            // 
            // lblYourDesc
            // 
            this.lblYourDesc.AutoSize = true;
            this.lblYourDesc.BackColor = System.Drawing.Color.Transparent;
            this.lblYourDesc.ForeColor = System.Drawing.Color.White;
            this.lblYourDesc.Location = new System.Drawing.Point(131, 105);
            this.lblYourDesc.Name = "lblYourDesc";
            this.lblYourDesc.Size = new System.Drawing.Size(0, 13);
            this.lblYourDesc.TabIndex = 29;
            // 
            // cbYouChar
            // 
            this.cbYouChar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbYouChar.FormattingEnabled = true;
            this.cbYouChar.Items.AddRange(new object[] {
            "Captain Falcon",
            "Donkey Kong",
            "Fox",
            "Jigglypuff",
            "Kirby",
            "Link",
            "Luigi",
            "Mario",
            "Ness",
            "Pikachu",
            "Samus",
            "Yoshi"});
            this.cbYouChar.Location = new System.Drawing.Point(121, 73);
            this.cbYouChar.Name = "cbYouChar";
            this.cbYouChar.Size = new System.Drawing.Size(121, 21);
            this.cbYouChar.TabIndex = 30;
            // 
            // lblKos
            // 
            this.lblKos.AutoSize = true;
            this.lblKos.BackColor = System.Drawing.Color.Transparent;
            this.lblKos.ForeColor = System.Drawing.Color.White;
            this.lblKos.Location = new System.Drawing.Point(158, 180);
            this.lblKos.Name = "lblKos";
            this.lblKos.Size = new System.Drawing.Size(0, 13);
            this.lblKos.TabIndex = 32;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(34, 180);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 13);
            this.label6.TabIndex = 31;
            this.label6.Text = "Ko\'s Against Opponent:";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(321, 262);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSubmit.TabIndex = 33;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // lblWins
            // 
            this.lblWins.AutoSize = true;
            this.lblWins.BackColor = System.Drawing.Color.Transparent;
            this.lblWins.ForeColor = System.Drawing.Color.White;
            this.lblWins.Location = new System.Drawing.Point(81, 226);
            this.lblWins.Name = "lblWins";
            this.lblWins.Size = new System.Drawing.Size(0, 13);
            this.lblWins.TabIndex = 35;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(39, 208);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 13);
            this.label7.TabIndex = 34;
            this.label7.Text = "Overall Record:";
            // 
            // lblLosses
            // 
            this.lblLosses.AutoSize = true;
            this.lblLosses.BackColor = System.Drawing.Color.Transparent;
            this.lblLosses.ForeColor = System.Drawing.Color.White;
            this.lblLosses.Location = new System.Drawing.Point(81, 246);
            this.lblLosses.Name = "lblLosses";
            this.lblLosses.Size = new System.Drawing.Size(0, 13);
            this.lblLosses.TabIndex = 37;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(42, 226);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 13);
            this.label9.TabIndex = 36;
            this.label9.Text = "Wins:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(33, 246);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 38;
            this.label5.Text = "Losses:";
            // 
            // lblOpKos
            // 
            this.lblOpKos.AutoSize = true;
            this.lblOpKos.BackColor = System.Drawing.Color.Transparent;
            this.lblOpKos.ForeColor = System.Drawing.Color.White;
            this.lblOpKos.Location = new System.Drawing.Point(538, 180);
            this.lblOpKos.Name = "lblOpKos";
            this.lblOpKos.Size = new System.Drawing.Size(0, 13);
            this.lblOpKos.TabIndex = 40;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(387, 180);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(142, 13);
            this.label10.TabIndex = 39;
            this.label10.Text = "Ko\'s Against Your Character:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(381, 246);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 13);
            this.label8.TabIndex = 45;
            this.label8.Text = "Losses:";
            // 
            // lblOpLosses
            // 
            this.lblOpLosses.AutoSize = true;
            this.lblOpLosses.BackColor = System.Drawing.Color.Transparent;
            this.lblOpLosses.ForeColor = System.Drawing.Color.White;
            this.lblOpLosses.Location = new System.Drawing.Point(429, 246);
            this.lblOpLosses.Name = "lblOpLosses";
            this.lblOpLosses.Size = new System.Drawing.Size(0, 13);
            this.lblOpLosses.TabIndex = 44;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(390, 226);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(34, 13);
            this.label12.TabIndex = 43;
            this.label12.Text = "Wins:";
            // 
            // lblOpWins
            // 
            this.lblOpWins.AutoSize = true;
            this.lblOpWins.BackColor = System.Drawing.Color.Transparent;
            this.lblOpWins.ForeColor = System.Drawing.Color.White;
            this.lblOpWins.Location = new System.Drawing.Point(429, 226);
            this.lblOpWins.Name = "lblOpWins";
            this.lblOpWins.Size = new System.Drawing.Size(0, 13);
            this.lblOpWins.TabIndex = 42;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(387, 208);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 13);
            this.label14.TabIndex = 41;
            this.label14.Text = "Overall Record:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(187, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(342, 48);
            this.pictureBox1.TabIndex = 46;
            this.pictureBox1.TabStop = false;
            // 
            // MatchUp64
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(716, 284);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lblOpLosses);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.lblOpWins);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.lblOpKos);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblLosses);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lblWins);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.lblKos);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cbYouChar);
            this.Controls.Add(this.lblYourDesc);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.lblOPDesc);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbOpChar);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnHelp);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MatchUp64";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnHelp;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Label lblOPDesc;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbOpChar;
        private System.Windows.Forms.Label lblYourDesc;
        private System.Windows.Forms.ComboBox cbYouChar;
        private System.Windows.Forms.Label lblKos;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Label lblWins;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblLosses;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblOpKos;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblOpLosses;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblOpWins;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}