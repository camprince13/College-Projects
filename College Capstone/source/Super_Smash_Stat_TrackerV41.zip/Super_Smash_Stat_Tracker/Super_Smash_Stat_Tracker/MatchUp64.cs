﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Super_Smash_Stat_Tracker
{
    public partial class MatchUp64 : Form
    {
        public MatchUp64()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            Matchup matchup64 = new Matchup();

            matchup64.Character = cbYouChar.Text;
            matchup64.OpponentCharacter = cbOpChar.Text;

            lblYourDesc.Text = matchup64.Description64();
            lblYourDesc.Text = lblYourDesc.Text.Replace("<br/>", "\r\n");

            lblOPDesc.Text = matchup64.OpponentDescription64();
            lblOPDesc.Text = lblOPDesc.Text.Replace("<br/>", "\r\n");

            lblKos.Text = matchup64.KosAgainst64(matchup64.OpponentCharacter , matchup64.Character);
            lblOpKos.Text = matchup64.KosAgainst64(matchup64.Character , matchup64.OpponentCharacter);
            lblWins.Text = matchup64.Wins64(matchup64.Character);
            lblLosses.Text = matchup64.Losses64(matchup64.Character);
            lblOpWins.Text = matchup64.Wins64(matchup64.OpponentCharacter);
            lblOpLosses.Text = matchup64.Losses64(matchup64.OpponentCharacter);
            

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            MiscFunc.openwiki(7);
        }

        

        
    }
}
