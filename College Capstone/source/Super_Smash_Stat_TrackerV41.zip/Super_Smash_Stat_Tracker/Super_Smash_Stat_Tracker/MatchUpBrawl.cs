﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Super_Smash_Stat_Tracker
{
    public partial class MatchUpBrawl : Form
    {
        public MatchUpBrawl()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            Matchup matchupBrawl = new Matchup();

            matchupBrawl.Character = cbYouChar.Text;
            matchupBrawl.OpponentCharacter = cbOpChar.Text;

            lblYourDesc.Text = matchupBrawl.DescriptionBrawl();
            lblOPDesc.Text = matchupBrawl.OpponentDescriptionBrawl();

            lblYourDesc.Text = lblYourDesc.Text.Replace("<br/>", "\r\n");
            lblOPDesc.Text = lblOPDesc.Text.Replace("<br/>", "\r\n");

            lblKos.Text = matchupBrawl.KosAgainstBrawl(matchupBrawl.OpponentCharacter , matchupBrawl.Character);
            lblOpKos.Text = matchupBrawl.KosAgainstBrawl(matchupBrawl.Character , matchupBrawl.OpponentCharacter);
            lblWins.Text = matchupBrawl.WinsBrawl(matchupBrawl.Character);
            lblLosses.Text = matchupBrawl.LossesBrawl(matchupBrawl.Character);
            lblOpWins.Text = matchupBrawl.WinsBrawl(matchupBrawl.OpponentCharacter);
            lblOpLosses.Text = matchupBrawl.LossesBrawl(matchupBrawl.OpponentCharacter);
        }     

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            MiscFunc.openwiki(7);
        }

        
    }
}
