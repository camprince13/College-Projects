﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Super_Smash_Stat_Tracker
{
    public partial class MatchUpMelee : Form
    {
        public MatchUpMelee()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            Matchup matchupMelee = new Matchup();

            matchupMelee.Character = cbYouChar.Text;
            matchupMelee.OpponentCharacter = cbOpChar.Text;

            lblYourDesc.Text = matchupMelee.DescriptionMelee();
            lblYourDesc.Text = lblYourDesc.Text.Replace("<br/>", "\r\n");

            lblOPDesc.Text = matchupMelee.OpponentDescriptionMelee();
            lblOPDesc.Text = lblOPDesc.Text.Replace("<br/>", "\r\n");

            lblKos.Text = matchupMelee.KosAgainstMelee(matchupMelee.OpponentCharacter , matchupMelee.Character);
            lblOpKos.Text = matchupMelee.KosAgainstMelee(matchupMelee.Character , matchupMelee.OpponentCharacter);
            lblWins.Text = matchupMelee.WinsMelee(matchupMelee.Character);
            lblLosses.Text = matchupMelee.LossesMelee(matchupMelee.Character);
            lblOpWins.Text = matchupMelee.WinsMelee(matchupMelee.OpponentCharacter);
            lblOpLosses.Text = matchupMelee.LossesMelee(matchupMelee.OpponentCharacter);

        }

        private void btnExit_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            MiscFunc.openwiki(7);
        }

       
    }
}
