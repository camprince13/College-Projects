﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Super_Smash_Stat_Tracker
{
    public partial class MatchUpSmash4 : Form
    {
        public MatchUpSmash4()
        {
            InitializeComponent();
        }


        private void btnSubmit_Click(object sender, EventArgs e)
        {
            Matchup matchupSmash4 = new Matchup();

            matchupSmash4.Character = cbYouChar.Text;
            matchupSmash4.OpponentCharacter = cbOpChar.Text;

            lblYourDesc.Text = matchupSmash4.DescriptionSmash4();
            lblOPDesc.Text = matchupSmash4.OpponentDescriptionSmash4();

            lblYourDesc.Text = lblYourDesc.Text.Replace("<br/>", "\r\n");
            lblOPDesc.Text = lblOPDesc.Text.Replace("<br/>", "\r\n");

            lblKos.Text = matchupSmash4.KosAgainstSmash4(matchupSmash4.OpponentCharacter , matchupSmash4.Character);
            lblOpKos.Text = matchupSmash4.KosAgainstSmash4(matchupSmash4.Character, matchupSmash4.OpponentCharacter);
            lblWins.Text = matchupSmash4.WinsSmash4(matchupSmash4.Character);
            lblLosses.Text = matchupSmash4.LossesSmash4(matchupSmash4.Character);
            lblOpWins.Text = matchupSmash4.WinsSmash4(matchupSmash4.OpponentCharacter);
            lblOpLosses.Text = matchupSmash4.LossesSmash4(matchupSmash4.OpponentCharacter);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            MiscFunc.openwiki(7);
        }
    }
}
