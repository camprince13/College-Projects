﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace Super_Smash_Stat_Tracker
{
    class Matchup
    {
        private string character;
        private string opponentCharacter;

        public string Character
        {
            get { return character; }
            set { character = value; }
        }
        public string OpponentCharacter
        {
            get { return opponentCharacter; }
            set { opponentCharacter = value; }
        }

        //###################################### Smash64 Matchup Stuff ############################################
        public string Description64()
        {
            string description = "";

            SqlDataReader dr;

            string strSQL = "SELECT Short_Desc FROM SSBG64 WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = @ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char", Character);

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                description = Convert.ToString(dr["Short_Desc"]);
            }

            conn.Close();

            return description;


        }

        public string OpponentDescription64()
        {
            string description = "";

            SqlDataReader dr;

            string strSQL = "SELECT Short_Desc FROM SSBG64 WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = @ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char", OpponentCharacter);

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                description = Convert.ToString(dr["Short_Desc"]);
            }

            conn.Close();

            return description;


        }

        public string KosAgainst64(string strOpponent, string strCharacter)
        {
            string Kos = "";

            SqlDataReader dr;

            string strSQL = "SELECT CaptainFalcon_ , DonkeyKong_ , Fox_ , JigglyPuff_, Kirby_ , Link_ , Luigi_ , Mario_ , Ness_ , Pikachu_ , Samus_, Yoshi_ FROM SSBG64 WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = @ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char", strCharacter);

            conn.Open();
            dr = comm.ExecuteReader();

            if (strOpponent == "Captain Falcon")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["CaptainFalcon_"]);
                }
            }
            else if (strOpponent == "Donkey Kong")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["DonkeyKong_"]);
                }
            }
            else if (strOpponent == "Fox")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Fox_"]);
                }
            }
            else if (strOpponent == "Jigglypuff")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["JigglyPuff_"]);
                }
            }
            else if (strOpponent == "Kirby")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Kirby_"]);
                }
            }
            else if (strOpponent == "Link")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Link_"]);
                }
            }
            else if (strOpponent == "Luigi")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Luigi_"]);
                }
            }
            else if (strOpponent == "Mario")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Mario_"]);
                }
            }
            else if (strOpponent == "Ness")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Ness_"]);
                }
            }
            else if (strOpponent == "Pikachu")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Pikachu_"]);
                }
            }
            else if (strOpponent == "Samus")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Samus_"]);
                }
            }
            else if (strOpponent == "Yoshi")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Yoshi_"]);
                }
            }
            conn.Close();

            return Kos;


        }

        public string Wins64(string strCharacter)
        {
            string strWins = "";

            SqlDataReader dr;

            string strSQL = "SELECT Wins FROM SSBG64 WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char" , strCharacter);

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                strWins = Convert.ToString(dr["Wins"]);
            }

            conn.Close();

            return strWins;
        }

        public string Losses64(string strCharacter)
        {
            string strLosses = "";

            SqlDataReader dr;

            string strSQL = "SELECT Losses FROM SSBG64 WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char", strCharacter);

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                strLosses = Convert.ToString(dr["Losses"]);
            }

            conn.Close();

            return strLosses;
        }

        //###################################### End Smash64 Matchup Stuff ############################################


        //###################################### Melee Matchup Stuff ############################################

        public string DescriptionMelee()
        {
            string description = "";

            SqlDataReader dr;

            string strSQL = "SELECT ShortDesc FROM SSBGM WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = @ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char", Character);

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                description = Convert.ToString(dr["ShortDesc"]);
            }

            conn.Close();

            return description;


        }

        public string OpponentDescriptionMelee()
        {
            string description = "";

            SqlDataReader dr;

            string strSQL = "SELECT ShortDesc FROM SSBGM WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = @ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char", OpponentCharacter);

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                description = Convert.ToString(dr["ShortDesc"]);
            }

            conn.Close();

            return description;


        }

        public string KosAgainstMelee(string strOpponent, string strCharacter)
        {
            string Kos = "";

            SqlDataReader dr;

            string strSQL = "SELECT Bowser_ , CaptainFalcon_ , DonkeyKong_ , DrMario_ , Falco_ , Fox_ , Ganondorf_ , IceClimbers_ , Jigglypuff_ , Kirby_ , Link_ , Luigi_ ,Mario_ , Marth_ , Mewtwo_ , MrGameWatch_ , Ness_ , Peach_ , Pichu_ , Pikachu_ , Roy_ , Samus_ , Yoshi_ , YoungLink_ , Zelda_Sheik_ FROM SSBGM WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = @ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char", strCharacter);

            conn.Open();
            dr = comm.ExecuteReader();


            if (strOpponent == "Bowser")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Bowser_"]);
                }
            }
            else if (strOpponent == "Captain Falcon")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["CaptainFalcon_"]);
                }
            }
            else if (strOpponent == "Donkey Kong")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["DonkeyKong_"]);
                }
            }
            else if (strOpponent == "Dr.Mario")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["DrMario_"]);
                }
            }
            else if (strOpponent == "Falco")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Falco_"]);
                }
            }
            else if (strOpponent == "Fox")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Fox_"]);
                }
            }
            else if (strOpponent == "Ganondorf")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Ganondorf_"]);
                }
            }
            else if (strOpponent == "Ice Climbers")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["IceClimbers_"]);
                }
            }
            else if (strOpponent == "Jigglypuff")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["JigglyPuff_"]);
                }
            }
            else if (strOpponent == "Kirby")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Kirby_"]);
                }
            }
            else if (strOpponent == "Link")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Link_"]);
                }
            }
            else if (strOpponent == "Luigi")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Luigi_"]);
                }
            }
            else if (strOpponent == "Mario")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Mario_"]);
                }
            }
            else if (strOpponent == "Marth")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Marth_"]);
                }
            }
            else if (strOpponent == "Mewtwo")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Mewtwo_"]);
                }
            }
            else if (strOpponent == "Mr. Game & Watch")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["MrGameWatch_"]);
                }
            }
            else if (strOpponent == "Ness")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Ness_"]);
                }
            }
            else if (strOpponent == "Peach")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Peach_"]);
                }
            }
            else if (strOpponent == "Pichu")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Pichu_"]);
                }
            }
            else if (strOpponent == "Pikachu")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Pikachu_"]);
                }
            }
            else if (strOpponent == "Roy")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Roy_"]);
                }
            }
            else if (strOpponent == "Samus")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Samus_"]);
                }
            }
            else if (strOpponent == "Yoshi")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Yoshi_"]);
                }
            }
            else if (strOpponent == "Young Link")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["YoungLInk_"]);
                }
            }
            else if (strOpponent == "Zelda/Sheik")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Zelda_Sheik_"]);
                }
            }
            conn.Close();

            return Kos;


        }

        public string WinsMelee(string strCharacter)
        {
            string strWins = "";

            SqlDataReader dr;

            string strSQL = "SELECT Win FROM SSBGM WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char", strCharacter);

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                strWins = Convert.ToString(dr["Win"]);
            }

            conn.Close();

            return strWins;
        }

        public string LossesMelee(string strCharacter)
        {
            string strLosses = "";

            SqlDataReader dr;

            string strSQL = "SELECT Loss FROM SSBGM WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char", strCharacter);

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                strLosses = Convert.ToString(dr["Loss"]);
            }

            conn.Close();

            return strLosses;
        }

        //###################################### End Melee Matchup Stuff ############################################

        //###################################### Brawl Matchup Stuff ############################################

        public string DescriptionBrawl()
        {
            string description = "";

            SqlDataReader dr;

            string strSQL = "SELECT Short_Desc FROM SSBGB WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = @ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char", Character);

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                description = Convert.ToString(dr["Short_Desc"]);
            }

            conn.Close();

            return description;


        }

        public string OpponentDescriptionBrawl()
        {
            string description = "";

            SqlDataReader dr;

            string strSQL = "SELECT Short_Desc FROM SSBGB WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = @ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char", OpponentCharacter);

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                description = Convert.ToString(dr["Short_Desc"]);
            }

            conn.Close();

            return description;


        }

        public string KosAgainstBrawl(string strOpponent, string strCharacter)
        {
            string Kos = "";

            SqlDataReader dr;

            string strSQL = "SELECT Bowser_ , CaptainFalcon_ , DiddyKong_ , DonkeyKong_ ,  Falco_ , Fox_ , Ganondorf_ , IceClimbers_ , Ike_ ,Jigglypuff_ , KingDedede_ , Kirby_ , Link_ , Lucario_ , Lucas_ , Luigi_ , Mario_ , Marth_ , Metaknight_ , MrGameWatch_ , Ness_ , Olimar_ ,Peach_ , Pikachu_ , Pit_ , PokemonTrainer_ , ROB_ , Samus_and_Zero_Suit_ , Snake_ , Sonic_ , ToonLink_ , Wario_ , Wolf_ , Yoshi_ , Zelda_Sheik_ FROM SSBGB WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = @ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char", strCharacter);

            conn.Open();
            dr = comm.ExecuteReader();


            if (strOpponent == "Bowser")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Bowser_"]);
                }
            }
            else if (strOpponent == "Captain Falcon")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["CaptainFalcon_"]);
                }
            }
            else if (strOpponent == "Diddy Kong")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["DiddyKong_"]);
                }
            }
            else if (strOpponent == "Donkey Kong")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["DonkeyKong_"]);
                }
            }
            else if (strOpponent == "Falco")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Falco_"]);
                }
            }
            else if (strOpponent == "Fox")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Fox_"]);
                }
            }
            else if (strOpponent == "Ganondorf")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Ganondorf_"]);
                }
            }
            else if (strOpponent == "Ice Climbers")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["IceClimbers_"]);
                }
            }
            else if (strOpponent == "Ike")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Ike_"]);
                }
            }
            else if (strOpponent == "Jigglypuff")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["JigglyPuff_"]);
                }
            }
            else if (strOpponent == "King Dedede")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["KingDedede_"]);
                }
            }
            else if (strOpponent == "Kirby")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Kirby_"]);
                }
            }
            else if (strOpponent == "Link")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Link_"]);
                }
            }
            else if (strOpponent == "Lucario")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Lucario_"]);
                }
            }
            else if (strOpponent == "Lucas")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Lucas_"]);
                }
            }
            else if (strOpponent == "Luigi")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Luigi_"]);
                }
            }
            else if (strOpponent == "Mario")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Mario_"]);
                }
            }
            else if (strOpponent == "Marth")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Marth_"]);
                }
            }
            else if (strOpponent == "Metaknight")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Metaknight_"]);
                }
            }
            else if (strOpponent == "Mr. Game & Watch")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["MrGameWatch_"]);
                }
            }
            else if (strOpponent == "Ness")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Ness_"]);
                }
            }
            else if (strOpponent == "Olimar")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Olimar_"]);
                }
            }
            else if (strOpponent == "Peach")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Peach_"]);
                }
            }
            else if (strOpponent == "Pikachu")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Pikachu_"]);
                }
            }
            else if (strOpponent == "Pit")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Pit_"]);
                }
            }
            else if (strOpponent == "Pokemon Trainer")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["PokemonTrainer_"]);
                }
            }
            else if (strOpponent == "R.O.B")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["ROB_"]);
                }
            }
            else if (strOpponent == "Samus/Zero Suit Samus")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Samus_and_Zero_Suit_"]);
                }
            }
            else if (strOpponent == "Snake")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Snake_"]);
                }
            }
            else if (strOpponent == "Sonic")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Sonic_"]);
                }
            }
            else if (strOpponent == "Toon Link")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["ToonLink_"]);
                }
            }
            else if (strOpponent == "Wario")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Wario_"]);
                }
            }
            else if (strOpponent == "Wolf")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Wolf_"]);
                }
            }
            else if (strOpponent == "Yoshi")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Yoshi_"]);
                }
            }
            else if (strOpponent == "Zelda/Sheik")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Zelda_Sheik_"]);
                }
            }
            conn.Close();

            return Kos;


        }


        public string WinsBrawl(string strCharacter)
        {
            string strWins = "";

            SqlDataReader dr;

            string strSQL = "SELECT Wins FROM SSBGB WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char", strCharacter);

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                strWins = Convert.ToString(dr["Wins"]);
            }

            conn.Close();

            return strWins;
        }

        public string LossesBrawl(string strCharacter)
        {
            string strLosses = "";

            SqlDataReader dr;

            string strSQL = "SELECT Losses FROM SSBGB WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char", strCharacter);

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                strLosses = Convert.ToString(dr["Losses"]);
            }

            conn.Close();

            return strLosses;
        }

        //###################################### End Brawl Matchup Stuff ############################################


        //###################################### Smash4 Matchup Stuff ############################################

        public string DescriptionSmash4()
        {
            string description = "";

            SqlDataReader dr;

            string strSQL = "SELECT Short_Desc FROM SSBG4 WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = @ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char", Character);

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                description = Convert.ToString(dr["Short_Desc"]);
            }

            conn.Close();

            return description;


        }

        public string OpponentDescriptionSmash4()
        {
            string description = "";

            SqlDataReader dr;

            string strSQL = "SELECT Short_Desc FROM SSBG4 WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = @ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char", OpponentCharacter);

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                description = Convert.ToString(dr["Short_Desc"]);
            }

            conn.Close();

            return description;


        }

        public string KosAgainstSmash4(string strOpponent, string strCharacter)
        {
            string Kos = "";

            SqlDataReader dr;

            string strSQL = "SELECT Bowser_ , BowserJr_ ,CaptainFalcon_ , Charizard_ , DarkPit_ ,DiddyKong_ , DonkeyKong_ , DrMario_ , DuckHunt_ , Falco_ , Fox_ , Ganondorf_ , Greninja_ , Ike_ ,Jigglypuff_ , KingDedede_ , Kirby_ , Link_ , LittleMac_ ,Lucario_ , Lucina_ , Luigi_ , Mario_ , Marth_ , MegaMan_ , Metaknight_ , MrGameWatch_ , Ness_ , Olimar_ , PacMan_ , Palutena_ , Peach_ , Pikachu_ , Pit_ , ROB_ , Robin_ , RosalinaLuma_ , Samus_ , Sheik_ , Shulk_ , Sonic_ , ToonLink_ , Villager_ , Wario_ , WiiFitTrainer_ , Yoshi_ , Zelda_ , ZeroSuitSamus_ FROM SSBG4 WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = @ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char", strCharacter);

            conn.Open();
            dr = comm.ExecuteReader();

            if (strOpponent == "Bowser")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Bowser_"]);
                }
            }
                else if (strOpponent == "Bowser Jr.")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["BowserJr_"]);
                }
            }
            else if (strOpponent == "Captain Falcon")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["CaptainFalcon_"]);
                }
            }
            else if (strOpponent == "Charizard")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Charizard_"]);
                }
            }
            else if (strOpponent == "Dark Pit")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["DarkPit_"]);
                }
            }
            else if (strOpponent == "Diddy Kong")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["DiddyKong_"]);
                }
            }
            else if (strOpponent == "Donkey Kong")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["DonkeyKong_"]);
                }
            }
            else if (strOpponent == "Dr. Mario")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["DrMario"]);
                }
            }
            else if (strOpponent == "Duck Hunt")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["DuckHunt_"]);
                }
            }
            else if (strOpponent == "Falco")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Falco_"]);
                }
            }
            else if (strOpponent == "Fox")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Fox_"]);
                }
            }
            else if (strOpponent == "Ganondorf")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Ganondorf_"]);
                }
            }
            else if (strOpponent == "Greninja")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Greninja_"]);
                }
            }
            else if (strOpponent == "Ike")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Ike_"]);
                }
            }
            else if (strOpponent == "Jigglypuff")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["JigglyPuff_"]);
                }
            }
            else if (strOpponent == "King Dedede")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["KingDedede_"]);
                }
            }
            else if (strOpponent == "Kirby")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Kirby_"]);
                }
            }
            else if (strOpponent == "Link")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Link_"]);
                }
            }
            else if (strOpponent == "Little Mac")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["LittleMac_"]);
                }
            }
            else if (strOpponent == "Lucario")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Lucario_"]);
                }
            }
            else if (strOpponent == "Lucina")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Lucina_"]);
                }
            }
            else if (strOpponent == "Luigi")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Luigi_"]);
                }
            }
            else if (strOpponent == "Mario")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Mario_"]);
                }
            }
            else if (strOpponent == "Marth")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Marth_"]);
                }
            }
            else if (strOpponent == "Mega Man")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["MegaMan"]);
                }
            }
            else if (strOpponent == "Metaknight")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Metaknight_"]);
                }
            }
            else if (strOpponent == "Mr. Game & Watch")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["MrGameWatch_"]);
                }
            }
            else if (strOpponent == "Ness")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Ness_"]);
                }
            }
            else if (strOpponent == "Olimar")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Olimar_"]);
                }
            }
            else if (strOpponent == "Pac-Man")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["PacMan_"]);
                }
            }
            else if (strOpponent == "Palutena")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Palutena_"]);
                }
            }
            else if (strOpponent == "Peach")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Peach_"]);
                }
            }
            else if (strOpponent == "Pikachu")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Pikachu_"]);
                }
            }
            else if (strOpponent == "Pit")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Pit_"]);
                }
            }
            else if (strOpponent == "R.O.B")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["ROB_"]);
                }
            }
            else if (strOpponent == "Robin")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Robin_"]);
                }
            }
            else if (strOpponent == "Rosalina & Luma")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["RosalinaLuma_"]);
                }
            }
            else if (strOpponent == "Samus")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Samus_"]);
                }
            }
            else if (strOpponent == "Sheik")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Sheik_"]);
                }
            }
            else if (strOpponent == "Shulk")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Shulk_"]);
                }
            }
            else if (strOpponent == "Sonic")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Sonic_"]);
                }
            }
            else if (strOpponent == "Toon Link")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["ToonLink_"]);
                }
            }
            else if (strOpponent == "Villager")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Villager_"]);
                }
            }
            else if (strOpponent == "Wario")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Wario_"]);
                }
            }
            else if (strOpponent == "Wii Fit Trainer")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["WiiFitTrainer_"]);
                }
            }
            else if (strOpponent == "Yoshi")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Yoshi_"]);
                }
            }
            else if (strOpponent == "Zelda")
            {
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["Zelda_"]);
                }
            }
            else if (strOpponent == "Zero Suit Samus")
            { 
                while (dr.Read())
                {
                    Kos = Convert.ToString(dr["ZeroSuitSamus_"]);
                }
            }
            conn.Close();

            return Kos;


        }

        public string WinsSmash4(string strCharacter)
        {
            string strWins = "";

            SqlDataReader dr;

            string strSQL = "SELECT Wins FROM SSBG4 WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char", strCharacter);

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                strWins = Convert.ToString(dr["Wins"]);
            }

            conn.Close();

            return strWins;
        }

        public string LossesSmash4(string strCharacter)
        {
            string strLosses = "";

            SqlDataReader dr;

            string strSQL = "SELECT Losses FROM SSBG4 WHERE char=@char";
            SqlConnection conn = new SqlConnection();

            string strConn = ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@char", strCharacter);

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                strLosses = Convert.ToString(dr["Losses"]);
            }

            conn.Close();

            return strLosses;
        }

        //###################################### End Smash4 Matchup Stuff ############################################
    }
}
