﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Media;

namespace Super_Smash_Stat_Tracker
{
    class MiscFunc
    {
        public static int ChooseSou(int num)
        {System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"sound\MenuBrawl1.wav");
        if (num == 0)
        { player.Stop(); }
        else
        { player.PlayLooping(); }
        return num;
        }


        public static int boop(int num)
        {
            System.Media.SoundPlayer player2 = new System.Media.SoundPlayer(@"sound\BrawlSelect.wav");
            player2.Play();
            System.Threading.Thread.Sleep(950);
            return num;
        }

        public static int G64Sound(int num)
        {
            System.Media.SoundPlayer player3 = new System.Media.SoundPlayer(@"sound\CharSelect64.wav");
            if (num == 0)
            { player3.Stop(); }
            else
            { player3.PlayLooping(); }
            return num;
        }

        public static int GMSound(int num)
        {
            System.Media.SoundPlayer player4 = new System.Media.SoundPlayer(@"sound\CharSelectMelee.wav");
            if (num == 0)
            { player4.Stop(); }
            else
            { player4.PlayLooping(); }
            return num;
        }

        public static int GBSound(int num)
        {
            System.Media.SoundPlayer player5 = new System.Media.SoundPlayer(@"sound\CharSelectBrawl.wav");
            if (num == 0)
            { player5.Stop(); }
            else
            { player5.PlayLooping(); }
            return num;
        }

        public static int GS4Sound(int num)
        {
            System.Media.SoundPlayer player6 = new System.Media.SoundPlayer(@"sound\CharSelectS4.wav");
            if (num == 0)
            { player6.Stop(); }
            else
            { player6.PlayLooping(); }
            return num;
        }





        public static int openwiki(int num)
        {
            System.Diagnostics.Process.Start("http://www.ssbstw.somee.com/HelpMain.aspx");
        return num;
        }
        






    }//End Class


}
