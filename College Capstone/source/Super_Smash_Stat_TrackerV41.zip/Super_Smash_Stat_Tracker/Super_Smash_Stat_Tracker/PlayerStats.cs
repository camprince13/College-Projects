﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Super_Smash_Stat_Tracker
{
    public partial class PlayerStats : Form
    {
        public PlayerStats()
        {
            InitializeComponent();
        }

        public UserName PlayerID;

        private void PlayerStats_Load(object sender, EventArgs e)
        {
            lblUserID.Text = "User ID: " + PlayerID.StrUserID;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            ViewStats temp = new ViewStats();

            if (ValidationLibrary.userLettersAndNumbers(txtUser.Text) || txtUser.Text == "")
            {
                DataSet ds = temp.SearchPlayer(txtUser.Text);
                gvResults.DataSource = ds;
                gvResults.DataMember = ds.Tables["SSBPT"].ToString();
            }
            else 
            {
                lblFeedBack.Text = "Can only search using letters and numbers.";
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
