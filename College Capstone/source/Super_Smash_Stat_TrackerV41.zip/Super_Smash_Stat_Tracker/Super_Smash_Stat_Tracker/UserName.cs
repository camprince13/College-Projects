﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace Super_Smash_Stat_Tracker
{
    public class UserName
    {
        private string strUserID;


        public string StrUserID
        {
            get { return strUserID; }
            set { strUserID = value; }
        }

        public string ResetUser(string UserID)
        {
            string feedBack = "";



            string strSQL = "UPDATE SSBPT Set Win=@Wins , Loss=@Losses , TotKos=@TotKos , TotSDs=@TotSDs WHERE User_ID=@UserID";

            SqlConnection conn = new SqlConnection();

            string strConn = ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@Wins", 0);
            comm.Parameters.AddWithValue("@Losses", 0);
            comm.Parameters.AddWithValue("@TotKos", 0);
            comm.Parameters.AddWithValue("@TotSDs", 0);
            comm.Parameters.AddWithValue("@UserID", UserID);
            
            try
            {
                conn.Open();

                feedBack = comm.ExecuteNonQuery().ToString() + "User Reset";
                conn.Close();
            }
            catch (Exception err)
            {
                feedBack = "ERROR: " + err.Message;
            }

            return feedBack;
        }
    }
}
