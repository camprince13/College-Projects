﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace Super_Smash_Stat_Tracker
{
    class UserRegistration
    {

        private string userName;
        private string password;
        private string reEnteredPass;
        private string feedBack;

        
        public string UserName
        {
            get { return userName; }
            set {
                if (ValidationLibrary.isItFilledIn(value) == false)
                    feedBack += "ERROR: UserName cannot be left blank. \n";
                else if (ValidationLibrary.isWithinRange(value, 1, 25) == false)
                    feedBack += "ERROR: UserName must be less than 25 characters long. \n";
                else if (ValidationLibrary.userLettersAndNumbers(value) == false)
                    feedBack += "ERROR: UserName must start with a letter and contain only letters and numbers. \n";

                userName = value;
            }
            
        }

        public string Password
        {
            get { return password; }
            set {
                if (ValidationLibrary.isItFilledIn(value) == false)
                    feedBack += "ERROR: Password cannot be left blank. \n";
                else if (ValidationLibrary.isWithinRange(value, 3, 25) == false)
                    feedBack += "ERROR: Password must be between 3 and 25 characters long. \n";
                else if (ValidationLibrary.passLettersAndNumbers(value) == false)
                    feedBack += "ERROR: PassWord must contain only letters and numbers. \n";
                password = value;
            }
        }

        public string ReEnteredPass
        {
            get { return reEnteredPass; }
            set {
                if (ValidationLibrary.isItFilledIn(value) == false)
                    feedBack += "ERROR: Please re-enter your password in the provided field. \n"; 
                reEnteredPass = value;
            }
        }

        public string FeedBack
        {
            get { return feedBack; }
        }

        public UserRegistration()
        {
            feedBack = "";
        }

        public string CreateAccount()
        {
            string strFeedBack = "";

            string strSQL = "INSERT INTO ssbpt (Name, Pass, Win, Loss) VALUES(@Name, @Pass , @Wins ,@Losses)";
            SqlConnection conn = new SqlConnection();

            string strConn = @ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@Name",UserName);
            comm.Parameters.AddWithValue("@Pass", Password);
            comm.Parameters.AddWithValue("@Wins", 0);
            comm.Parameters.AddWithValue("@Losses", 0);

            try
            {
                conn.Open();

                strFeedBack = comm.ExecuteNonQuery().ToString() + "Records Added";
                conn.Close();
            }
            catch (Exception err)
            {
                strFeedBack = "ERROR: " + err.Message;
            }

            return strFeedBack;
        }

        public string UpdateUser(string UserID)
        {
            string strFeedBack = "";

            string strSQL = "UPDATE SSBPT SET Name=@Name , Pass=@Password WHERE User_ID=@UserID";
            SqlConnection conn = new SqlConnection();

            string strConn = @ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            

            comm.Parameters.AddWithValue("@Name", UserName);
            comm.Parameters.AddWithValue("@Password", Password);
            comm.Parameters.AddWithValue("@UserID", UserID);


            try
            {
                conn.Open();

                strFeedBack = comm.ExecuteNonQuery().ToString() + "Update Complete";
                conn.Close();
            }
            catch (Exception err)
            {
                strFeedBack = "ERROR: " + err.Message;
            }

            return strFeedBack;
        }

        public string EditName(string UserID)
        {
            string strName = "";

            SqlDataReader dr;


            SqlCommand comm = new SqlCommand();

            String StrSQL = "SELECT Name FROM ssbpt WHERE (User_ID=@UserID)";



            comm.Parameters.AddWithValue("@UserID", UserID);

            SqlConnection conn = new SqlConnection();

            string strConn = ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            comm.Connection = conn;
            comm.CommandText = StrSQL;

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                strName = Convert.ToString(dr["Name"]);
            }

            conn.Close();

            return strName;

        }

        public string EditPass(string UserID)
        {
            string strPass = "";

            SqlDataReader dr;


            SqlCommand comm = new SqlCommand();

            String StrSQL = "SELECT Pass FROM ssbpt WHERE (User_ID=@UserID)";



            comm.Parameters.AddWithValue("@UserID", UserID);

            SqlConnection conn = new SqlConnection();

            string strConn = ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            comm.Connection = conn;
            comm.CommandText = StrSQL;

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                strPass = Convert.ToString(dr["Pass"]);
            }

            conn.Close();

            return strPass;

        }

        public string DeleteUser(string UserID)
        {
            string strFeedBack = "";

            string strSQL = "DELETE FROM SSBPT WHERE User_ID=@UserID";
            SqlConnection conn = new SqlConnection();

            string strConn = @ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;


            comm.Parameters.AddWithValue("@UserID", UserID);


            try
            {
                conn.Open();

                strFeedBack = comm.ExecuteNonQuery().ToString() + "User Deleted.";
                conn.Close();
            }
            catch (Exception err)
            {
                strFeedBack = "ERROR: " + err.Message;
            }

            return strFeedBack;
        }

    }
}
