﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;


namespace Super_Smash_Stat_Tracker
{
    class ValidationLibrary
    {

        public static bool isItFilledIn(string strTemp)
        {
            bool result = false;
            if (strTemp != "")
            {
                result = true;
            }
            return result;
        }

        public static bool isItText(string strTemp)
        {
            bool result = false;
            Regex rgx = new Regex(@"^[a-zA-Z]+$");

            if (rgx.IsMatch(strTemp))
            {
                result = true;
            }
            return result;
        }


        public static bool isItNumeric(string strTemp)
        {
            bool result = false;
            Regex rgx = new Regex("[0-9]$");

            if (rgx.IsMatch(strTemp))
            {
                result = true;
            }
            return result;
        }

        public static bool isItPositive(string strTemp)
        {
            bool result = true;
            Regex rgx = new Regex("^-[0-9]$");

            if (rgx.IsMatch(strTemp))
            {
                result = false;
            }
            return result;
        }
        public static bool isItPoop(string strTemp)
        {
            bool result = true;
            if (strTemp == "Poop")
            {
                result = false;
            }
            return result;
        }

        public static bool isValidLength(string strTemp, int length)
        {

            bool result = false;
            if (strTemp.Length == length)
            {
                result = true;
            }
            return result;
        }

        public static bool isWithinRange(string strTemp, int intMinLen, int intMaxLen)
        {

            bool result = false;
            if (strTemp.Length >= intMinLen && strTemp.Length <= intMaxLen)
            {
                result = true;
            }
            return result;

        }

        public static bool isPhoneValid(string strTemp)
        {
            bool result = false;
            Regex rgx = new Regex("(\\([2-9]\\d\\d\\)|[2-9]\\d\\d) ?[-.,]? ?[2-9]\\d\\d ?[-.,]? ?\\d{4}");

            if (rgx.IsMatch(strTemp))
            {
                result = true;
            }
            return result;

        }


        public static bool isEmailValid(string strTemp)
        {
            bool result = false;
            Regex rgx = new Regex("^[a-z0-9][-a-z0-9.!#$%&'*+-=?^_`{|}~\\/]+@([-a-z0-9]+\\.)+[a-z]{2,5}$", RegexOptions.IgnoreCase);

            if (rgx.IsMatch(strTemp))
            {
                result = true;
            }
            return result;

        }

        public static bool isDateValid(string strTemp)
        {
            bool result = false;
            Regex rgx = new Regex("^(0[1-9]|1[0-2])\\/(0[1-9]|1\\d|2\\d|3[01])\\/\\d{4}$");

            if (rgx.IsMatch(strTemp))
            {
                result = true;
            }
            return result;
        }

        public static bool isIDValid(string strTemp)
        {
            bool result = false;
            Regex rgx = new Regex("^[1-9]{1}[a-zA-Z]{1}$");

            if (rgx.IsMatch(strTemp))
            {
                result = true;
            }
            return result;
        }

        public static bool userLettersAndNumbers(string strTemp)
        {
            bool result = false;
            Regex rgx = new Regex("^[a-zA-Z-]$|^[a-zA-Z][a-zA-Z-0-9]+$");

            if (rgx.IsMatch(strTemp))
            {
                result = true;
            }
            return result;
        }

        public static bool passLettersAndNumbers(string strTemp)
        {
            bool result = false;
            Regex rgx = new Regex("^[a-zA-Z-0-9]+$");

            if (rgx.IsMatch(strTemp))
            {
                result = true;
            }
            return result;
        }

    }

}