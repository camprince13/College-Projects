﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace Super_Smash_Stat_Tracker
{
    class ViewStats
    {
        public DataSet Search64()
        {
            DataSet ds = new DataSet();

            SqlCommand comm = new SqlCommand();

            String strSQL = "SELECT * FROM SSBG64 WHERE 0=0";


            


            SqlConnection conn = new SqlConnection();

            string strConn = ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;


            comm.Connection = conn;
            comm.CommandText = strSQL;

            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;

            conn.Open();
            da.Fill(ds, "SSBG64");
            conn.Close();


            return ds;
        }

        public DataSet SearchMelee()
        {
            DataSet ds = new DataSet();

            SqlCommand comm = new SqlCommand();

            String strSQL = "SELECT * FROM SSBGM WHERE 0=0";





            SqlConnection conn = new SqlConnection();

            string strConn = ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;


            comm.Connection = conn;
            comm.CommandText = strSQL;

            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;

            conn.Open();
            da.Fill(ds, "SSBGM");
            conn.Close();


            return ds;
        }

        public DataSet SearchBrawl()
        {
            DataSet ds = new DataSet();

            SqlCommand comm = new SqlCommand();

            String strSQL = "SELECT * FROM SSBGB WHERE 0=0";





            SqlConnection conn = new SqlConnection();

            string strConn = ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;


            comm.Connection = conn;
            comm.CommandText = strSQL;

            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;

            conn.Open();
            da.Fill(ds, "SSBGB");
            conn.Close();


            return ds;
        }

        public DataSet SearchSmash4()
        {
            DataSet ds = new DataSet();

            SqlCommand comm = new SqlCommand();

            String strSQL = "SELECT * FROM SSBG4 WHERE 0=0";





            SqlConnection conn = new SqlConnection();

            string strConn = ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;


            comm.Connection = conn;
            comm.CommandText = strSQL;

            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;

            conn.Open();
            da.Fill(ds, "SSBG4");
            conn.Close();


            return ds;
        }
        
        public DataSet SearchPlayer(string strName)
        {
            DataSet ds = new DataSet();

            SqlCommand comm = new SqlCommand();

            String strSQL = "SELECT Name, Win , Loss , TotKos, TotSDs FROM SSBPT WHERE 0=0";

            if (strName.Length > 0)
            {
                strSQL += " AND Name LIKE @Name";
                comm.Parameters.AddWithValue("@Name", "%" + strName + "%");
            }


            SqlConnection conn = new SqlConnection();

            string strConn = ConnectionStrings.ConnectionToUserDatabase();
            conn.ConnectionString = strConn;


            comm.Connection = conn;
            comm.CommandText = strSQL;

            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;

            conn.Open();
            da.Fill(ds, "SSBPT");
            conn.Close();


            return ds;
        }
    }
}
