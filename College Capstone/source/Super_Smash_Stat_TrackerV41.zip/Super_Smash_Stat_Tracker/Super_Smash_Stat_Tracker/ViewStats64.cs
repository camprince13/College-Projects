﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Super_Smash_Stat_Tracker
{
    public partial class ViewStats64 : Form
    {
        public ViewStats64()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void ViewStats64_Load(object sender, EventArgs e)
        {
            ViewStats temp = new ViewStats();

            DataSet ds = temp.Search64();
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = ds.Tables["SSBG64"].ToString();
        }

        
    }
}
