﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Super_Smash_Stat_Tracker
{
    public partial class ViewStatsBrawl : Form
    {
        public ViewStatsBrawl()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ViewStatsBrawl_Load(object sender, EventArgs e)
        {
            ViewStats temp = new ViewStats();

            DataSet ds = temp.SearchBrawl();
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = ds.Tables["SSBGB"].ToString();
        }
    }
}
