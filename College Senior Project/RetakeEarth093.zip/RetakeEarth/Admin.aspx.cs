﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["AccLvl"]) != "1") { Response.Redirect("Default.aspx"); }

        DBPerson temp = new DBPerson();
        VerbArea.InnerHtml = temp.VerbsToHTML();

    }//end page load


    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        if (txtTitle.Text != "" && txtBody.Text != "")
        {
            DBPerson temp = new DBPerson();
            string fdBack = temp.AddNews(Session["Uname"].ToString(), txtTitle.Text, txtBody.Text);
            if (fdBack == "1 Records added")
            {
                txtTitle.Text = "";
                txtBody.Text = "";
            }
            else
            { txtTitle.Text = fdBack; }
        }
    }//end button submit (news)


}//end page