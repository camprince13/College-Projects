﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for AI_Boss
/// </summary>

[Serializable]
public class AI_Boss : EnemyAI
{
    public AI_Boss(Team mine, Team notMine, Combat com)
        : base(mine, notMine)
	{
        myTeam = mine;
        theirTeam = notMine;
        combat = com;
        names = new string[] { "ƛ", "Ω", "□▪₴₡Ἇ", "ӶӃҥҍѹ฿", "ȪȞǪǧÆ¿" };
	}//end constructor

    private string output;
    private int assistTicker = 0;

    public override string turn(Creature cr)
    {
        //for now it is using the simple AI
        //it will have it's own stuff later

        if (cr.getTempHp() > 0)
        {

            if (assistTicker == 7) 
            {
                addMinion(cr);
                assistTicker = 0;
                return output;
            }//end if assistTicker == 7

            else if (cr.getHpPercent() <= 20)
            {
                heal(cr);
                assistTicker++;
                return output;
            }//end if low hp

            else
            {
                if (genRandomNum(0, 100) >= 45){targetedAtt(cr);}
                else {attRand(cr); }
                assistTicker++;
                return cr.getName() + output;
            }//end outer else

        }//end if alive

        return "";
    }//end turn

    #region functions

    private void attRand(Creature cr)
    {
        int rand = genRandomNum(0, theirTeam.length());
        Creature target = theirTeam.getCreature(rand);
        int dam = target.recieveDamage(cr.attack());
        theirTeam.setCreature(rand, target);
        output = " attacked " + target.getName() + " for " + dam + " damage.";
    }//end attRand

    private void targetedAtt(Creature cr)
    {
        int[] low = new int[theirTeam.length()];//get it? its a new low.

        for (int i = 0; i < theirTeam.length(); i++)
        {
            low[i] = theirTeam.getCreature(i).getTempHp();
        }//end for

        int min = low.Min();
        int tarIndx = Array.IndexOf(low, min);

        Creature target = theirTeam.getCreature(tarIndx);
        int dam = target.recieveDamage(cr.attack());
        theirTeam.setCreature(tarIndx, target);
        output = " attacked " + target.getName() + " for " + dam + " damage.";
        //output = " attacked " + target.getName();

    }//end targetedAtt

    private void heal(Creature cr)
    {
        cr.recieveHeals((cr.getHp() / 5));//20 --> 20%
        output = cr.getName() + " used weak potion on self";
    }//end heal

    private void addMinion(Creature cr)
    {

        Creature c = new Creature((cr.getName() + "'s Minion"), 7, 5);
        int tmpLvl = myTeam.getAvgLvl();
        c.recieveXp((tmpLvl * 120));
        myTeam.addCreature(c);
        output = cr.getName() + " summoned a minion";
    
    }//end addMinion

    #endregion

    public override string turn(Creature cr, int action, int target) { return ""; }
}//end class