﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for AI_Moderate
/// </summary>

[Serializable]
public class AI_Moderate : EnemyAI
{
    public AI_Moderate(Team mine, Team notMine, Combat com)
        : base(mine, notMine)
	{
        myTeam = mine;
        theirTeam = notMine;
        combat = com;
        names = new string[] { "Feral Human", "Alien Outcast", "Mutant", "Hostile Scavenger", "Gaggle-Hive-Mind-Mutant"};
	}//end constructor

    private string output;

    public override string turn(Creature cr)
    {
        //for now it is using the simple AI
        //it will have it's own stuff later

        if (cr.getTempHp() > 0)
        {
            if (cr.getHpPercent() < 33)//moderate ai only heals self
            {
                heal(cr);
                return output;
            }

            else
            {
                targetedAtt(cr);
                return cr.getName() + output;
            }

        }//end if alive

        return "";
    }//end turn



    #region functions
    private void attRand(Creature cr)
    {
        int rand = genRandomNum(0, theirTeam.length());
        Creature target = theirTeam.getCreature(rand);
        target.recieveDamage(cr.attack());
        theirTeam.setCreature(rand, target);
        output = " attacked " + target.getName();
    }//end attRand

    private void targetedAtt(Creature cr)
    { 
    int[] low = new int[theirTeam.length()];//get it? its a new low.

    for (int i = 0; i < theirTeam.length(); i++ ) 
    {
        low[i] = theirTeam.getCreature(i).getTempHp();
    }//end for

    int min = low.Min();
    int tarIndx = Array.IndexOf(low, min);

    Creature target = theirTeam.getCreature(tarIndx);
    int dam = target.recieveDamage(cr.attack());
    theirTeam.setCreature(tarIndx, target);
    output = " attacked " + target.getName() + " for " + dam + " damage.";
    //output = " attacked " + target.getName();

    }//end targetedAtt

    private void heal(Creature cr) 
    { 
     cr.recieveHeals((cr.getHp() / 5));//20 --> 20%
     output = cr.getName() + " used weak potion on self";
    }//end heal

    #endregion

    public override string turn(Creature cr, int action, int target) { return ""; }
}//end class