﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for AI_Player
/// ---------------------------------
/// not actually AI
/// this will house the player's actions
/// </summary>

[Serializable]
public class AI_Player : EnemyAI
{
	public AI_Player(Team mine, Team notMine, Combat com) : base(mine, notMine)
	{
        myTeam = mine;
        theirTeam = notMine;
        combat = com;
	}//end constructor

    #region variables
    //Combat combat;
    private string output;
    #endregion

    public override string turn(Creature cr)
    {
        //for now it is using the simple AI
        //it will have it's own stuff later

        if (cr.getTempHp() > 0)
        {
            attRand(cr);
            return cr.getName() + output;//" attacked a random opponent";
        }
        return "";
    }//end turn

    public override string turn(Creature cr, int action, int target)
    {
        #region attack / defend
        if (action == 0) {
            Creature victim = getTargetCreature(target);
            int dam = victim.recieveDamage(cr.attack());
            setTargetCreature(victim, target);
            output = cr.getName() + " attacked " + victim.getName() + " for " + dam + " damage.<br />";
            if (victim.getTempHp() == 0) { output +=victim.getName() +" defeated"; }
            theirTeam.totHealth();
            return output;
        }//end attack [action = 0]

        if (action == 1) { cr.defend();
        return cr.getName() + " defended.";
        }//end defend action [int of 1 = defend]

        #endregion

        #region health potions
        else if(action == 2){
            Creature victim = getTargetCreature(target);
            victim.recieveHeals((victim.getHp() / 5));//20 --> 20%
            setTargetCreature(victim, target);
            return cr.getName() + " used weak potion on " + victim.getName();
        }//end use sm.potion [int of 2]

        else if (action == 3)
        {
            Creature victim = getTargetCreature(target);
            victim.recieveHeals((victim.getHp() / 2));//100 --> 50 %
            setTargetCreature(victim, target);
            return cr.getName() + " used moderate potion on " + victim.getName();
        }//end use med.potion [int of 3]

        else if (action == 4)
        {
            Creature victim = getTargetCreature(target);
            victim.recieveHeals((victim.getHp()));//200 --> 100%
            setTargetCreature(victim, target);
            return cr.getName() + " used strong potion on " + victim.getName();
        }//end use lrg.potion [int of 4]

        #endregion

        #region buff FLASK

        else if (action == 5)
        {
            Creature victim = getTargetCreature(target);
            victim.setTempFortitude(cr.getTempFortitude() + 3);
            setTargetCreature(victim, target);
            return cr.getName() + " used fortitude buff on " + victim.getName();
        }//end use fortitude buff [int of 5]

        else if (action == 6)
        {
            Creature victim = getTargetCreature(target);
            victim.setTempLuck(cr.getTempLuck() + 3);
            setTargetCreature(victim, target);
            return cr.getName() + " used luck buff on " + victim.getName();
        }//end use luck buff [int of 6]

        else if (action == 7)
        {
            Creature victim = getTargetCreature(target);
            victim.setTempAgility(cr.getTempAgility() + 3);
            setTargetCreature(victim, target);
            return cr.getName() + " used agility buff on " + victim.getName();

        }//end use agility buff [int of 7]

        else if (action == 8)
        {
            Creature victim = getTargetCreature(target);
            victim.setTempStrength(cr.getTempStrength() + 3);
            setTargetCreature(victim, target);
            return cr.getName() + " used strength buff on " + victim.getName();
        }//end use Strength buff [int of 8]

        else if (action == 9)
        {
            Creature victim = getTargetCreature(target);
            victim.setTempKnowledge(cr.getTempKnowledge() + 3);
            setTargetCreature(victim, target);
            return cr.getName() + " used Knowledge buff on " + victim.getName();
        }//end use Knowledge buff [int of 9]

#endregion

        else if (action == 10)
        { 
        resTeammate();
        return output;
        }

        else { return ""; }
    }//end turn


    public void attRand(Creature cr) {
        int rand = genRandomNum(0, theirTeam.length());
        Creature target = theirTeam.getCreature(rand);
        target.recieveDamage(cr.attack());
        theirTeam.setCreature(rand, target);
        output = " attacked " + target.getName();
    }//end attRand

    /*
     run
     */

    private Creature getTargetCreature(int target)
    {

        if (0 <= target && target < theirTeam.length()) {
            return theirTeam.getCreature(target);
        }//their team creature [slot]
        
        else
        {
            target = target - theirTeam.length();
            return myTeam.getCreature(target);
        }
    }//end getTargetCreature

    private void setTargetCreature(Creature cre, int target)
    {
        if (0 <= target && target < theirTeam.length())
        {
            theirTeam.setCreature(target, cre);
        }//their team creature [slot]

        else
        {
            target = target - theirTeam.length();
            myTeam.setCreature(target, cre);
        }
    }//end setTargetCreature

    private void resTeammate() 
    {
        if (myTeam.deadLength() > 0) 
        {
            Creature tmp = myTeam.getDeadCreature(0);
            myTeam.removeDeadCreature(0);
            tmp.recieveHeals(10);
            myTeam.addCreature(tmp);
            output = "Revived " + tmp.getName();
        }
        else { output = "No one to revive. You wasted a turn."; }
    }//end resTeammate

}//end class