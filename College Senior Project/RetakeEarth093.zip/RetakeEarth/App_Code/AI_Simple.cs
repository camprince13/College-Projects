﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for AI_Simple
/// Simple AI
/// ---------
/// Attacks random creature on opposing team
/// nothing else
/// </summary>

[Serializable]
public class AI_Simple : EnemyAI
{
    public AI_Simple(Team mine, Team notMine, Combat com) : base(mine, notMine)
	{
        myTeam = mine;
        theirTeam = notMine;
        combat = com;
        names = new string[] { "Dog", "Legged Fish", "Mutant Squirrel", "Vicious Bird" };// (Known as a Goose in the ancient language)
	}//end constructor

    //Combat combat;

    //add more names for diversity
    //protected string[] names = new string[] { "Dog", "Legged Fish", "Mutant Squirrel" };

    public override string turn(Creature cr) {

        Creature target;

        if (cr.getTempHp() > 0)
        {
            int rand = genRandomNum(0, theirTeam.length());
            target = theirTeam.getCreature(rand);
            int dam = target.recieveDamage(cr.attack());
            theirTeam.setCreature(rand, target);
            return cr.getName() + " attacked " + target.getName() + " for " + dam + " damage.";
        }

        else { return ""; }

        //combat.refreshGUI();

    }//end turn

    public override string turn(Creature cr, int action, int target) { return ""; }

}//end class