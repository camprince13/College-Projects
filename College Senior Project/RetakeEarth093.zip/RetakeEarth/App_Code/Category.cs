﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient; //SQL database
using System.Data; //database

/// <summary>
/// Summary description for Category
/// </summary>

[Serializable]
public class Category
{
	public Category()
	{
		 
	}
    public DataSet GetCat()
        {
            //Create a dataset to return filled
            DataSet ds = new DataSet();

            //Create a command for our SQL statement
            SqlCommand comm = new SqlCommand();

            //SQL Statement
            String strSQL = "Select cat_name, cat_description, cat_id FROM categories";

            //Create DB tools and Configure
            //******************************************
            SqlConnection conn = new SqlConnection();
            string strConn = @DBLogin.GetConnected();
            conn.ConnectionString = strConn;
            comm.Connection = conn;
            comm.CommandText = strSQL;
            //Create Data Adapter
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;

            conn.Open();
            da.Fill(ds, "Forums");
            conn.Close();

            return ds;
        }//End Search Contacts

         public string CatToHTML() {
            DataSet ds = GetCat();


            List<string> title = ds.Tables[0].AsEnumerable()
                       .Select(r => r.Field<string>(0))
                       .ToList();

            List<string> desc = ds.Tables[0].AsEnumerable()
                      .Select(r => r.Field<string>(1))
                      .ToList();
            List<int> cat = ds.Tables[0].AsEnumerable()
                    .Select(r => r.Field<int>(2))
                    .ToList();

            String html = "";
             
            for (var i = 0; i < title.Count; i++)
            {
                html += "<a href='ForumTopics.aspx?cat=" + cat[i] +"'><p><h2>" + title[i] + "</h2>";
                html += desc[i] + "</a><br /><br />";
            }

            return html;
        }//end of CatToHTML







}//end of class