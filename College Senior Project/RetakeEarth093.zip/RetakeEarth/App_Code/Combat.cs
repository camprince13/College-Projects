﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for Combat
/// </summary>

[Serializable]
public class Combat
{
	public Combat(Team ax, Team al, int CombatSeed)
	{
        axis = ax;
        allies = al;

        //logic to decide what ai type[when available]
        if (CombatSeed == 0)
        {
            ai = new AI_Simple(axis, allies, this);
        }
        else if (CombatSeed == 1)
        {
            ai = new AI_Moderate(axis, allies, this);
        }
        else if (CombatSeed == 2)
        {
            ai = new AI_Boss(axis, allies, this);
        }


        playerAi = new AI_Player(allies, axis, this);//player ai

        if (axis.getCreature(0).getName() == "[]") 
        {
            if (ai.GetType().Name == "AI_Boss")
            { ai.genRandomBossTeam(); }
            else
            {
                ai.genRandomTeam();
            }
        }//end if empty team

        goFirst();
	}//End constructor

    #region variables
    Team axis = new Team();
    Team allies = new Team();
    EnemyAI ai;
    EnemyAI playerAi;
    bool playerStart = false;
    bool gameover = false;
    private bool win;
    private int tick = 0; //used to separate and determine who goes
    private int enTick = 0;//same as tick; but for bad guys
    private bool ticker = true; //used to say "good guy turn or bad guy turn"

    string allyText = "", enemyText = "", generalText = "";

    #endregion

    #region main
    public string[] mainSequence(){
        
            if (gameover == false) {

                generalText = "";

                if (ticker)
                {//if player turn

                    if (tick < playerAi.getMyTeam().length()) {
                        generalText += playerAi.turn(playerAi.getMyTeam().getCreature(tick)) + "<br />";
                        tick++;
                        axis.totHealth();
                        refreshGUI();
                    }

                    else if (tick >= playerAi.getMyTeam().length()) { 
                    tick = 0;
                    ticker = false;//no longer player turn
                    generalText += "Between turn segment. <br />";
                    //mainSequence();
                    }

                }//end if player turn

                else //enemy team 
                {

                    if (enTick < ai.getMyTeam().length())
                    {
                        generalText += ai.turn(ai.getMyTeam().getCreature(enTick)) + "<br />";
                        enTick++;
                        allies.totHealth();
                        refreshGUI();
                    }

                    else if (enTick >= ai.getMyTeam().length())
                    {
                        enTick = 0;
                        ticker = true;//no longer enemy turn
                        //mainSequence();
                        generalText += ai.getMyTeam().getCreature(0).getName() + " would attack, but it feels like it is it's destiny to let you go. <br />";
                    }
                
                }//end if enemy tem

            }//end if gameover

        string[] tmpReturn = {enemyText, allyText, generalText };

        return tmpReturn;
    }//end mainSequence
    ////////////////////////////////////////////////////////////////////////
    public string[] mainSequence(int action, int target)
    {
        if (gameover == false)
        {
            generalText = "";

            if (ticker)
            {//if player turn

                if (tick < playerAi.getMyTeam().length())
                {
                    if (action == 999) {
                        flee();
                    }

                    else
                    {
                        generalText += playerAi.turn(playerAi.getMyTeam().getCreature(tick), action, target) + "<br />";
                    }

                    if (generalText.Contains("defeated")) {
                        //moved xp to loot
                        loot();
                    }//adding xp

                    tick++;
                    axis.totHealth();
                    refreshGUI();

                    if (tick >= playerAi.getMyTeam().length()) {
                        tick = 0;
                        ticker = false;//no longer player turn
                        //generalText += "Don't be greedy, It's the enemy's turn. <br />";
                    }
                }//end within player team bounds

            }//end if player turn

            else //enemy team 
            {

                for (int i = 0; i < ai.getMyTeam().length() && allies.isDefeated() == false; i++)
                {
                    generalText += ai.turn(ai.getMyTeam().getCreature(enTick)) + "<br />";
                    enTick++;
                    allies.totHealth();
                    refreshGUI();

                    if (enTick >= ai.getMyTeam().length())
                    {
                        enTick = 0;
                        ticker = true;//no longer enemy turn
                    }

                }//end for

            }//end if enemy team

        }//end if gameover

        string[] tmpReturn = { enemyText, allyText, generalText };

        return tmpReturn;
    }//end mainSequence w/ action

    #endregion

    #region functions

    private void goFirst() {
        int axInit = ai.genRandomNum(0, 50);
        int alInit = ai.genRandomNum(0, 50);

        axInit += axis.getAvgLuck();
        axInit += axis.getAvgAgility();

        alInit += allies.getAvgLuck();
        alInit += allies.getAvgAgility();

        if (alInit >= axInit) { playerStart = true; ticker = true; }
        else { playerStart = false; ticker = false; }
    }//end goFirst

    public void refreshGUI() {

        enemyText = "";
        for (int i = 0; i < axis.length(); i++) {

            enemyText += "lvl " + (axis.getCreature(i).getLevel() + " ");

            if (axis.getCreature(i).getWeapon().getName() != "fists")
            { enemyText += (axis.getCreature(i).getName() + "* "); }

            else { enemyText += (axis.getCreature(i).getName() + " "); }

            
        enemyText += (axis.getCreature(i).getTempHp() + "/" + axis.getCreature(i).getHp());
        enemyText += ("<br />");
        }//end for

        allyText = "";
        for (int i = 0; i < allies.length(); i++)
        {
            allyText += "lvl " + (allies.getCreature(i).getLevel() + " ");
            allyText += (allies.getCreature(i).getName() + " ");
            allyText += (allies.getCreature(i).getTempHp() + "/" + allies.getCreature(i).getHp());
            allyText += ("<br />");
        }

        if(axis.isDefeated() || allies.isDefeated() )
        { gameover = true;
        generalText += "Conflict terminated, ";

        if (axis.isDefeated())
        {
            generalText += "you win";
            win = true;
        }

        else 
        {
            generalText += "you lose";
            win = false;
        }

        }//end if game over

    }//end refreshGUI

    public string[] getBasicGui() { refreshGUI();
    string[] tmpReturn = { enemyText, allyText, generalText };
    return tmpReturn;
    }//end getBasicGui

    public string[] getListOfTargets() {

        int x = (axis.length() + allies.length());
        string[] tmp = new string[x];
        int inty = 1;

        for (int i = 0; i < axis.length(); i++)
        {
                    tmp[i] = axis.getCreature(i).getName() + "  (" + inty + ")";
                    inty++;
            }

        for (int i = 0; i < allies.length(); i++ )//(x - axis.length()); i++)
        {
            tmp[(axis.length() + i)] = allies.getCreature(i).getName() + "  (" + inty + ")";
            inty++;
        }

            return tmp;
    }//end get list

    private void loot() {
        Weapon loot = axis.getDeadCreature((axis.deadLength() - 1)).getWeapon();
        Inventory inv = allies.getInventory();

        int xp = playerAi.genRandomNum(40, 62);//12, 21
        generalText += "Awarded "+xp +" xp";
        allies.awardXp(xp);
        //allies.getInventory().addCurrency(20);

        int money;

        if (loot.getName() != "fists")
        {
            inv.addItem(loot);
            generalText += ", a(n) " + loot.getName();
            money = playerAi.genRandomNum(1, 12);
        }

        else { money = playerAi.genRandomNum(12, 32); }
        //.addCurrency(20);    12, 32
          
        generalText += " and " + money + " credits.<br />";

        inv.addCurrency((money));
        allies.setInventory(inv);
    }//end loot

    private void flee(){

        int getAway = playerAi.getMyTeam().getAvgLuck();
        getAway += playerAi.getMyTeam().getAvgAgility();
        getAway += playerAi.genRandomNum(0, 20);
        int resistance = ai.getMyTeam().getAvgLuck();
        resistance += ai.getMyTeam().getAvgAgility();
        resistance += ai.genRandomNum(0, 20);
        if (getAway >= resistance)
        {
            generalText += "You ran away! Coward.<br />";
            gameover = true;
            win = true;
        }

        else { generalText += "You were going to run away, but the " + ai.getMyTeam().getCreature(0).getName() 
            + " made a rude gesture. Now you have to duke it out... for honor...<br />"; }

    }//end flee

    #endregion

    public Team getAllies() { return allies; }
    public Team getAxis() { return axis; }
    public bool getWinRes() { return win; }

}//end Class