﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Conversation
/// </summary>
[Serializable]
public class Conversation
{
    String[] DefaultDialogDictionary = new string[] { "What do you want?", "I don't like the looks of you, outsider", "Leave me alone outsider" };
    List<KeyValuePair<string, string>> SpecificDialogDictionary = new List<KeyValuePair<string, string>>();
    bool defaultDialog = true;

	public Conversation()
	{
        defaultDialog = true;
	}//end Conversation constructor

    public Conversation(List<KeyValuePair<string, string>> dialog)
    {
        SpecificDialogDictionary = dialog;
        defaultDialog = false;
    }//end Conversation constructor

    public bool GetDefaultDialogFlag(){
        return defaultDialog;
    }//end GetDefaultDialogFlag

    public string talk()
    {
            Random random = new Random();
            int randomNumber = random.Next(0, DefaultDialogDictionary.Length);
            return DefaultDialogDictionary[randomNumber];
    }//end talk
    public string talkSpecific(string key)
    {
        bool flag = false;
        int slot1 = 0;
        for (int i = 0; i < SpecificDialogDictionary.Count;i++ )
        {
            if(SpecificDialogDictionary[i].Key == key){
                slot1 = i;
                flag = true;
            }
        }

        if(flag){
            return SpecificDialogDictionary[slot1].Value;
        }
        else{
            return "It's pretty clear this person doesn't understand what you are saying...";
        }
    }
}//end Conversation Class