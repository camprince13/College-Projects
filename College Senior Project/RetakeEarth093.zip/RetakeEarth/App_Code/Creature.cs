﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Creature
/// Creature = player, npc, allies, enemies, monsters...
/// </summary>

[Serializable]
public class Creature
{
    #region constructors

    public Creature(string nm, int health, int attack)
	{
        name = nm;
        hp = health;
        att = attack;
        resetToFull();
	}//End constructor

    public Creature() { }//End constructor

    #endregion

    #region variables

    private string name = "[]";
    private int hp = 10;
    private int tempHp = 10;
    private int att = 2;
    private int tempAtt = 2;
    private int disp = 0; //disposition towards player

    private int fortitude = 0;//F.L.A.S.K
    private int luck = 0;
    private int agility = 0;
    private int strength = 0;
    private int knowledge = 0;

    private int tempFortitude = 0;
    private int tempLuck = 0;
    private int tempAgility = 0;
    private int tempStrength = 0;
    private int tempKnowledge = 0;

    private Weapon wep = new Weapon();
    private int level = 0;
    private int xp = 0;

    bool isDefending = false;

    #endregion

    #region getters

    public string getName() { return name; }
    public int getHp() { return hp; }
    public int getTempHp() { return tempHp; }
    public int getAtt() { return att; }
    public int getTempAtt() { return tempAtt; }
    public int getDisp() { return disp; }
    public int getFortitude() { return fortitude; }
    public int getLuck() { return luck; }
    public int getAgility() { return agility; }
    public int getStrength() { return strength; }
    public int getKnowledge() { return knowledge; }
    public int getTempFortitude() { return tempFortitude; }
    public int getTempLuck() { return tempLuck; }
    public int getTempAgility() { return tempAgility; }
    public int getTempStrength() { return tempStrength; }
    public int getTempKnowledge() { return tempKnowledge; }
    public Weapon getWeapon() { return wep; }
    public int getLevel() { return level; }
    public int getXp() { return xp; }

    public int getHpPercent() 
    {
        Double d = (tempHp / hp);
        return Convert.ToInt16(d * 100); 
    }

    #endregion

    #region setters

    public void setName(string name)
    {
        this.name = name;
        if (this.name == "" || this.name == null) { this.name = "???"; }
    }//End set name

    public void setHp(int hp)
    {
        this.hp = hp;
        if (this.hp <= 0) { this.hp = 1; }
    }//end set hp

    public void setTempHp(int tempHp)
    {
        this.tempHp = tempHp;
        if (this.tempHp < 0) { this.tempHp = 0; }
        if (this.tempHp > hp) { this.tempHp = hp; }
    }//End set temp hp

    public void setAtt(int att)
    {
        this.att = att;
        if (this.att <= 0) { this.att = 1; }
    }//end set att

    public void setTempAtt(int tempAtt)
    {
        this.tempAtt = tempAtt;
        if (this.tempAtt < 0) { this.tempAtt = 0; }
    }//end setTempAtt

    public void setDisp(int disp)
    {
        this.disp = disp;
        if (this.disp < 0) { this.disp = 0; }
    }//end setDisp

    public void setFortitude(int fortitude)
    {
        this.fortitude = fortitude;
        if (this.fortitude <= 0) { this.fortitude = 1; }
    }//end setFortitude

    public void setLuck(int luck)
    {
        this.luck = luck;
        if (this.luck <= 0) { this.luck = 1; }
    }//end setLuck

    public void setAgility(int agility)
    {
        this.agility = agility;
        if (this.agility <= 0) { this.agility = 1; }
    }//end setAgility

    public void setStrength(int strength)
    {
        this.strength = strength;
        if (this.strength <= 0) { this.strength = 1; }
    }//end setStrength

    public void setKnowledge(int knowledge)
    {
        this.knowledge = knowledge;
        if (this.knowledge <= 0) { this.knowledge = 1; }
    }//end setKnowledge

    public void setTempFortitude(int tempFortitude)
    {
        this.tempFortitude = tempFortitude;
        if (this.tempFortitude < 0) { this.tempFortitude = 0; }
    }//end setTempFortitude

    public void setTempLuck(int tempLuck)
    {
        this.tempLuck = tempLuck;
        if (this.tempLuck < 0) { this.tempLuck = 0; }
    }//end setTempLuck

    public void setTempAgility(int tempAgility)
    {
        this.tempAgility = tempAgility;
        if (this.tempAgility < 0) { this.tempAgility = 0; }
    }//end setTempAgility

    public void setTempStrength(int tempStrength)
    {
        this.tempStrength = tempStrength;
        if (this.tempStrength < 0) { this.tempStrength = 0; }
    }//end setTempStrength

    public void setTempKnowledge(int tempKnowledge)
    {
        this.tempKnowledge = tempKnowledge;
        if (this.tempKnowledge < 0) { this.tempKnowledge = 0; }
    }//end setTempKnowledge

    public void setWeapon(Weapon newWep)
    {
        this.wep = newWep;
    }//end setWeapon

    #endregion

    #region functions

    public void resetToFull()
    { //full heath, removes buffs/debuffs
        tempHp = hp;
        tempAtt = att;
        tempFortitude = fortitude;
        tempLuck = luck;
        tempAgility = agility;
        tempStrength = strength;
        tempKnowledge = knowledge;
        isDefending = false;
    }//end reset to full

    public void resetToNoBuff()
    { //removes buffs/debuffs
        tempAtt = att;
        tempFortitude = fortitude;
        tempLuck = luck;
        tempAgility = agility;
        tempStrength = strength;
        tempKnowledge = knowledge;
        isDefending = false;
    }//end reset to no buff

    public int attack() { return (tempAtt + wep.getAttack() + tempStrength); }

    public void defend() { isDefending = true; }//good for 1 defence
    
    public int recieveDamage(int dam) {

        int damage;

        /*if (isDefending) 
        {  setTempHp( tempHp - (dam - ((Convert.ToInt16((wep.getDef() / 2))) *2 ) ));
        isDefending = false;}

        else { setTempHp(tempHp - (dam - (Convert.ToInt16((wep.getDef() / 2))))); }*/

        if (isDefending)
        {
            damage = (dam - ((Convert.ToInt16((wep.getDef() / 2))) * 2));
            isDefending = false;
        }

        else{damage = (dam - (Convert.ToInt16((wep.getDef() / 2))));}

        setTempHp(tempHp - damage);

        return damage;

    }//end recieveDamage
    
    public void recieveHeals(int heelz) {
        tempHp += heelz;
        if (tempHp > hp) { tempHp = hp; }
    }//end recieve heals

    #endregion

    #region xp related functions

    public void recieveXp(int x) { 
        xp += x;
        int check = (getXp() / 100);

    if(check > getLevel() )// + 1)
    { levelUp(); 
        recieveXp(0); }

    }//end recieveXP

    public void levelUp() {
        level++;
        hp = (hp + ((hp/10) + getFortitude()) );
        att = (att + ((att / 12) + getStrength()));//(att + ((att / 2) + getStrength()) );

        int mod = getLevel() % 5;

        if (mod == 1)
        { fortitude++; }
        if (mod == 2)
        { luck++; }
        if (mod == 3)
        { agility++; }
        if (mod == 4)
        { strength++; }
        if (mod == 0)
        { knowledge++; }

        resetToFull();

    }//end levelUp

    #endregion

}//End class