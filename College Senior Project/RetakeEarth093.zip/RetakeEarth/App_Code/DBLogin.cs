﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DBLogin
/// </summary>
public class DBLogin
{
    public static string GetConnected()
    {
        //school DB
        string result = @"Server=sql.neit.edu;Database=SE414_Group1;User Id=se414_group1;Password=Group1IsBest";

        //string result = @"Server=s12.winhost.com;Database=DB_106341_retakeearth;User Id=DB_106341_retakeearth_user;Password=s3vEnt3eNpUrPle5l0ths";

        return result;
    }//end of getConnected
    public static string Passphr() { return "s3vEnt3eNpUrPle5l0ths"; }
}//end of class