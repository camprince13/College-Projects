﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient; //SQL database
using System.Data; //database

//using System.Object;
//using System.MarshalByRefObject;
using System.IO;//.Stream;
//using System.IO.MemoryStream;
using System.Runtime.Serialization.Formatters.Binary;


/// <summary>
/// Summary description for Person
/// </summary>
public class DBPerson
{

    #region login stuff

    public String PersonLogin(string Name, string Pass)
        {

            string LVL = "";
            SqlDataReader dr;
            SqlCommand comm = new SqlCommand();
            String strSQL = "SELECT accLvl FROM Login WHERE (uname = @Name AND pass = @Pass)";

            comm.Parameters.AddWithValue("@Name", encrypt(Name));
            comm.Parameters.AddWithValue("@Pass", encrypt(Pass));

            //Create DB tools and Configure
            //***************************************
            SqlConnection conn = new SqlConnection();

            string strConn = @DBLogin.GetConnected();
            conn.ConnectionString = strConn;

            comm.Connection = conn;
            comm.CommandText = strSQL;

            conn.Open();
            dr = comm.ExecuteReader();

            while (dr.Read())
            {
                LVL = dr["accLvl"].ToString();
                LVL = decrypt(LVL);
            }

            conn.Close();

            return LVL;

        }//End Log in

        public string AddContact(string nm, string pass, string email)
        {
            string strFeedback = "";

            List<string> ls = FindOnePerson(nm);

            if (ls.Contains(encrypt(nm)))
            {
                strFeedback = "Error: user already exists.";
                return strFeedback;
            }

            else
            {

                //Create SQL command string
                string strSQL = "INSERT INTO Login (uname, pass, accLvl, email, dateCreated) VALUES (@FName, @Pass, @AccLvl, @email, @dte)";

                // Create a connection to DB
                SqlConnection conn = new SqlConnection();

                string strConn = @DBLogin.GetConnected();

                conn.ConnectionString = strConn;

                //send out the command
                SqlCommand comm = new SqlCommand();
                comm.CommandText = strSQL;
                comm.Connection = conn;

                comm.Parameters.AddWithValue("@FName", encrypt(nm));
                comm.Parameters.AddWithValue("@Pass", encrypt(pass));
                comm.Parameters.AddWithValue("@AccLvl", encrypt("5"));
                comm.Parameters.AddWithValue("@email", encrypt(email));
                comm.Parameters.AddWithValue("@dte", encrypt((DateTime.Now).ToString()));

                try
                {
                    conn.Open();
                    strFeedback = comm.ExecuteNonQuery().ToString() + " Records added";

                    conn.Close();
                }
                catch (Exception err)
                {
                    strFeedback = "Error: " + err.Message;
                }
                return strFeedback;

            }//end else

        }//End Add Contact

        public List<string> FindOnePerson(string uname)
        {
            SqlConnection conn = new SqlConnection();
            SqlCommand comm = new SqlCommand();

            //Connection String
            string strConn = @DBLogin.GetConnected();

            //SQL command string to pull up one person's data
            string sqlString =
           "SELECT uname FROM Login WHERE uname = @Person_ID;";

            conn.ConnectionString = strConn;

            comm.Connection = conn;
            comm.CommandText = sqlString;
            comm.Parameters.AddWithValue("@Person_ID", encrypt(uname));

            conn.Open();

            //return comm.ExecuteReader();

            List<string> list = (from IDataRecord r in comm.ExecuteReader()
                                 select (string)r["uname"]).ToList();
            conn.Close();
            return list;

        }//End Find One Person

    #endregion

    #region Encryption / Decryption

        //Encryption / Decryption
    //----------------------------------------------
        private string encrypt(string str){

            string temp = "";

        if (str != "")
            {
                string x = @DBLogin.Passphr();
                string y = str;
                temp = _001_encrypt.service.EncryptString(y, x);
            }
            else
            { temp = ""; }

        return temp;
        }//end encrypt

        private string decrypt(string str)
        {
            string temp = "";
            if (str != "")
            {
                try
                {
                    string x = @DBLogin.Passphr();
                    string y = str;
                    temp = _000_Decrypt.Service.DecryptString(y, x);
                }
                catch { temp = "Error: the message could not be decrypted. The message or passphrase could be wrong."; }
            }
            else
            { temp = ""; }

            return temp;

        }//end decrypt
    //----------------------------------------------------------------
        //End encryption / decryption

        #endregion

    #region news
        //News
    //----------------------------------------------------------------
        public string AddNews(string usr, string title, string body)
        {
            string strFeedback = "";

                //Create SQL command string
                string strSQL = "INSERT INTO News (title, body, ownerID, date) VALUES (@titl, @bod, @owner, @dte)";

                // Create a connection to DB
                SqlConnection conn = new SqlConnection();

                string strConn = @DBLogin.GetConnected();

                conn.ConnectionString = strConn;

                //send out the command
                SqlCommand comm = new SqlCommand();
                comm.CommandText = strSQL;
                comm.Connection = conn;

                comm.Parameters.AddWithValue("@titl", title);
                comm.Parameters.AddWithValue("@bod", body);
                comm.Parameters.AddWithValue("@owner", encrypt(usr));
                comm.Parameters.AddWithValue("@dte", DateTime.Now);

                try
                {
                    conn.Open();
                    strFeedback = comm.ExecuteNonQuery().ToString() + " Records added"; 
                }
                catch (Exception err)
                {
                    strFeedback = "Error: " + err.Message;
                }
                finally { conn.Close(); }
                return strFeedback;
        }//End Add News


        public DataSet GetNews()
        {
            //Create a dataset to return filled
            DataSet ds = new DataSet();

            //Create a command for our SQL statement
            SqlCommand comm = new SqlCommand();

            //SQL Statement
            String strSQL = "Select TOP 5 title, body, ownerID, date FROM News WHERE 0=0 Order by id DESC";

            //Create DB tools and Configure
            //******************************************
            SqlConnection conn = new SqlConnection();
            string strConn = @DBLogin.GetConnected();
            conn.ConnectionString = strConn;
            comm.Connection = conn;
            comm.CommandText = strSQL;
            //Create Data Adapter
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;

            conn.Open();
            da.Fill(ds, "News");
            conn.Close();

            return ds;
        }//End Search Contacts


        public string NewsToHTML() {
            DataSet ds = GetNews();


            List<string> title = ds.Tables[0].AsEnumerable()
                       .Select(r => r.Field<string>(0))
                       .ToList();

            List<string> body = ds.Tables[0].AsEnumerable()
                      .Select(r => r.Field<string>(1))
                      .ToList();

            List<string> owner = ds.Tables[0].AsEnumerable()
            .Select(r => r.Field<string>(2))
            .ToList();

            List<DateTime> date = ds.Tables[0].AsEnumerable()
            .Select(r => r.Field<DateTime>(3))
            .ToList();

            String html = "";

            for (var i = 0; i < title.Count; i++)
            {
                html += "<p><h2>" + title[i] + "</h2><br />";
                html += body[i] + "<br />";
                html += "Posted by &nbsp" + decrypt(owner[i]) + "&nbsp on &nbsp" + date[i].ToString() + "</p><br /><br />";
            }

            return html;
        }//End news to html

    //--------------------------------------------------------------------------
    //End news
#endregion

    #region GetVerbs

        public DataSet GetVerblist()
        {
            //Create a dataset to return filled
            DataSet ds = new DataSet();

            //Create a command for our SQL statement
            SqlCommand comm = new SqlCommand();

            //SQL Statement
            String strSQL = "Select action, timesUsed FROM SuggestedActions WHERE 0=0";

            //Create DB tools and Configure
            //******************************************
            SqlConnection conn = new SqlConnection();
            string strConn = @DBLogin.GetConnected();
            conn.ConnectionString = strConn;
            comm.Connection = conn;
            comm.CommandText = strSQL;
            //Create Data Adapter
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;

            conn.Open();
            da.Fill(ds, "SuggestedActions");
            conn.Close();

            return ds;
        }//End Search Contacts


        public string VerbsToHTML()
        {
            DataSet ds = GetVerblist();


            List<string> action = ds.Tables[0].AsEnumerable()
                       .Select(r => r.Field<string>(0))
                       .ToList();

            List<int> timesUsed = ds.Tables[0].AsEnumerable()
                      .Select(r => r.Field<int>(1))
                      .ToList();

            String html = "";

                    html += "<table border=1>"
                + "<tr>"
                + "<th>Action</th>"
                + "<th>Times Used</th>"
                + "</tr>";

            for (var i = 0; i < action.Count; i++)
            {
                html += "<tr>";
                html += "<td>" + action[i] + "</td>"
                + "<td>" + timesUsed[i] + "</td>";

                html += "</tr>";
            }

            html += "</table>";


            return html;
        }//End news to html

    #endregion

    #region Game Data

        public Team getGameData(string uname)
        {

            //Create a dataset to return filled
            DataSet ds = new DataSet();

            //Create a command for our SQL statement
            SqlCommand comm = new SqlCommand();

            //SQL Statement
            String strSQL = "Select saveData FROM Player WHERE ownerID=@ownerid";

            //Create DB tools and Configure
            //******************************************
            SqlConnection conn = new SqlConnection();
            string strConn = @DBLogin.GetConnected();
            conn.ConnectionString = strConn;
            comm.Connection = conn;
            comm.CommandText = strSQL;
            comm.Parameters.AddWithValue("@ownerid", encrypt(uname));
            //Create Data Adapter
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;

            byte[] arrBytes = {111};
            conn.Open();

            //da.Fill(ds, "Player");

            //List<Team> list = (from IDataRecord r in comm.ExecuteReader()
                               //select (Team)r["saveData"]).ToList();

            /*byte[] arrBytes = (from IDataRecord r in comm.ExecuteReader()
                               select (byte)r["saveData"]).ToArray();*/

            //byte[] arrBytes;// = new byte[];

            using (SqlDataReader d = comm.ExecuteReader())
            {
                if (d.Read())
                {
                    arrBytes = (byte[])d["saveData"];
                }
                else
                {
                }
            }

            conn.Close();


            /*MemoryStream memStream = new MemoryStream();
            BinaryFormatter binForm = new BinaryFormatter();
            memStream.Write(arrBytes, 0, arrBytes.Length);
            memStream.Seek(0, SeekOrigin.Begin);
            Team obj = null;
            try
            {
                obj = (Team)binForm.Deserialize(memStream);
            }
            catch 
            { obj = null; }

            memStream.Close();
            
            return obj;*/

            Team t = byteArrayToObject(arrBytes) as Team;
            return t;

            //return ds;
            //return list;
        }//end getGameData

        public string setGameData(Team team, string uname) {

            string strFeedback = "";

            string strSQL = "";

            if (getGameData(uname) != null && getGameData(uname).ToString() != "")
            {                 //Create SQL command string
                strSQL = "Update Player Set saveData=@team, ownerID=@owner where ownerID=@owner";
                //"INSERT INTO Login (uname, pass, accLvl, email, dateCreated) VALUES (@FName, @Pass, @AccLvl, @email, @dte)";
            }
            else 
            { strSQL = "Insert INTO Player (saveData, ownerID) VALUES (@team, @owner)"; }


            //MemoryStream memStream = new MemoryStream();
            //StreamWriter sw = new StreamWriter(memStream);
            //sw.Write(team);

            /*if (team == null)
                return null;

            BinaryFormatter bf = new BinaryFormatter();
            MemoryStream ms = new MemoryStream();
            bf.Serialize(ms, team);*/

                // Create a connection to DB
                SqlConnection conn = new SqlConnection();

                string strConn = @DBLogin.GetConnected();

                conn.ConnectionString = strConn;

                //send out the command
                SqlCommand comm = new SqlCommand();
                comm.CommandText = strSQL;
                comm.Connection = conn;

                Object tempObj = team as Object;
                Byte[] bArr = objectToByteArray(team);

                comm.Parameters.Add("@team", SqlDbType.VarBinary, Int32.MaxValue);//team);  AddWithValue
                comm.Parameters["@team"].Value = bArr;//objectToByteArray(team);
                //comm.Parameters["@team"].Value = ms.ToArray(); //memStream.GetBuffer();
                comm.Parameters.AddWithValue("@owner", encrypt(uname));

                //memStream.Close();
                //sw.Close();

                //ms.Close();

                try
                {
                    conn.Open();
                    strFeedback = comm.ExecuteNonQuery().ToString() + " Records added";
                }
                catch (Exception err)
                {
                    strFeedback = "Error: " + err.Message;
                }
                finally { conn.Close(); }

                return strFeedback;

        }//end setGameData

    #endregion

    #region Binary Conversion

        //convert object to byte array
        private byte[] objectToByteArray(Object obj)
        {
            if (obj == null)
                return null;

            BinaryFormatter bf = new BinaryFormatter();
            MemoryStream ms = new MemoryStream();
            bf.Serialize(ms, obj);

            return ms.ToArray();
        }

        // Convert byte array to an Object
        private Object byteArrayToObject(byte[] arrBytes)
        {
            if (arrBytes.Length <= 0)
            { return null; }

            MemoryStream memStream = new MemoryStream();
            BinaryFormatter binForm = new BinaryFormatter();
            memStream.Write(arrBytes, 0, arrBytes.Length);
            memStream.Seek(0, SeekOrigin.Begin);

            Object obj;

            try
            {
                obj = (Object)binForm.Deserialize(memStream);
            }
            catch
            {
                obj = null;
            }

            return obj;
        }

    #endregion

}//End Class
