﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for EnemyAI
/// </summary>

[Serializable]
public abstract class EnemyAI
{
	public EnemyAI(Team mine, Team notMine)
	{
        myTeam = mine;
        theirTeam = notMine;
	}//end constructor

    #region variables
    protected Team myTeam = new Team();
    protected Team theirTeam = new Team();
    protected string[] names = new string[1] { "[]" };
    protected Combat combat;
    #endregion

    #region override
    public abstract string turn(Creature cr);

    public abstract string turn(Creature cr, int action, int target);
    #endregion

    #region functions

    public void allTurn() {

        for (int i = 0; i < myTeam.length(); i++) { turn(myTeam.getCreature(i)); }

    }//end all turn

    /*public int genRandomNum(int low, int max)
    {
        Random rnd = new Random();
        int randy = rnd.Next(low, max);
        return randy;
    }//end genRandomNum*/

    private Random rnd = new Random();
    private static readonly object syncLock = new object();
    public int genRandomNum(int low, int max)
    {

        lock (syncLock)
        { // synchronize
            for (int i = 0; i < rnd.Next(30, 150); i++) { }

            int randy = rnd.Next(low, max);
            return randy;
        }

    }//end genRandomNum     This is more random

    public void genRandomTeam()
    {

        int members = genRandomNum(1, 6);

        int oppLevel;
        if (theirTeam != null){oppLevel = theirTeam.getAvgLvl();}
        else{ oppLevel = 0;}

        int highlvl = oppLevel + 3, lowlvl = oppLevel-3;
        if (lowlvl < 0) { lowlvl = 0; }
        int lvl = genRandomNum(lowlvl, highlvl);

        int hp = 10 + lvl;//(lvl * 2);
        int att = 2;

        myTeam.setCreature(0, new Creature(names[genRandomNum(0, names.Length)], hp, att));
        Creature tempCreature = myTeam.getCreature(0);
        tempCreature.recieveXp((lvl * 100));
        myTeam.setCreature(0, tempCreature);

        if (members > 1){

            for (int i = 1; i < members; i++ ) {
                myTeam.setCreature(i, new Creature(names[genRandomNum(0, names.Length)], hp, att));
                tempCreature = myTeam.getCreature(i);
                tempCreature.recieveXp((lvl * 100));
                if ((genRandomNum(0, 100) >= 50)) { tempCreature.setWeapon(myTeam.getInventory().getOneRandomItem()); }//randomly assigns weapon

                myTeam.setCreature(i, tempCreature);
            }

        }//end if

    }//genRandomTeam

    public void genRandomBossTeam()
    {

        int members = 1;// genRandomNum(1, 6);

        int oppLevel;
        if (theirTeam != null) { oppLevel = theirTeam.getAvgLvl(); }
        else { oppLevel = 0; }

        int highlvl = oppLevel + 3, lowlvl = oppLevel - 3;
        if (lowlvl < 0) { lowlvl = 0; }
        int lvl = genRandomNum(lowlvl, highlvl);

        int hp = 50 + (lvl * 2);
        int att = 2;

        myTeam.setCreature(0, new Creature(names[genRandomNum(0, names.Length)], hp, att));
        Creature tempCreature = myTeam.getCreature(0);
        tempCreature.recieveXp((lvl * 100));
        myTeam.setCreature(0, tempCreature);

        if (members > 1)
        {

            for (int i = 1; i < members; i++)
            {
                myTeam.setCreature(i, new Creature(names[genRandomNum(0, names.Length)], hp, att));
                tempCreature = myTeam.getCreature(i);
                tempCreature.recieveXp((lvl * 100));
                if ((genRandomNum(0, 100) >= 50)) { tempCreature.setWeapon(myTeam.getInventory().getOneRandomItem()); }//randomly assigns weapon

                myTeam.setCreature(i, tempCreature);
            }

        }//end if

    }//genRandomTeam

    public bool checkGameOver() { return theirTeam.isDefeated(); }

    public Team getMyTeam() { return myTeam; }

    public Team getTheirTeam() { return theirTeam; }

    #endregion

}//end class