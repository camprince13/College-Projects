﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Inventory
/// </summary>

[Serializable]
public class Inventory
{
    public Inventory() { //addItem(new Weapon());
    currency = 0;
    battItems = new int[9];
    }

    public Inventory(bool isShop)
    { 
        currency = 0;
        battItems = new int[9];
        if (isShop) { addRandomStock(); }
    }

    public Inventory(Weapon wep1, Weapon wep2, Weapon wep3) { 
    addItem(wep1);
    addItem(wep2);
    addItem(wep3);
    currency = 0;
    battItems = new int[9];
    }

    private Weapon[] temp;
    private int currency;
    private int[] battItems;//battle items
    /* 
     * 0 - weak potion
     * 1 - med.potion
     * 2 - strong potion
     * 3 - buff F
     * 4 - buff L
     * 5 - buff A
     * 6 - buff S
     * 7 - buff K
     * 8 - Revive
     */


    #region functions

    public void setItem(int slot, Weapon wep)
    {
        if (slot >= 0 && slot < temp.Length) { temp[slot] = wep; }
        else { addItem(wep); }
    }

    public Weapon getItem(int slot)
    {
        if (slot < temp.Length)
        {
            return temp[slot];
        }
        else { return new Weapon(); }
    }//end getItem

    public Weapon[] getItems() { return temp; }

    public void setCurrency(int crr) { currency = crr;
    if (currency < 0) { currency = 0; }
    }

    public int getCurrency() { return currency; }

    public void addCurrency(int crr) { currency += crr;
    if (currency < 0) { currency = 0; }
    }

    public void addItem(Weapon wep)
    {
        if (wep.getName() != "fists")
        {
            if (temp != null)
            {
                Weapon[] temp2 = new Weapon[temp.Length + 1];

                for (int i = 0; i < temp.Length; i++)
                {
                    temp2[i] = temp[i];
                }//end for

                temp2[temp.Length] = wep;
                temp = temp2;
            }//end inner if
            else
            {
                temp = new Weapon[1];
                temp[0] = wep;
            }//end else
        }//end outer if
    }//end add item

    public void removeItem(int slot)
    {

        Weapon[] temp2 = new Weapon[temp.Length - 1];

        int b = 0;
        for (int i = 0; i < temp.Length; i++)
        {
            if (i != slot)
            {
                temp2[b] = temp[i];
                b++;
            }
        }//end for
        temp = temp2;

    }//end removeItem

    public int length() {
        if (temp != null) { return temp.Length; }
        else { return 0; }
    }//end length

    public void setBattleItems(int[] arr) {
        battItems = arr;
    }//end setBattleItems

    public void set1BattleItem(int slot, int amount)
    {
        battItems[slot] = amount;
    }//end setBattleItems

    public int[] getBattleItems() { return battItems; }

    public int get1BattleItem(int slot) { return battItems[slot]; }

    #endregion

    #region stuff for random inventory

    public void addRandomStock() {
        
        /*int i = genRandomNum(0, 100);
        if (i >= 92) { i = 4; }
        if (i >= 85) { i = 3; }
        if (i >= 70) { i = 2; }
        else if (i >= 60) { i = 1; }
        else { i = 0; }

        Weapon[] tmp = getWeaponSet(i);
        int randy = genRandomNum(1, 5);

        for (int x = 0; x < randy; x++ ) {
            addItem( (tmp[genRandomNum(0, tmp.Length)]) );
        }//end for*/

        int randy = genRandomNum(1, 5);
        for (int i = 0; i < randy; i++) { addOneRandomItem(); }

    }//end addRandomStock

    public void addOneRandomItem() {
        int i = genRandomNum(0, 100);
        if (i >= 92) { i = 4; }
        if (i >= 85) { i = 3; }
        if (i >= 70) { i = 2; }
        else if (i >= 60) { i = 1; }
        else { i = 0; }

        Weapon[] tmp = getWeaponSet(i);
        addItem((tmp[genRandomNum(0, tmp.Length)]));
    }//end addOneRandomItem

    public Weapon getOneRandomItem() {
        Weapon[] tmp = getWeaponSet(0);
        return tmp[genRandomNum(0, tmp.Length)];
    }//end getOneRandomItem

    private Random rnd = new Random();
    private static readonly object syncLock = new object();
    private int genRandomNum(int low, int max)
    {
        
        lock (syncLock)
        { // synchronize
        for (int i = 0; i < rnd.Next(30, 150); i++ ) { }

        int randy = rnd.Next(low, max);
        return randy;
        }

    }//end genRandomNum

    private Weapon[] getWeaponSet(int num){
    //0 for low set
    //1 for med set
        if(num == 0){
            Weapon[] lowEndWep = { new Weapon("shovel", 3, 2, 3), new Weapon("fork", 2, -2, 1), new Weapon("plunger", 4, 3, 12), new Weapon("thermas", 3, 4, 12), new Weapon("broken glass", 10, -10, 20) };
            return lowEndWep;
        }

        else if (num == 1)
        {
            Weapon[] lowEndWep = { new Weapon("claw hammer", 12, 4, 23), new Weapon("steak knife", 15, 2, 25), new Weapon("metal pipe", 13, 7, 38), new Weapon("sheet metal", 4, 12, 32), new Weapon("handful of metal shards", 20, -20, 35) };
            return lowEndWep;
        }

        else if (num == 2)
        {
            Weapon[] lowEndWep = { new Weapon("cedar quarterstaff", 20, 9, 51), new Weapon("dagger", 22, 5, 44), new Weapon("sledge hammer", 27, 10, 57), new Weapon("manhole cover", 9, 21, 49), new Weapon("ball of chainsaw blades", 30, -30, 50) };
            return lowEndWep;
        }

        else if (num == 3)
        {
            Weapon[] lowEndWep = { new Weapon("carbon fiber mace", 29, 13, 66), new Weapon("single-shot energy pistol", 35, 7, 75), new Weapon("energy hammer", 41, 20, 85), new Weapon("anti-personel shield", 12, 34, 82), new Weapon("ball of scalpel heads", 50, -50, 87) };
            return lowEndWep;
        }

        else if (num == 4)
        {
            Weapon[] lowEndWep = { new Weapon("proto plasma fist", 43, 19, 92), new Weapon("vibroblade", 50, 13, 108), new Weapon("energy door ram", 60, 27, 123), new Weapon("portable blaster shield", 15, 48, 117), new Weapon("plasma chain", 70, -70, 87) };
            return lowEndWep;
        }

        else
        {
            Weapon[] lowEndWep = { new Weapon("shovel", 3, 2, 3), new Weapon("fork", 2, -1, 1), new Weapon("plunger", 4, 3, 12), new Weapon("thermas", 3, 4, 12), new Weapon("broken glass", 10, -10, 20) };
            return lowEndWep;
        }

    }//end getWeaponSet

    #endregion

}//end class