﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Person
/// </summary>

[Serializable]
public class Person
{
    string name;
    String[] DialogDictionary = new string[] { "What do you want?", "I don't like the looks of you, outsider", "What can I get for you, outsider?" };
    Creature cre;
    Conversation con;

	public Person()
	{
        name = "Jerry Smith";
       cre = createCreature(1, new Weapon("pitchfork", 4, 1, 4));
       con = new Conversation();
	}//end person constructor
    public Person(string n, int lvl, Weapon wep)
    {
        name = n;
        cre = createCreature(lvl, wep);
        con = new Conversation();
    }//end person constructor
    public Person(string n, int lvl, Weapon wep, List<KeyValuePair<string, string>> dialog)
    {
        name = n;
        cre = createCreature(lvl, wep);
        con = createCon(dialog);
    }//end person constructor
    public Conversation createCon(List<KeyValuePair<string, string>> dialog)
    {
        Conversation conv = new Conversation(dialog);
        return conv;
    }//createConversation
    public Creature createCreature(int lvl, Weapon wep)
    {
        Creature cr = new Creature(name, 11, 3);
        cr.setWeapon(wep);
        cr.recieveXp(lvl*100);
        return cr;
    }//createCreature
    public string getName()
    {
        return name;
    }//end getName
    public Conversation getConversation()
    {
        return con;
    }//end getDefaultConversation
    public Creature getCreature()
    {
        return cre;
    }//end getCreature
}//end Person class