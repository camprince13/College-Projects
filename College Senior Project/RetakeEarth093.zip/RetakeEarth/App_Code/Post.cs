﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient; //SQL database
using System.Data; //database

/// <summary>
/// Summary description for Posts
/// </summary>
public class Post
{
    public Post()
    {
        
    }
    private string topic = System.Web.HttpContext.Current.Request["topic"];
    public DataSet GetPosts()
    {
        //Create a dataset to return filled
        DataSet ds = new DataSet();

        if (topic != "" && topic != null)
        {

            //Create a command for our SQL statement
            SqlCommand comm = new SqlCommand();

            //SQL Statement
            String strSQL = "Select post_content, post_date, post_topic, post_by FROM Posts Where post_topic = " + topic;

            //Create DB tools and Configure
            //******************************************
            SqlConnection conn = new SqlConnection();
            string strConn = @DBLogin.GetConnected();
            conn.ConnectionString = strConn;
            comm.Connection = conn;
            comm.CommandText = strSQL;
            //Create Data Adapter
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;

            conn.Open();
            da.Fill(ds, "Posts");
            conn.Close();
        }//end if topic

        return ds;
    }//End Search Contacts
   
    private string decrypt(string str)
    {
        string temp = "";
        if (str != "")
        {
            try
            {
                string x = @DBLogin.Passphr();
                string y = str;
                temp = _000_Decrypt.Service.DecryptString(y, x);
            }
            catch { temp = "Error: the message could not be decrypted. The message or passphrase could be wrong."; }
        }
        else
        { temp = ""; }

        return temp;

    }//end decrypt

    public string PostsToHTML()
    {

        DataSet dsTopic = new DataSet();

        if (topic != "" && topic != null)
        {

            //Create a command for our SQL statement
            SqlCommand comm = new SqlCommand();

            //SQL Statement
            String strSQL = "Select topic_subject FROM Topics Where topic_id = " + topic;

            //Create DB tools and Configure
            //******************************************
            SqlConnection conn = new SqlConnection();
            string strConn = @DBLogin.GetConnected();
            conn.ConnectionString = strConn;
            comm.Connection = conn;
            comm.CommandText = strSQL;
            //Create Data Adapter
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;

            conn.Open();
            da.Fill(dsTopic, "Topics");
            conn.Close();

        }//end if topic

        string Topictitle;

        if (dsTopic.Tables.Count != 0 && dsTopic != null)
        { Topictitle = dsTopic.Tables["Topics"].Rows[0]["topic_subject"].ToString(); }
        else { Topictitle = "Error: no topic! Seek a programmer!"; }
        

        DataSet ds = GetPosts();

        String html = "";


        if (ds.Tables.Count != 0 && ds != null)
        {

            List<string> content = ds.Tables[0].AsEnumerable()
               .Select(r => r.Field<string>(0))
               .ToList();
            List<DateTime> date = ds.Tables[0].AsEnumerable()
                      .Select(r => r.Field<DateTime>(1))
                      .ToList();
            List<string> by = ds.Tables[0].AsEnumerable()
                      .Select(r => r.Field<string>(3))
                      .ToList();

            html += "<h2>" + Topictitle + "</h2><br />";

            for (var i = 0; i < content.Count; i++)
            {
                html += "<div class=\"bubblePost\"><h2>" + content[i] + "</h2>";
                html += decrypt(by[i]) + "   " + date[i] + " </div><br />";
            }
        
        }//End if datasource has data

        else { html += "<h2>" + Topictitle + "</h2><br />";
        html += "<div class=\"bubblePost\"><h2>" + "No posts." + "</h2>";
        }//

        return html;
    }//end of PostsToHTML
}//End class