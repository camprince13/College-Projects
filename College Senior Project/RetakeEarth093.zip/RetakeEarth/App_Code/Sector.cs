﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Sector
/// </summary>

[Serializable]
public class Sector
{
    String[] locationDesc = new string[] { "", "", "", "", "", "", "", "" };
    List<Person> people = new List<Person>();
    Shop shop;
    string background = "images/TemplePlaceHolder.png";//reference an image from image folder
    string dirInTown;

	public Sector()
	{
        dirInTown = "The 7th ring of hell";
	}//end sector constructor

    public Sector(String DirInTown)
    {
        dirInTown = DirInTown;

    }//end sector constructor
    #region gets&Sets
    public void SectorSetDir(string d) { dirInTown = d; }
    public void SectorSetBG(string b) { background = b; }
    public void SectorSetLD(int slot, string desc) { locationDesc[slot] = desc; }
    public void SectorSetPeople(){
        Person per = new Person();
        people.Add(per);
    }//end SectorSetPeople

    public void SectorSetCustomPeople(string name, int lvl, Weapon wep, List<KeyValuePair<string, string>> dialog)
    {
        Person per = new Person(name, lvl, wep, dialog);
        people.Add(per);
    }//end SectorSetPeople
    public void SectorSetCustomPeople(string name, int lvl, Weapon wep)
    {
        Person per = new Person(name, lvl, wep);
        people.Add(per);
    }//end SectorSetPeople
    public string getAllPeople()
    {
        string names = ". <br /> People in this section include but are not limited to";
        if (people.Count != 0)
        {
            for (int i = 0; i < people.Count; i++)
            {
                names += " <u><i><b>" + people[i].getName().ToLower()+"</b></i></u>";
            }//end for
        }//end if
        else
        {
            names = ". No people in this sector";
        }//end else
        return names;
    }//end getallpeople

    public Person getPerson(int slot)
    {
        return people[slot];
    }//getPerson

    public List<string> getAllPeopleList()
    {
        List<string> peopleNames = new List<string>();
        for (int i = 0; i < people.Count; i++)
        {
            peopleNames.Add(people[i].getName().ToLower());
        }//end for
        return peopleNames;
    }//end getAllPeopleList

    public string SectorGetDir() { return dirInTown; }
    public string SectorGetBG() { return background; }
    public string SectorGetLD(int slot) { return locationDesc[slot]; }

    public Shop getShop() { return shop; }
    public void SectorSetShop(Shop s) { shop = s; }
    #endregion

    #region checks
    public bool checkPeopleList(string name)
    {
        bool flag = false;
        string temp;
        for (int i = 0; i < people.Count; i++)
        {
            temp = people[i].getName().ToLower();
            if (temp == name.Trim())
            {
                flag = true;
            }//end if
        }//end for
        return flag;
    }//end checkPeopleList
    public int checkPeopleSlot(string name)
    {
        int slot = 0;
        string temp;
        for (int i = 0; i < people.Count; i++)
        {
            temp = people[i].getName().ToLower();
            if (temp == name.Trim())
            {
                slot=i;
            }//end if
        }//end for
        return slot;
    }//end checkPeopleSlot
    #endregion
}//end class