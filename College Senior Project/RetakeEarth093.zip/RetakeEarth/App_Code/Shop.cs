﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Shop
/// </summary>

[Serializable]
public class Shop
{
    public Shop()
	{
        inventory = new Inventory(true);
        inventory.addRandomStock();
        inventory.addCurrency(1000);
        mark = 0.33;

	}//end constuctor
    public Shop(bool flag)
    {
        inventory = new Inventory(true);
        inventory.addCurrency(1000);
        mark = 0.33;
        if (flag)
        {
            inventory.addItem(new Weapon("boat", 20, 90, 2400));
        }
    }
    public Shop(int num)
    {
        
        
        mark = 0.33;
        
        
            inventory = new Inventory(true);
            //inventory.addRandomStock();
            inventory.addCurrency(1000);
        
        
        
    }
    public Shop(string stuff)
    {


        mark = 0.33;


        inventory = new Inventory(true);
        inventory.addRandomStock();
        inventory.addCurrency(1000);



    }
    Inventory inventory;

    int disp = 0;
    double mark;

    //add battle items


    #region functions

    public int markup(int price){
        int tmp = Convert.ToInt32((price * (1 + mark)) - (disp/10));
        return tmp;
    }//end markup

    public int markDown(int price)
    {
        int tmp = Convert.ToInt32((price * (1 - mark)) - (disp / 10));
        return tmp;
    }//end markDown

    public string[] getListOfItems()
    {
        string[] tmp = new string[inventory.length()];

        for (int i = 0; i < inventory.length(); i++)
        { tmp[i] = inventory.getItem(i).getName(); }

        return tmp;
    }//end getListOfItems
    public int[] getListOfItemsAttack()
    {
        int[] tmp = new int[inventory.length()];

        for (int i = 0; i < inventory.length(); i++)
        { tmp[i] = inventory.getItem(i).getAttack(); }

        return tmp;
    }//end getListOfAttack
    public int[] getListOfItemsDefence()
    {
        int[] tmp = new int[inventory.length()];

        for (int i = 0; i < inventory.length(); i++)
        { tmp[i] = inventory.getItem(i).getDef(); }

        return tmp;
    }//end getListOfDefence
    public int[] getListOfItemPrices()
    {
        int[] tmp = new int[inventory.length()];

        for (int i = 0; i < inventory.length(); i++)
        { tmp[i] = markup(inventory.getItem(i).getValue()); }

        return tmp;
    }//end getListOfItemPrices

    public Shop genRandomShop() {

        Shop s = new Shop();
        s.inventory.addOneRandomItem();
        s.inventory.addOneRandomItem();
        return s;

    }//end genRandomShop

    public string getShopContents()
    {
        string result = "Shop Items <br /><table><tr><th>item name</th><th>value</th><th>attack</th><th>defence</th></tr>";
        int[] prices = getListOfItemPrices();
        string[]  items = getListOfItems();
        int[]  attacks = getListOfItemsAttack();
        int[] defs = getListOfItemsDefence();
        
        for (int i = 0; items.Length > i; i++)
        {
            result += "<tr><td>" + items[i] + " </td><td> " + prices[i].ToString() + "</td><td> " + attacks[i].ToString() + " </td><td> " + defs[i].ToString() + " </td></tr>";
        }
        
        result += "</table><br /><br />";
        return result;
    }

    #endregion

    #region buy/sell functions

    public Object[] buyFromShop(Inventory playerInventory, string itemToBuy) {

        string[] tmp = getListOfItems();
        int[] tmpPri = getListOfItemPrices();

        int indexOfItem = Array.IndexOf(tmp, itemToBuy);
        string output = "";

        if (indexOfItem != -1)
        {

            if (playerInventory.getCurrency() >= tmpPri[indexOfItem])
            {
                Weapon tmpWep = inventory.getItem(indexOfItem);
                int pay = markup((inventory.getItem(indexOfItem).getValue()));

                playerInventory.addCurrency(-(pay));
                playerInventory.addItem(tmpWep);

                inventory.removeItem(indexOfItem);
                inventory.addCurrency(pay);

                output += "Bought <u>" + itemToBuy + "</u>, you now have <b>" + playerInventory.getCurrency() + "</b> total currency";

            }//end if

            else
            {
                output += "Too poor to buy " + itemToBuy;
            }//end else
        }//end outer if

        else {
            output += "This item is not sold here.";
        }//end else

        Object[] ret = new Object[2];
        ret[0] = playerInventory;
        ret[1] = output;

        return ret;

    }//buyFromShop

    public Object[] sellToShop(Inventory playerInventory, string itemToSell)
    {

        string[] tmp = new string[playerInventory.length()];

        for (int i = 0; i < playerInventory.length(); i++)
        { tmp[i] = playerInventory.getItem(i).getName(); }

        int[] tmpPri = new int[playerInventory.length()];

        for (int i = 0; i < playerInventory.length(); i++)
        { tmpPri[i] = markDown(playerInventory.getItem(i).getValue()); }


        int indexOfItem = Array.IndexOf(tmp, itemToSell.Trim());
        string output = "";

                if (indexOfItem != -1)
        {

        if (inventory.getCurrency() >= tmpPri[indexOfItem])
        {
            Weapon tmpWep = playerInventory.getItem(indexOfItem);
            int pay = markDown((playerInventory.getItem(indexOfItem).getValue()));

            inventory.addCurrency(-(pay));
            inventory.addItem(tmpWep);

            playerInventory.removeItem(indexOfItem);
            playerInventory.addCurrency(pay);

            output += "After much bartering you sold <u>" + itemToSell + "</u>, you now have <b>" + playerInventory.getCurrency()+"</b> total currency";

        }//end if

        else
        {
            output += "Shop too poor to buy " + itemToSell;
        }//end else

        }//end outer if

                else
                {
                    output += "You can't sell what you dont have.";
                }//end else

        Object[] ret = new Object[2];
        ret[0] = playerInventory;
        ret[1] = output;

        return ret;

    }//end sellToShop

    #endregion

}//end Shop class