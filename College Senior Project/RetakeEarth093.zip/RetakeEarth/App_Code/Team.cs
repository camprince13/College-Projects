﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Team
/// </summary>

[Serializable]
public class Team
{
    #region constuctors

    public Team() { temp = new Creature[1];
    temp[0] = new Creature();
    txtAdv = new textAdventure();
    }

    public Team(Creature cre) { 
        temp = new Creature[1];
        temp[0] = cre;
        txtAdv = new textAdventure();
    }

    public Team(Creature a, Creature b, Creature c)
    {
        temp = new Creature[3];
        temp[0] = a;
        temp[1] = b;
        temp[2] = c;
        txtAdv = new textAdventure();
    }
    #endregion

    #region variables
    private Creature[] temp;
    private Creature[] dead = new Creature[0];
    private Inventory inventory = new Inventory();
    private textAdventure txtAdv;
    #endregion

    #region getters/setters

    public void setCreature(int sl, Creature cr)
    {
        if (sl >= 0 && sl < temp.Length) { temp[sl] = cr; }
        else { addCreature(cr); }
    }

    public Creature getCreature(int slot)
    {
        return temp[slot];
    }

    public void setDeadCreature(int sl, Creature cr)
    {
        if (sl >= 0 && sl < dead.Length) { dead[sl] = cr; }
        else { addDeadCreature(cr); }
    }

    public Creature getDeadCreature(int slot)
    {
        if (dead.Length != 0)
        {
            return dead[slot];
        }
        else { return null; }
    }

    public void setInventory(Inventory inv){inventory = inv;}

    public Inventory getInventory() { return inventory; }

    public void setTextAdv(textAdventure txt) { txtAdv = txt; }

    public textAdventure getTextAdv() { return txtAdv; }

    #endregion

    #region functions

    public void addCreature(Creature cr)
    { 
    Creature[] temp2 = new Creature[temp.Length + 1];

    for (int i = 0; i < temp.Length; i++ ) {
        temp2[i] = temp[i];
    }//end for

    temp2[temp.Length] = cr;
    temp = temp2;
    }//end add creature

    public void addDeadCreature(Creature cr)
    {
        Creature[] temp2 = new Creature[dead.Length + 1];

        for (int i = 0; i < dead.Length; i++)
        {
            temp2[i] = dead[i];
        }//end for

        temp2[dead.Length] = cr;
        dead = temp2;
    }//end add dead creature

    public void removeCreature(int slot) {

        Creature[] temp2 = new Creature[temp.Length - 1];

        int b = 0;
        for (int i = 0; i < temp.Length; i++)
        {
            if (i != slot)
            {
                temp2[b] = temp[i];
                b++;
            }
        }//end for
        temp = temp2;
    }//end removeCreature

    public void removeDeadCreature(int slot)
    {

        Creature[] temp2 = new Creature[dead.Length - 1];

        int b = 0;
        for (int i = 0; i < dead.Length; i++)
        {
            if (i != slot)
            {
                temp2[b] = dead[i];
                b++;
            }
        }//end for
        dead = temp2;
    }//end removeDeadCreature

    public int length() { return temp.Length; }

    public int deadLength() { return dead.Length; }

    public bool isDefeated() {

        //if (length() == 0) { return true; }
        if (totHealth() == 0) { return true; }//else if
        else { return false; }

    }//end isDefeated

    public int totHealth() {
        int tot = 0;

        for (int i = 0; i < temp.Length; i++)
        {
            try{tot += temp[i].getTempHp();}
            catch { tot += 0; }

            //removes dead creatures    _may need a tweak later
            if (temp[i].getTempHp() == 0) {
                addDeadCreature(temp[i]);//adds to list of dead
                removeCreature(i); }

        }//end for
        return tot;
    }//end totHealth

    public void awardXp(int xp) {

        int xpEach = xp / temp.Length;

        for (int i = 0; i < temp.Length; i++) {
            temp[i].recieveXp(xpEach);
        }

    }//end awardXp

    public string[] getListOfCreatures() 
    { 
    string[] tmp = new string[temp.Length];

    for (int i = 0; i < temp.Length; i++)
    { tmp[i] = temp[i].getName(); }

        return tmp;
    }//end getListOfCreatures

    public string[] getListOfItems()
    {
        string[] tmp = new string[inventory.length()+1];

        tmp[0] = "fists (1)";

        for (int i = 1; i < inventory.length()+1; i++)
        { tmp[i] = inventory.getItem((i-1)).getName() + " (" + (i+1) + ")"; }

        return tmp;
    }//end getListOfItems

    public void equipItem(int crSlot, int wepSlot)
    {
        inventory.addItem(temp[crSlot].getWeapon());

        if (wepSlot == 0) 
        {temp[crSlot].setWeapon(new Weapon());}

        else
        {temp[crSlot].setWeapon(inventory.getItem((wepSlot-1)));
        inventory.removeItem((wepSlot - 1));}
        
    }//end equipItem

    #endregion

    #region get avg stuff

    public int getAvgFortitude()
    {
        if (temp.Length > 0)
        {
            int avg = 0;
            for (int i = 0; i < temp.Length; i++)
            {
                avg += temp[i].getFortitude();
            }//end for
            try { avg = (avg / temp.Length); }
            catch { avg = 0; }
            return avg;
        }
        else { return 0; }
    }//end getAvgFortitude

    public int getAvgLuck()
    {
        if (temp.Length > 0)
        {
        int avg = 0;
        for (int i = 0; i < temp.Length; i++)
        {
            avg += temp[i].getLuck();
        }//end for
        try { avg = (avg / temp.Length); }
        catch { avg = 0; }
        return avg;
        }
        else { return 0; }
    }//end getAvgLuck

    public int getAvgAgility()
    {
        if (temp.Length > 0)
        {
        int avg = 0;
        for (int i = 0; i < temp.Length; i++)
        {
            avg += temp[i].getAgility();
        }//end for
        try { avg = (avg / temp.Length); }
        catch { avg = 0; }
        return avg;
        }
        else { return 0; }
    }//end getAvgAgility

    public int getAvgStrength()
    {
        if (temp.Length > 0)
        {
        int avg = 0;
        for (int i = 0; i < temp.Length; i++)
        {
            avg += temp[i].getStrength();
        }//end for
        try { avg = (avg / temp.Length); }
        catch { avg = 0; }
        return avg;
        }
       else { return 0; }
    }//end getAvgStrength

    public int getAvgKnowledge()
    {
        if (temp.Length > 0)
        {
        int avg = 0;
        for (int i = 0; i < temp.Length; i++)
        {
            avg += temp[i].getKnowledge();
        }//end for
        try { avg = (avg / temp.Length); }
        catch { avg = 0; }
        return avg;
        }
        else { return 0; }
    }//end getAvgKnowledge

    public int getAvgLvl()
    {
        if (temp.Length > 0)
        {
        int avg = 0;
        for (int i = 0; i < temp.Length; i++)
        {
            avg += temp[i].getLevel();
        }//end for

        try{avg = (avg / temp.Length);}
        catch { avg = 0; }

        return avg;
        }
        else { return 0; }
    }//end getAvgLvl

    #endregion

    #region display stuff

    public string displayAll() 
    {
        string str = "<h2>Status</h2>";
        str += displayMainStatus();
        str += "<br /><h2>Weapons</h2>";
        str += displayWeapons();
        str += "<br /><h2>Currency</h2>";
        str += inventory.getCurrency();
        str += "<br /><h2>Temporary Status</h2>";
        str += displayTempStatus();
        return str;
    }//end displayAll

    public string displayMainStatus()
    {
        string outputString = "";

        outputString += "<table border=1>"
        + "<tr>"
        + "<th>Level</th>"
        + "<th>Name</th>"
        + "<th>Current Health</th>"
        + "<th>Max Health</th>"
        + "<th>Attack</th>"
        + "<th>Weapon</th>"
        + "<th>Fortitude</th>"
        //+ "<th>Temp Fortitude</th>"
        + "<th>Luck</th>"
        //+ "<th>Temp Luck</th>"
        + "<th>Agility</th>"
        //+ "<th>Temp Agility</th>"
        + "<th>Strength</th>"
        //+ "<th>Temp Strength</th>"
        + "<th>Knowledge</th>"
        //+ "<th>Temp Knowledge</th>"
        + "<th>XP</th>"
        + "</tr>";

        for (int i = 0; i < temp.Length; i++)
        {
            outputString += "<tr>";
            outputString += "<td>" + temp[i].getLevel() + "</td>"
                + "<td>" + temp[i].getName() + "</td>"
                + "<td>" + temp[i].getTempHp() + "</td>"
                + "<td>" + temp[i].getHp() + "</td>"
                + "<td>" + temp[i].getAtt() + "</td>"
                + "<td>" + temp[i].getWeapon().getName() + "</td>"
                + "<td>" + temp[i].getFortitude() + "</td>"
                //+ "<td>" + temp[i].getTempFortitude() + "</td>"
                + "<td>" + temp[i].getLuck() + "</td>"
                //+ "<td>" + temp[i].getTempLuck() + "</td>"
                + "<td>" + temp[i].getAgility() + "</td>"
                //+ "<td>" + temp[i].getTempAgility() + "</td>"
                + "<td>" + temp[i].getStrength() + "</td>"
                //+ "<td>" + temp[i].getTempStrength() + "</td>"
                + "<td>" + temp[i].getKnowledge() + "</td>"
                //+ "<td>" + temp[i].getTempKnowledge() + "</td>"
                + "<td>" + temp[i].getXp() + "</td>";
            outputString += "</tr>";

        }//end for

        outputString += "</table>";//done with char status

        return outputString;
    }//end displayMainStatus

    public string displayTempStatus() 
    {
        string outy = "";

        outy += "<table border=1>"
        + "<tr>"
        + "<th>Name</th>"
        + "<th>Temp Fortitude</th>"
        + "<th>Temp Luck</th>"
        + "<th>Temp Agility</th>"
        + "<th>Temp Strength</th>"
        + "<th>Temp Knowledge</th>"
        + "</tr>";

        for (int i = 0; i < temp.Length; i++)
        {
            outy += "<tr>";
            outy += "<td>" + temp[i].getName() + "</td>"
                + "<td>" + temp[i].getTempFortitude() + "</td>"
                + "<td>" + temp[i].getTempLuck() + "</td>"
                + "<td>" + temp[i].getTempAgility() + "</td>"
                + "<td>" + temp[i].getTempStrength() + "</td>"
                + "<td>" + temp[i].getTempKnowledge() + "</td>";
            outy += "</tr>";

        }//end for

        outy += "</table>";//done with char status

        return outy;
    }//end displayTempStatus

    public string displayWeapons() {
    
                string outy = "";

        outy += "<table border=1>"
        + "<tr>"
        + "<th>Name</th>"
        + "<th>Attack</th>"
        + "<th>Defense</th>"
        + "<th>Value</th>"
        + "</tr>";

        for (int i = 0; i < inventory.length(); i++)
        {
            outy += "<tr>";
            outy += "<td>" + inventory.getItem(i).getName() + "</td>"
                + "<td>" + inventory.getItem(i).getAttack() + "</td>"
                + "<td>" + inventory.getItem(i).getDef() + "</td>"
                + "<td>" + inventory.getItem(i).getValue() + "</td>";
            outy += "</tr>";

        }//end for

        outy += "</table>";//done with char status

        return outy;
    
    }//end displayWeapons

    #endregion

}//end class