﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient; //SQL database
using System.Data; //database
using System.Web.UI;
using System.Web.UI.WebControls;


/// <summary>
/// Summary description for ForumTopics
/// </summary>
public class Threads
{
    public Threads()
	{
		
	}
    public DataSet GetThreads()
    {
        string cat = System.Web.HttpContext.Current.Request["cat"];
        if (cat != "" && cat != null)
        {
            //Create a dataset to return filled
            DataSet ds = new DataSet();

            //Create a command for our SQL statement
            SqlCommand comm = new SqlCommand();


            //SQL Statement
            String strSQL = "Select topic_subject, topic_date, topic_by, topic_id FROM Topics Where topic_cat = " + cat;

            //Create DB tools and Configure
            //******************************************
            SqlConnection conn = new SqlConnection();
            string strConn = @DBLogin.GetConnected();
            conn.ConnectionString = strConn;
            comm.Connection = conn;
            comm.CommandText = strSQL;
            //Create Data Adapter
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;

            conn.Open();
            da.Fill(ds, "Topics");
            conn.Close();

            return ds;
        }//end if
        else
        {
           DataSet dsError = new DataSet();

            return dsError;
        }
    }//End Search Contacts

    private string decrypt(string str)
    {
        string temp = "";
        if (str != "")
        {
            try
            {
                string x = @DBLogin.Passphr();
                string y = str;
                temp = _000_Decrypt.Service.DecryptString(y, x);
            }
            catch { temp = "Error: the message could not be decrypted. The message or passphrase could be wrong."; }
        }
        else
        { temp = ""; }

        return temp;

    }//end decrypt

    public string ThreadsToHTML()
    {
        DataSet ds = GetThreads();

        String html = "";

        if (ds.Tables.Count != 0 && ds != null)
        {

            List<string> title = ds.Tables[0].AsEnumerable()
                       .Select(r => r.Field<string>(0))
                       .ToList();

            List<DateTime> date = ds.Tables[0].AsEnumerable()
                      .Select(r => r.Field<DateTime>(1))
                      .ToList();
            List<string> by = ds.Tables[0].AsEnumerable()
                      .Select(r => r.Field<string>(2))
                      .ToList();
            List<int> topic = ds.Tables[0].AsEnumerable()
                     .Select(r => r.Field<int>(3))
                     .ToList();

            for (var i = 0; i < title.Count; i++)
            {
                html += "<a href='Posts.aspx?topic=" + topic[i] + "'><div class=\"bubblePost\"><h2>" + title[i] + "</h2></a>";
                html += decrypt(by[i]) + "   " + date[i] + " </div><br /><br />";
            }

        }//End if

        else { html = "No topics found.<br /><br />"; }


        return html;
    }//end of CatToHTML

}//end class