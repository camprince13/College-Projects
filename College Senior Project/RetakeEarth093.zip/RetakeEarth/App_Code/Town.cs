﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Town
/// </summary>

[Serializable]
public class Town
{
    public Town()
    {
        name = "<u>Default Town Name</u>";
        disp = 0;
        Sector[] sects = { new Sector("North"), new Sector("South"), new Sector("East"), new Sector("West"), new Sector("Northeast"), new Sector("Northwest"), new Sector("Southeast"), new Sector("Southwest") };
    }//constructor end

    public Town(String townName, int sec)
    {
        name = townName;
        Sector[] sects = new Sector[sec];
        for (int i = 0; i < sec; i++)
        {
            sects[i] = new Sector();
        }
       
    }//constructor end
    #region varables
    private String name;
    private int disp; //disposition towards player
    Sector[] sects = { new Sector(""), new Sector(""), new Sector(""), new Sector(""), new Sector(""), new Sector(""), new Sector(""), new Sector("") };
    Sector currentSect = new Sector("you have no clue");
    int currentSectSlot = 0;
    #endregion

    #region gets&sets
 public String Name
    {
        get { return name; }
        set { name = value; }
    }
    public int Disp
    {
        get { return disp; }
        set { disp = value; }
    }

    public void TownSetSect(int slot,  Sector sect) { sects[slot] = sect; }

    public Sector TownGetSect(int slot) {
        return sects[slot]; 
    }
    public void TownSetCurrSect(int slot)
    {
        currentSect = sects[slot];
        currentSectSlot = slot;
    }
    public void TownSetAllSect(Sector[] sect) { sects = sect; }
    public Sector[] TownGetAllSect()
    {
        
        return sects;
    }
    public Sector TownGetCurrentSect()
    {
        return currentSect;
    }
    public int TownCurrentGetSectSlot()
    {
        return currentSectSlot;
    }
    #endregion

}//Town class end