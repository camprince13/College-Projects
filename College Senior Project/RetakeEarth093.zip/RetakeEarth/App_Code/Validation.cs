﻿//Cameron Prince
//Original
//Modified
//A validation class

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient; //SQL database
using System.Data; //database
using System.Text;
using System.Text.RegularExpressions;

/// <summary>
/// Summary description for Validation
/// </summary>
public static class Validation
{
	
		 //Tests a string to see if it is blank
        public static bool IsFilledIn(string temp)
        {
            bool result = false;
            if (temp.Length > 0)
            { result = true; }
            return result;
        }


        //Tests for a valid length for state
        public static bool IsValidLength(string temp)
        {
            bool result = true;
            if (temp.Length != 2)
            { result = false; }
            return result;
        }


        //Tests for the country's length
        public static bool IsWithinRange(string temp)
        {
            bool result = false;
            if (temp.Length > 2 && temp.Length < 20)
            { result = true; }
            return result;
        }

        //Tests money amounts
        public static bool IsWithinRange(double temp)
        {
            bool result = false;
            if (temp >= 0 && temp <= 100)
            { result = true; }
            return result;
        }


        //Checks for valid email
        public static bool IsValidEmail(string temp)
        {
            bool result = true;
            int AtLocation = temp.IndexOf("@");
            int NextAtLocation = temp.IndexOf("@", AtLocation + 1);
            int PeriodLocation = temp.LastIndexOf(".");
            if (temp.Length < 8)
            { result = false; }
            else if (AtLocation < 2)
            { result = false; }
            else if (PeriodLocation + 2 > (temp.Length))
            { result = false; }
            return result;
        }//End check email


        public static bool HasCurseWord(string temp) {
            bool res = false;
            temp = temp.ToLower();

            if(temp.Contains("fuck") || temp.Contains("fucker") || temp.Contains("fucking") || temp.Contains("fucked") || temp.Contains("motherfucker") 
                || temp.Contains("shit") ||  temp.Contains("shitty") || temp.Contains("shittiest") || temp.Contains("dumbshit") || temp.Contains("bullshit") 
                || temp.Contains("shithead") || temp.Contains("shithole") || temp.Contains("shitter")
                || temp.Contains("asshole") || temp.Contains("cunt") || temp.Contains("twat") || temp.Contains("nigger")) { res = true; }

            //Does not contain the following

            /*
            //ass 
            //hell
            //bitch
            //whore
            //pussy 
            cock 
            dick 
            douchebag
            jackass
            piss 
            slut
            tits
            arse */

            //Full Curse list
            //fuck OR shit OR ass OR asshole OR hell OR bitch OR whore OR shitty OR shittiest OR fucker OR asshole OR pussy OR motherfucker OR fucking OR fucked OR dumbshit OR bullshit OR cock OR cunt OR dick OR douchebag OR jackass OR piss OR shithead OR shithole OR slut OR tits OR twat OR shitter OR arse

            return res;
        }//end hasCurseWord


        public static bool HasCurseWordAgressive(string temp)
        {
            bool res = false;
            temp = temp.ToLower();

            if (temp.Contains("fuck") || temp.Contains("fucker") || temp.Contains("fucking") || temp.Contains("fucked") || temp.Contains("motherfucker")
                || temp.Contains("shit") || temp.Contains("shitty") || temp.Contains("shittiest") || temp.Contains("dumbshit") || temp.Contains("bullshit")
                || temp.Contains("shithead") || temp.Contains("shithole") || temp.Contains("shitter")
                || temp.Contains("asshole") || temp.Contains("cunt") || temp.Contains("twat")
                || temp.Contains("bitch") || temp.Contains("whore")
                || temp.Contains("pussy") || temp.Contains("cock") || temp.Contains("dick") || temp.Contains("douchebag")
                || temp.Contains("jackass") || temp.Contains("piss") || temp.Contains("slut") || temp.Contains("tits") || temp.Contains("arse")
                || temp.Contains("nigger") || temp.Contains("kike") || temp.Contains("spic") || temp.Contains("gook") || temp.Contains("beaner") 
                || temp.Contains("chink") 
                )
            { res = true; }

            //Removed due to interference with other words [hello, assistance]
            //|| temp.Contains("hell")
            //|| temp.Contains("ass") 

            //Full Curse list
            //fuck OR shit OR ass OR asshole OR hell OR bitch OR whore OR shitty OR shittiest OR fucker OR asshole OR pussy OR motherfucker OR fucking OR fucked OR dumbshit OR bullshit OR cock OR cunt OR dick OR douchebag OR jackass OR piss OR shithead OR shithole OR slut OR tits OR twat OR shitter OR arse
            return res;
        }//end hasCurseWordAgressive

        public static string censorString(string temp)
        {

            Regex wordFilter = new Regex("(fuck|shit|asshole|shitty|shittiest|fucker|asshole|motherfucker|fucking|fucked|dumbshit|bullshit|cunt|shithead|shithole|twat|shitter|nigger)");
            return wordFilter.Replace(temp, "****");

        }//end censorString

        public static string censorStringAgressive(string temp) {

            Regex wordFilter = new Regex("(fuck|shit|ass|asshole|hell|bitch|whore|shitty|shittiest|fucker|asshole|pussy|motherfucker|fucking|fucked|dumbshit|bullshit|cock|cunt|dick|douchebag|jackass|piss|shithead|shithole|slut|tits|twat|shitter|arse|nigger|kike|spic|gook|beaner|chink)");
            return wordFilter.Replace(temp, "****");

        }//end censorString

        public static string censorStringRandomReplace(string temp)
        {

            Regex wordFilter = new Regex("(fuck|shit|ass|asshole|hell|bitch|whore|shitty|shittiest|fucker|asshole|pussy|motherfucker|fucking|fucked|dumbshit|bullshit|cock|cunt|dick|douchebag|jackass|piss|shithead|shithole|slut|tits|twat|shitter|arse|nigger|kike|spic|gook|beaner|chink)");

            Random rnd = new Random();
            int num = rnd.Next(replaceArr.Count());

            return wordFilter.Replace(temp, replaceArr[num]);

        }//end censorString



        private static string[] replaceArr = new string[] { "BUNNY", "MATH", "TACO", "BAD_WORD", "BEEP", "BLUEBERRIES", "ONIONS", "ARMADILLO", "DIRE_BEAR", "SALAD", "RABID_SPIDER_MONKEY", "BISON", "CHEESE", "BEES?", "GEESE", "DUMB", "@#%INSERT_WORD_HERE@#$", "'NICE'", "GERBALSNAPDRAGON", "HOMOSAPIEN"};

	}//end class
