﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Weapon
/// </summary>

[Serializable]
public class Weapon
{
	public Weapon(string nm, int attack, int defense, int val)
	{
        name = nm;
        att = attack;
        def = defense;
        value = val;
	}//end constructor

    public Weapon()
    {
        name = "fists";
        att = 0;
        def = 0;
        value = 0;
    }//end constructor

    #region variables

    string name = "[]";
    int att = 0;
    int def = 0;
    int value = 0;

    #endregion

    #region getters/setters

    public string getName() { return name; }

    public void setName(string name)
    {
        this.name = name;
        if (this.name == "" || this.name == null) { this.name = "???"; }
    }//End set name

    public int getAttack() { return att; }

    public void setAtt(int at)
    {
        this.att = at;
        if (this.att < 0) { this.att = 0; }
    }//end set Att

    public int getDef() { return def; }

    public void setDef(int d)
    {
        this.def = d;
        if (this.def < 0) { this.def = 0; }
    }//end set Att

    public int getValue() { return value; }

    public void setValue(int val)
    {
        this.value = val;
        if (this.value < 0) { this.value = 0; }
    }//end setValue

    #endregion

}//end class