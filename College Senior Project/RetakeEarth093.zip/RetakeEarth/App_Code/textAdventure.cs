﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient; //SQL database
using System.Data; //database
using System.Web.UI;
using System.Web.UI.WebControls;



/// <summary>
/// Summary description for textAdventure
/// </summary>

[Serializable]
public class textAdventure
{

    public textAdventure()
    {
        town = new Town[] { new Town("Falsewind", 8), new Town("Temple of the Faithless", 2), new Town("Temple of the Shattered Earth", 2), new Town("Village of Outcasts", 4), new Town("Harenam", 1), new Town("New town", 1), new Town("Abandoned Spire", 1) };
        for (int i = 0; i < town.Length; i++)
        {
            Sector[] twmp = town[i].TownGetAllSect();
            
            town[i].TownGetSect(0).SectorSetDir("North");
               
            town[i].TownGetSect(1).SectorSetDir("South");
             
            town[i].TownGetSect(2).SectorSetDir("East");
               
            town[i].TownGetSect(3).SectorSetDir("West");
               
            town[i].TownGetSect(4).SectorSetDir("Northeast");
               
            town[i].TownGetSect(5).SectorSetDir("Northwest");
                
            town[i].TownGetSect(6).SectorSetDir("Southeast");
               
            town[i].TownGetSect(7).SectorSetDir("Southwest");
               

            if (i == 0)//(town[i].Name == "Falsewind")
            {

                town[i].TownGetSect(0).SectorSetShop(new Shop(true));
                town[i].TownGetSect(0).SectorSetLD(0, "Large gloomy building block out the sun. You see a small shop.");
                town[i].TownGetSect(0).SectorSetPeople();
                List<KeyValuePair<string, string>> dialog = new List<KeyValuePair<string, string>>();
                dialog.Add(new KeyValuePair<string, string>("", "hey there! Please exit the conversation if you want to buy things"));
                dialog.Add(new KeyValuePair<string, string>("why do i need to stop talking to buy things", "because thats how the programmers designed the game, it made sense at the time"));
                dialog.Add(new KeyValuePair<string, string>("that's dumb", "yeah kinda but that's life"));
                dialog.Add(new KeyValuePair<string, string>("hi", "hello money ba- I mean customer"));
                dialog.Add(new KeyValuePair<string, string>("hey", "are you gunna buy something or what"));
                town[i].TownGetSect(0).SectorSetCustomPeople("ShopKeep", 10, new Weapon("Brass Knuckles", 8, 2, 15), dialog);
                town[i].TownGetSect(1).SectorSetLD(1, "small sheetmetal shacks hang around, like lost souls");
                town[i].TownGetSect(2).SectorSetLD(2, "A fountain with an old man sitting on it");
                town[i].TownGetSect(3).SectorSetLD(3, "Many stands litter the street but all of them are empty");
                town[i].TownGetSect(3).SectorSetCustomPeople("Steve", 2, new Weapon("spoon", 1, 1, 1));
                town[i].TownGetSect(4).SectorSetLD(4, "IT'S ALL ON FIRE");
                town[i].TownGetSect(5).SectorSetLD(5, "Two large gorrila fight in an ancient parking lot, many people are taking bets");
                town[i].TownGetSect(5).SectorSetCustomPeople("Gorrila #1", 40, new Weapon("Gorrila Fists", 25, 10, 400));
                town[i].TownGetSect(5).SectorSetCustomPeople("Gorrila #2", 30, new Weapon("Gorrila Feet", 20, 6, 200));
                town[i].TownGetSect(6).SectorSetLD(6, "More sad sheetmetal shacks polute the area");
                town[i].TownGetSect(7).SectorSetLD(7, "The mosdest jaged sheetmetal home of the towns shaman");
                town[i].TownGetSect(0).SectorSetCustomPeople("Shaman", 20, new Weapon("Ancient Stick", 14, 8, 300));
                town[i].TownGetSect(0).SectorSetBG("images/TownSmall.png");
                town[i].TownGetSect(1).SectorSetBG("images/TownSmall.png");
                town[i].TownGetSect(2).SectorSetBG("images/TownSmall.png");
                town[i].TownGetSect(3).SectorSetBG("images/TownSmall.png");
                town[i].TownGetSect(4).SectorSetBG("images/TownSmall.png");
                town[i].TownGetSect(5).SectorSetBG("images/TownSmall.png");
                town[i].TownGetSect(6).SectorSetBG("images/TownSmall.png");
                town[i].TownGetSect(7).SectorSetBG("images/TownSmall.png");
            }//end else if
            else if (i == 1)//(town[i].Name == "Temple of the Faithless")
            {
                Shop s = new Shop(1);
                List<KeyValuePair<string, string>> dialog = new List<KeyValuePair<string, string>>();
                dialog.Add(new KeyValuePair<string, string>("", "Go away outsider you are not one of us"));
                dialog.Add(new KeyValuePair<string, string>("how do i join", "You cannot, we only accept cool people"));
                dialog.Add(new KeyValuePair<string, string>("you suck", "no you suck"));
                dialog.Add(new KeyValuePair<string, string>("hi", "go away"));
                dialog.Add(new KeyValuePair<string, string>("hey", "please go away"));
                town[i].TownGetSect(0).SectorSetCustomPeople("Cultist Sam", 5, new Weapon("Cultist Dagger", 5, 3, 200), dialog);
                town[i].TownGetSect(0).SectorSetCustomPeople("Cultist Henry", 5, new Weapon("Cultist Cloak", 3, 5, 200), dialog);
                town[i].TownGetSect(0).SectorSetCustomPeople("New Cultist", 5, new Weapon("Cultist Doorknob", 2, 2, 200));
                List<KeyValuePair<string, string>> shopDialog = new List<KeyValuePair<string, string>>();
                dialog.Add(new KeyValuePair<string, string>("", "hey there! Please exit the conversation if you want to buy things"));
                dialog.Add(new KeyValuePair<string, string>("why do i need to stop talking to buy things", "because thats how the programmers designed the game, it made sense at the time"));
                dialog.Add(new KeyValuePair<string, string>("that's dumb", "yeah kinda but that's life"));
                dialog.Add(new KeyValuePair<string, string>("hi", "hello money ba- I mean customer"));
                dialog.Add(new KeyValuePair<string, string>("hey", "are you gunna buy something or what"));
                town[i].TownGetSect(0).SectorSetCustomPeople("Cultist ShopKeep", 10, new Weapon("Brass Knuckles", 8, 2, 15), shopDialog);
                town[i].TownGetSect(0).SectorSetShop(new Shop(1));
                town[i].TownGetSect(0).SectorSetLD(0, "Many pews litter the hall with a large stained glass window towering behind the podium");
                town[i].TownGetSect(1).SectorSetLD(1, "Marked and unmarked graves fill the land infront of the temple");
                List<KeyValuePair<string, string>> skelDialog = new List<KeyValuePair<string, string>>();
                skelDialog.Add(new KeyValuePair<string, string>("", "Hey dude whats up?"));
                skelDialog.Add(new KeyValuePair<string, string>("are you a skeleton", "Well kind of but thats a bit personal"));
                skelDialog.Add(new KeyValuePair<string, string>("why are you so spooky", "cause I can be"));
                town[i].TownGetSect(1).SectorSetCustomPeople("Skeleton", 8, new Weapon("funny bone", 6, 2, 20), skelDialog);
                town[i].TownGetSect(0).SectorSetBG("images/TempleSmall.png");
            }//end else if
            else if (i == 2)//(town[i].Name == "Temple of the Shattered Earth")
            {
                Shop s = new Shop(2);
                town[i].TownGetSect(0).SectorSetShop(new Shop("dsf"));
                town[i].TownGetSect(0).SectorSetPeople();
                town[i].TownGetSect(0).SectorSetLD(0, "Hooded figures chant in unison as you enter the hall");
                town[i].TownGetSect(1).SectorSetLD(1, "Trees gather around a temple, you hear the wind howl");
                town[i].TownGetSect(0).SectorSetBG("images/TempleSmall.png");
                town[i].TownGetSect(1).SectorSetBG("images/TempleSmall.png");
            }//end else if
            else if (i == 3)//(town[i].Name == "Village of Outcasts")
            {
                Shop s = new Shop(3);
                town[i].TownGetSect(0).SectorSetShop(new Shop("stuff"));
                town[i].TownGetSect(0).SectorSetLD(0, "horses everywhere and a shop");
                town[i].TownGetSect(1).SectorSetLD(1, "IT'S ALL ON ICE");
                town[i].TownGetSect(2).SectorSetLD(2, "7 magic elves greet you");
                town[i].TownGetSect(2).SectorSetPeople();
                town[i].TownGetSect(3).SectorSetLD(3, "STUFF IS IN HERE");
                town[i].TownGetSect(0).SectorSetBG("images/TownSmall.png");
            }//end else if
            else if (i == 4)//(town[i].Name == "Harenam")
            {
                Shop s = new Shop(4);
                town[i].TownGetSect(0).SectorSetShop(new Shop(4));
                town[i].TownGetSect(0).SectorSetLD(0, "Lots else if sand and a shop");
                town[i].TownGetSect(0).SectorSetPeople();
                town[i].TownGetSect(0).SectorSetBG("images/TownSmall.png");
            }//end else if
            else if (i == 4)//(town[i].Name == "Harenam")
            {
                Shop s = new Shop(4);
                town[i].TownGetSect(0).SectorSetShop(new Shop(4));
                town[i].TownGetSect(0).SectorSetLD(0, "Lots else if sand and a shop");
                town[i].TownGetSect(0).SectorSetBG("images/TownSmall.png");
            }//end else if
            else if (i == 5)//(town[i].Name == "new town")
            {
                Shop s = new Shop(true);
                town[i].TownGetSect(0).SectorSetShop(new Shop(true));
                town[i].TownGetSect(0).SectorSetLD(0, "Hundreds of frozen horses grazing");
                town[i].TownGetSect(0).SectorSetPeople();
                town[i].TownGetSect(0).SectorSetBG("images/TownSmall.png");
            }//end else if
            else if (i == 5)//(town[i].Name == "new town")
            {
                Shop s = new Shop(true);
                town[i].TownGetSect(0).SectorSetShop(new Shop(1));
                town[i].TownGetSect(0).SectorSetLD(0, "An old automated shop that apears to still be working");
                town[i].TownGetSect(0).SectorSetBG("images/TempleSmall.png");
            }//end else if

        }//end outer for
        currTown = town[0];
    }//end constructor

    #region variables
    //String input_string;
    //String verb;
    //String object_thing;//effected item
    String output_string;
    String location;
    Town currTown = new Town();
    Creature currCreature = new Creature();
    Conversation currConvo;
    Town[] town;// = new Town[];// {new Town(), new Town(), new Town(), new Town(), new Town()};// make textadventure constructor for setting towns
    String[] actionDictionary = new string[] { "attack", "fight", "drop", "punch","go","kill","buy","sell","look","win" };
    String[] insultDictionary = new string[] { "Who plays a text adventure game and types nothing? An idiot.", "Of all the things you could think of you decided that was the best idea?", "" };
    String[] words3 = new string[] {"",""};
    private Team playerTeam;
    #endregion

    #region functions
    //Checking for words within user input strings 
    public string CheckText(String input, Team pt, Panel pan)//txtAdv
    {
        //panel = pan;
        playerTeam = pt;
        input = input.ToLower();


        if (input != "")
        {
            if (currConvo != null)
            {
                String[] words3 = new string[] {""};
                words3[0] = input;
                return SentenceChecker(words3, pan);
            }
            String[] words2 = input.Split(' ');
            if (words2[0] == "buy" || words2[0] == "sell" || words2[0] == "attack")
            {
                String[] words3 = new string[] { "", "" };
                words3[0] = words2[0];
                string res = "";
                for (int i = 1; i < words2.Length; i++)
                {
                    res += " " + words2[i];
                }
                words3[1]=res;
                    return SentenceChecker(words3, pan);
            }
            else if (words2[0] == "talk" && words2[1] == "to")
            {
                words3 = new string[] { "", "", ""};
                words3[0] = words2[0];
                words3[1] = words2[1];
                
                string res = "";
                for (int i = 2; i < words2.Length; i++)
                {
                    res += " " + words2[i];
                }
                words3[2] = res;
                return SentenceChecker(words3, pan);
            }
            for (int i = 0; i<words2.Length; i++)
            {
                if (words2[i] == "in" || words2[i] == "the" || words2[i] == "is" || words2[i] == "to" || words2[i] == "an" || words2[i] == "of" )//get rid of fluff words
                {
                    words2 = removeFluff(words2,i);
                }
            }//end for
            
            if (actionDictionary.Contains(words2[0])) {

                return SentenceChecker(words2, pan);
               
            }//end inner if

            else
            {

                if (CheckVerb(words2[0]) == false)//check if new word exists within the database
                {
                    SaveVerb(words2[0]); //if the word does not exist save to suggested actions
                    return SentenceChecker(words2, pan);
                }//end inner if

                else
                {
                    incrementWord(words2[0]);
                    return SentenceChecker(words2, pan);
                }//end inner else

                //SentenceChecker(words2, town);
                //word added to backup list

            }//end else

          

        }//End outer if
        else
        {
            //insult character
            return "Who plays a text adventure game and types nothing? An idiot.";
        }//end else

    }//end checktext

    public void SaveVerb(String verb)
    {
        //Create SQL command string
        string strSQL = "INSERT INTO SuggestedActions (action, timesUsed) VALUES (@verb, 1)";

        // Create a connection to DB
        SqlConnection conn = new SqlConnection();

        string strConn = @DBLogin.GetConnected();

        conn.ConnectionString = strConn;

        //send out the command
        SqlCommand comm = new SqlCommand();
        comm.CommandText = strSQL;
        comm.Connection = conn;

        comm.Parameters.AddWithValue("@verb", verb);

        try
        {
            conn.Open();
            //strFeedback = 
            comm.ExecuteNonQuery();//.ToString() + " Records added";

            conn.Close();
        }
        catch (Exception err)
        {
            // strFeedback = "Error: " + err.Message;
        }

    }//end save verb

    public bool CheckVerb(String verb)
    {
        SqlConnection conn = new SqlConnection();
        SqlCommand comm = new SqlCommand();

        //Connection String
        string strConn = @DBLogin.GetConnected();

        //SQL command string to pull up one person's data
        string sqlString = "select Count(action) from SuggestedActions WHERE action = @verb";//"SELECT action FROM SuggestedActions WHERE action = @verb;";

        conn.ConnectionString = strConn;

        comm.Connection = conn;
        comm.CommandText = sqlString;
        comm.Parameters.AddWithValue("@verb", verb);

        conn.Open();
        int tmp = (Int32)comm.ExecuteScalar();


        //comm.ExecuteNonQuery() > 0
        if (tmp > 0)///////////////////tmp != "" && tmp != null
        {
            return true;
            conn.Close();
        }
        else
        {
            return false;
            conn.Close();
        }

        conn.Close();
    }//end checkverb

    public void incrementWord(String verb)
    {
        //Create SQL command string
        string strSQL = "Update SuggestedActions Set timesUsed=(Select timesUsed from SuggestedActions where action=@verb)+1 where action=@verb";

        // Create a connection to DB
        SqlConnection conn = new SqlConnection();

        string strConn = @DBLogin.GetConnected();

        conn.ConnectionString = strConn;

        //send out the command
        SqlCommand comm = new SqlCommand();
        comm.CommandText = strSQL;
        comm.Connection = conn;

        comm.Parameters.AddWithValue("@verb", verb);

        try
        {
            conn.Open();
            //strFeedback = 
            comm.ExecuteNonQuery();//.ToString() + " Records added";
            conn.Close();
        }
        catch (Exception err)
        {
            // strFeedback = "Error: " + err.Message;
        }

    }//end save verb

    public String OutputLocationText(Town town, Sector sector, int slot)
    {
        return "You are in " + town.Name + ": " + sector.SectorGetDir() + " district. You see " + sector.SectorGetLD(slot) +currTown.TownGetCurrentSect().getAllPeople() + " <br /><br />"; 
    }//end outputText

    public String ItemAction(Weapon item)//come back to this
    {
        return "You used " + item.getName();//will run through dictionaries to get output
    }//end ItemAction

    public string SentenceChecker(string[] words, Panel panel)
    {
       //////////Create a current conversation based case statment//////////////
        if (currConvo != null && words[0] == "exit")
        {
            currConvo = null;
            return " You leave the conversation";
        }
        if(currConvo != null){
            return currCreature.getName() + ": " + currTown.TownGetCurrentSect().getPerson(currTown.TownGetCurrentSect().checkPeopleSlot(currCreature.getName().ToLower())).getConversation().talkSpecific(words[0]);
        }
        switch (words.Length)
        {
            #region case1 word
            case 1:
                 if (words[0] == "north")
                        {
                            if (currTown.TownGetSect(0).SectorGetLD(0) != "")
                            {
                                currTown.TownSetCurrSect(0); ;// 0 is north

                                panel.BackImageUrl = currTown.TownGetCurrentSect().SectorGetBG();
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + currTown.TownGetCurrentSect().getShop().getShopContents() + "You walked to the northern part of town.";
                            }
                            else
                            {
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "This area does not have a northern section";
                            }
                }//end if
                if (words[0] == "south")
                        {
                            if (currTown.TownGetSect(1).SectorGetDir() != "")
                            {
                                currTown.TownSetCurrSect(1);// 1 is south

                                panel.BackImageUrl = currTown.TownGetCurrentSect().SectorGetBG();
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "You walked to the southern part of town.";
                            }
                            else
                            {
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "This area does not have a southern section";
                            }
                        }//end if
                if (words[0] == "east")
                        {
                            if (currTown.TownGetSect(2).SectorGetLD(2) != "")
                            {
                           // 2 is east
                                currTown.TownSetCurrSect(2);
                                panel.BackImageUrl = currTown.TownGetCurrentSect().SectorGetBG();
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "You walked to the " + currTown.TownGetCurrentSect().SectorGetDir() + "ern part of town. ";
                            }
                            else
                            {
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "This area does not have a eastern section";
                            }
                            }//end if
                if (words[0] == "something")
                {
                    return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "seriously?";
                }
                if(words[0] == "win"){
                    return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "You gotta try harder than that...";
                }
                if (words[0] == "lose")
                {
                    return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "You fall on to the ground and call youself a loser. Everyone in the area agrees with you";
                }
                if (words[0] == "fail")
                {
                    return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "you fail at failing";
                }
                 if(words[0] == "kill"){
                     return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "kill what? Did you eat paint growing up?";
                }
                 if (words[0] == "scream" || words[0] == "yell")
                 {
                     return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "you scream as loud as you can but the pain doesn't stop...";
                 }
                 if (words[0] == "look" || words[0] == "see")
                 {
                     return "You look around " + OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "now what?";
                 }
                 if (words[0] == "leave" || words[0] == "exit" || words[0] == "flee" || words[0] == "disappear" || words[0] == "escape" || words[0] == "vamoose" || words[0] == "scram")
                 {
                     for (int i = 0; i < town.Length; i++)
                     {
                         if(currTown.Name == town[i].Name){
                     town[i] = currTown;
                         }
                     }
                     return "You leave the town";
                 }
                return "one word";
                break;
            #endregion

            #region case2 words
            case 2: 
                #region twoWordVerbCaseStatement
                switch (words[0])
                {
                    #region caselook
                    case "look":
                        if (words[1] == "around")
                        {
                            return "You look around " + OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "now what?";
                        }
                        else
                        {
                            return "You don't see " + words[1] + " " + OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "now what?";
                        }
                        break;
                    #endregion
                    #region casego
                    case "go":
                        if (words[1] == "north")
                        {
                            if (currTown.TownGetSect(0).SectorGetLD(0) != "")
                            {
                                currTown.TownSetCurrSect(0); ;// 0 is north

                                panel.BackImageUrl = currTown.TownGetCurrentSect().SectorGetBG();
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + currTown.TownGetCurrentSect().getShop().getShopContents() + "You walked to the northern part of town.";
                            }
                            else
                            {
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "This area does not have a northern section";
                            }
                        }//end if
                        if (words[1] == "south")
                        {
                            if (currTown.TownGetSect(1).SectorGetDir() != "")
                            {
                                currTown.TownSetCurrSect(1);// 1 is south

                                panel.BackImageUrl = currTown.TownGetCurrentSect().SectorGetBG();
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "You walked to the southern part of town.";
                            }
                            else
                            {
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "This area does not have a southern section";
                            }
                        }//end if
                        if (words[1] == "east")
                        {
                            if (currTown.TownGetSect(2).SectorGetLD(2) != "")
                            {
                           // 2 is east
                                currTown.TownSetCurrSect(2);
                                panel.BackImageUrl = currTown.TownGetCurrentSect().SectorGetBG();
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "You walked to the " + currTown.TownGetCurrentSect().SectorGetDir() + "ern part of town. ";
                            }
                            else
                            {
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "This area does not have a eastern section";
                            }
                            }//end if
                        if (words[1] == "west")
                        {
                            if (currTown.TownGetSect(3).SectorGetLD(3) != "")
                            {
                                currTown.TownSetCurrSect(3);// 3 is west

                                panel.BackImageUrl = currTown.TownGetCurrentSect().SectorGetBG();
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "You walked to the western part of town.";
                            }
                            else
                            {
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "This area does not have a western section";
                            }
                        }//end if
                        if (words[1] == "north-east" || words[1] == "northeast")
                        {
                            if (currTown.TownGetSect(4).SectorGetLD(4) != "")
                            {
                                currTown.TownSetCurrSect(4);// 4 is northeast

                                panel.BackImageUrl = currTown.TownGetCurrentSect().SectorGetBG();
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "You walked to the north-eastern part of town.";
                            }
                            else
                            {
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "This area does not have a north-eastern section";
                            }
                        }//end if
                        if (words[1] == "north-west" || words[1] == "northwest")
                        {
                            if (currTown.TownGetSect(5).SectorGetLD(5) != "")
                            {
                                currTown.TownSetCurrSect(5);// 5 is northeast

                                panel.BackImageUrl = currTown.TownGetCurrentSect().SectorGetBG();
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "You walked to the north-western part of town.";
                            }
                            else
                            {
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "This area does not have a north-western section";
                            }
                        }//end if
                        if (words[1] == "south-east" || words[1] == "southeast")
                        {
                            if (currTown.TownGetSect(6).SectorGetLD(6) != "")
                            {
                                currTown.TownSetCurrSect(6);// 6 is southeast

                                panel.BackImageUrl = currTown.TownGetCurrentSect().SectorGetBG();
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "You walked to the south-eastern part of town.";
                            }
                            else
                            {
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "This area does not have a south-eastern section";
                            }
                        }//end if
                        if (words[1] == "south-west" || words[1] == "southwest")
                        {
                            if (currTown.TownGetSect(7).SectorGetLD(7) != "")
                            {
                                currTown.TownSetCurrSect(7);// 7 is southwest

                                panel.BackImageUrl = currTown.TownGetCurrentSect().SectorGetBG();
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "You walked to the south-western part of town.";
                            }
                             else
                             {
                                 return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "This area does not have a south-western section";
                             }
                        }//end if
                        if (words[1] == "home")
                        {
                            return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "You don't have a home...";
                        }//end if
                        return "two words";
                        break;
                    #endregion

                    #region casefuck
                    case "fuck":
                        if (words[1] == "you")
                        {
                            return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "no fuck you";
                        }//end if
                        if (words[1] == "this")
                        {
                            return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "Oh you wanted the enemies to be harder! I got you";
                        }//end if
                        break;
                    #endregion

                    #region caseattack
                    case "attack":
                        if (words[1].Trim() == "tutorial")
                        {
                            return "You walked out of the town. And got attacked by a horse.";
                        }//end if
                        else
                        {
                            if (currTown.TownGetCurrentSect().checkPeopleList(words[1].ToLower()))
                            {
                                currCreature = currTown.TownGetCurrentSect().getPerson(currTown.TownGetCurrentSect().checkPeopleSlot(words[1].ToLower())).getCreature();
                                return "You attacked " + words[1];
                            }//end inner if
                            else
                            {
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "There is no one in this sector named " + words[1];
                            }//end else
                        }

                        return "2 words";
                        break;
                    #endregion

                    #region casebuysell
                    case "buy":
                        if (currTown.TownGetCurrentSect().SectorGetDir() == "North")
                        {
                            Object[] nw = currTown.TownGetCurrentSect().getShop().buyFromShop(playerTeam.getInventory(), words[1].Trim());
                       playerTeam.setInventory((nw[0] as Inventory));
                        return (nw[1] as string);
                        }//end if
                        else
                        {
                            return "there's no shop here, what would make you think there was?";
                        }

                    case "sell":
                        if (currTown.TownGetCurrentSect().SectorGetDir() == "North")
                        {
                            Object[] nw = currTown.TownGetCurrentSect().getShop().sellToShop(playerTeam.getInventory(), words[1]);
                            playerTeam.setInventory((nw[0] as Inventory));
                            return (nw[1] as string);
                        }//end if
                        else { return "there's no shop here, what would make you think there was?"; }
                    #endregion
                
                    #region caseuse
                    case "use":
                        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                       ///// under heavy development
                            for(int i=0; i < playerTeam.getInventory().length(); i++ ){
                                if( playerTeam.getInventory().getItem(i).getName() == words[1]){


                                    return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "";
                                }//end if
                                return "You don't have " + words[1];
                            }//end for

                         /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                        return "2 words";
                        break;
                    #endregion
                    default:
                        return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "I'm really not built for that";
                    
                }//end inner switch
            #endregion
                return "two words";
                break;
            #endregion
    
            #region case3
            case 3:
                switch (words[0])
                {
                    case "talk":
                        if (words[1] == "to")
                        {
                            if (currTown.TownGetCurrentSect().checkPeopleList(words[2].ToLower()))
                            {
                                if (currTown.TownGetCurrentSect().getPerson(currTown.TownGetCurrentSect().checkPeopleSlot(words[2].ToLower())).getConversation().GetDefaultDialogFlag())
                                {
                                    return words[2] + " said: " + currTown.TownGetCurrentSect().getPerson(currTown.TownGetCurrentSect().checkPeopleSlot(words[2].ToLower())).getConversation().talk();
                                }//end inner if
                                else
                                {
                                    currCreature = currTown.TownGetCurrentSect().getPerson(currTown.TownGetCurrentSect().checkPeopleSlot(words[2].ToLower())).getCreature();
                                    currConvo = currTown.TownGetCurrentSect().getPerson(currTown.TownGetCurrentSect().checkPeopleSlot(words[2].ToLower())).getConversation();
                                    return words[2] + " said: " + currTown.TownGetCurrentSect().getPerson(currTown.TownGetCurrentSect().checkPeopleSlot(words[2].ToLower())).getConversation().talkSpecific("");
                                }//end inner else
                            }//end inner if
                            else
                            {
                                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "There is no one in this sector named " + words[2];
                            }//end else
                        }
                        return "2 words";
                        break;
                }
                return "3 words";
                break;
            #endregion
            default:
                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + "I'm not built for that";
                break;
        }//end switch

        return "";
    }//end SentenceChecker
#endregion

    #region townStuff
    public string loadtown(int overLocationX, int overLocationY, int overLocationCell,Panel panel)
    {
        //panel = pan;
        
        if(overLocationCell == 0){
             if (overLocationX >= 38 && overLocationX <= 154 && overLocationY >= 43 && overLocationY <= 140) {
        currTown = town[0];
        currTown.TownSetCurrSect(0);//sets location in town
        panel.BackImageUrl = currTown.TownGetCurrentSect().SectorGetBG();
        return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + currTown.TownGetCurrentSect().getShop().getShopContents();
             }//end inner if

             else if (overLocationX >= 93 && overLocationX <= 140 && overLocationY >= 490 && overLocationY <= 540)
             {
                 currTown = town[1];//make town[modified town] = currTown after exit is called
                 currTown.TownSetCurrSect(1);
                 panel.BackImageUrl = currTown.TownGetCurrentSect().SectorGetBG();
                 return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot());
             }//end else if
            
             return "congrats you broke the game.... not cool";
        }//end else if
        else if (overLocationCell == 1)
        {
            if (overLocationX >= 200 && overLocationX <= 245 && overLocationY >= 420 && overLocationY <= 499)
            {
                currTown = town[2];
                currTown.TownSetCurrSect(0);
                panel.BackImageUrl = currTown.TownGetCurrentSect().SectorGetBG();
                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + currTown.TownGetCurrentSect().getShop().getShopContents();
            }//end else if
            else if (overLocationX >= 307 && overLocationX <= 430 && overLocationY >= 120 && overLocationY <= 410)
            {
                currTown = town[5];
                currTown.TownSetCurrSect(0);
                panel.BackImageUrl = currTown.TownGetCurrentSect().SectorGetBG();
                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + currTown.TownGetCurrentSect().getShop().getShopContents();
            }//end else if
            return "congrats you broke the game.... not cool";
        }//end else if
        else if (overLocationCell == 3)
        {
            if (overLocationX >= 4 && overLocationX <= 175 && overLocationY >= 148 && overLocationY <= 215)
            {
                currTown = town[3];
                currTown.TownSetCurrSect(0);
                panel.BackImageUrl = currTown.TownGetCurrentSect().SectorGetBG();
                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + currTown.TownGetCurrentSect().getShop().getShopContents();
            }//end if
            return "congrats you broke the game.... not cool";
        }//end else if
        else if (overLocationCell == 3)
        {
            if (overLocationX >= 617 && overLocationX <= 655 && overLocationY >= 207 && overLocationY <= 270)
            {
                currTown = town[6];
                currTown.TownSetCurrSect(0);
                panel.BackImageUrl = currTown.TownGetCurrentSect().SectorGetBG();
                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + currTown.TownGetCurrentSect().getShop().getShopContents();
            }//end if
            return "congrats you broke the game.... not cool";
        }//end else if
        else if (overLocationCell == 6)
        {
            if (overLocationX >= 261 && overLocationX <= 344 && overLocationY >= 429 && overLocationY <= 515)
            {
                currTown = town[4];
                currTown.TownSetCurrSect(0);
                panel.BackImageUrl = currTown.TownGetCurrentSect().SectorGetBG();
                return OutputLocationText(currTown, currTown.TownGetCurrentSect(), currTown.TownCurrentGetSectSlot()) + currTown.TownGetCurrentSect().getShop().getShopContents();
            }//end else if
            return "congrats you broke the game.... not cool";
        }//end else if
        return "";

    }//end loadTown

    public string getCurrTownName() { return currTown.Name; }
    public Creature getCurrCreature() { return currCreature; }

    #endregion
    public String[] removeFluff(String[] temp,int slot)
    {

        String[] temp2 = new String[temp.Length - 1];

        int b = 0;
        for (int i = 0; i < temp.Length; i++)
        {
            if (i != slot)
            {
                temp2[b] = temp[i];
                b++;
            }
        }//end for
        return temp2;
    }//end removeFluff
}//end class