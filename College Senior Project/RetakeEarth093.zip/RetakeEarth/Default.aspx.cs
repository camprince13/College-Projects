﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
        if (!string.IsNullOrEmpty(Session["AccLvl"] as String))
        {
            if (Session["AccLvl"].ToString() == "1") 
            {
                lbl1.Text = "<br />Logged in - " + Session["LoggedIn"] + "<br />" +
                "Name - " + Session["Uname"] + "<br />" + "Access Level - " + Session["AccLvl"];
            }
            else
            {
                lbl1.Text = "";
            }
        } 
             else
            {
                lbl1.Text = "";
            }

        DBPerson temp = new DBPerson();

        News.InnerHtml = temp.NewsToHTML();

    }//End pg load


}//End page