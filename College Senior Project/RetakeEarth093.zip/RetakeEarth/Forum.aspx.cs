﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient; //SQL database
using System.Data; //database


public partial class Forum : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        txtNewCat.ReadOnly = true;
        txtNewCat.Enabled = false;

        txtDesc.ReadOnly = true;
        txtDesc.Enabled = false;

        btnSub.Visible = false;
        btnSub.Enabled = false;

        Label1.Visible = false;
        Label1.Enabled = false;

        Label2.Visible = false;
        Label2.Enabled = false;

        txtNewCat.Style.Add("visibility", "hidden");
        txtDesc.Style.Add("visibility", "hidden");

        Category temp = new Category();
        Forums.InnerHtml = temp.CatToHTML();

        if (Convert.ToString(Session["AccLvl"]) == "1") { 


        txtNewCat.ReadOnly = false;
        txtNewCat.Enabled = true;

        txtDesc.ReadOnly = false;
        txtDesc.Enabled = true;

        btnSub.Visible = true;
        btnSub.Enabled = true;

        Label1.Visible = true;
        Label1.Enabled = true;

        Label2.Visible = true;
        Label2.Enabled = true;

        txtNewCat.Style.Add("visibility", "visible");
        txtDesc.Style.Add("visibility", "visible");
        }//end admin area


    }//page load end


    protected void btnSub_Click(object sender, EventArgs e)
    {
        string newCat = txtNewCat.Text;
        string descr = txtDesc.Text;

        if (newCat != "" && descr != "")
        {


            //SQL Statement
            String strSQL = "Insert into Categories(cat_name, cat_description) values(@nm, @des)";


            // Create a connection to DB
            SqlConnection conn = new SqlConnection();

            string strConn = @DBLogin.GetConnected();

            conn.ConnectionString = strConn;

            //send out the command
            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@nm", newCat);
            comm.Parameters.AddWithValue("@des", descr);

            try
            {
                conn.Open();
                comm.ExecuteNonQuery().ToString();

                conn.Close();
            }
            catch (Exception err)
            {

            }

            Response.Redirect(Request.RawUrl);
        }//end  of if

    }//end submit cat

}//end class