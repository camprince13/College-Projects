﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient; //SQL database
using System.Data; //database

public partial class ForumTopic : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Threads temp = new Threads();
        Forums.InnerHtml = temp.ThreadsToHTML();
        if (Session["LoggedIn"] != "True")
        {
            txtNewTopic.ReadOnly = true;
            txtNewTopic.Text = "Please login to post";
            btnTopic.Visible = false;
            btnTopic.Enabled = false;
        }
    }//page load ends


    private string encrypt(string str)
    {
        string temp = "";

        if (str != "")
        {
            string x = @DBLogin.Passphr();
            string y = str;
            temp = _001_encrypt.service.EncryptString(y, x);
        }
        else
        { temp = ""; }

        return temp;
    }//end encrypt


    private string cat = System.Web.HttpContext.Current.Request["cat"];

    
    protected void btnTopic_Click(object sender, EventArgs e)
    {
        string NewTopic = txtNewTopic.Text;

        if(NewTopic != ""){

            if (Validation.HasCurseWordAgressive(NewTopic)) { NewTopic = Validation.censorStringAgressive(NewTopic); }
        
        //SQL Statement
        String strSQL = "Insert into Topics(topic_subject, topic_date, topic_cat, topic_by) values(@top, @dte, @topcat, @owner)";


        // Create a connection to DB
        SqlConnection conn = new SqlConnection();

        string strConn = @DBLogin.GetConnected();

        conn.ConnectionString = strConn;

        //send out the command
        SqlCommand comm = new SqlCommand();
        comm.CommandText = strSQL;
        comm.Connection = conn;

        comm.Parameters.AddWithValue("@top", NewTopic);
        comm.Parameters.AddWithValue("@dte", DateTime.Now);
        comm.Parameters.AddWithValue("@topcat", cat);
        comm.Parameters.AddWithValue("@owner", encrypt(Session["Uname"].ToString()));

        try
        {
            conn.Open();
            comm.ExecuteNonQuery().ToString();

            conn.Close();
        }
        catch (Exception err)
        {

        }

        Response.Redirect(Request.RawUrl);
        }//end  of if


    }// end of btnTopic click


}//end of class