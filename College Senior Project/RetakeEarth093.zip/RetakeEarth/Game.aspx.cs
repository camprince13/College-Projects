﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Game : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["Team"] == null)
        {
            //hideAllPanels();
            showOverworld();
        }

        #region combat session page_load stuff
        if (Session["LoggedIn"] != "True")
        {
            Response.Redirect("Login2.aspx");
        }


        if (Session["Combat"] != "" && Session["Combat"] != null)
        {
            //playerTeam = Session["Team"] as Team;
            combat = Session["Combat"] as Combat;
        }

        if (Session["CombLbls"] != "" && Session["CombLbls"] != null)
        {
            string[] tmpLbls = Session["CombLbls"] as string[];
            lblEnemyTeam.Text = tmpLbls[0];
            lblAllyTeam.Text = tmpLbls[1];
            lblGeneralText.Text = tmpLbls[2];
            popItmDrp();
            popTarDrp();
        }
       
        
        else
        {
            if (Session["Team"] != "" && Session["Team"] != null)
            {
                playerTeam = Session["Team"] as Team;
                lblInvOutput.Text = playerTeam.displayAll();
            }//end inner if
            else {
                //this is temp, put real player team here
                if (teamFromDB() != 1)
                { ////////////////////////////////////////////////////////////////////////////////////

                    string s = (Session["Uname"].ToString());
                    s = char.ToUpper(s[0]) + s.Substring(1);

                    playerTeam = new Team(new Creature(s, 15, 5), new Creature("Sherman", 15, 5), new Creature("Reilly", 12, 3));
                    playerTeam.setTextAdv(new textAdventure());
                }////////////////////////////////////////////////////////////////////////////////////////////////////////////
                else { teamSessToVar(); }
                //playerTeam = new Team(new Creature("A", 100, 5), new Creature("B", 100, 5), new Creature("C", 100, 3));
            }//end inner else

            combat = new Combat(new Team(), playerTeam, 1);//enemy team, player team, seed(0 for simple ai) ++for higher
            HttpContext.Current.Session["Team"] = playerTeam;
            HttpContext.Current.Session["Combat"] = combat;
            afterMain(combat.getBasicGui());
        }
        #endregion

        #region inventory page_load stuff

        popEquipeeDrp();
        popEquipItem();

        #endregion



    }//end pg load

    #region combat stuff
    
    Team playerTeam;// = new Team(new Creature("A", 12, 3), new Creature("B", 12, 3),new Creature("C", 12, 3));
    Combat combat;
    string previousMode;

    private void afterMain(string[] tmpLbls) {

        lblEnemyTeam.Text = tmpLbls[0];
        lblAllyTeam.Text = tmpLbls[1];
        lblGeneralText.Text = tmpLbls[2];

        HttpContext.Current.Session["Team"] = combat.getAllies(); //playerTeam;
        HttpContext.Current.Session["Combat"] = combat;
        HttpContext.Current.Session["CombLbls"] = tmpLbls;

        popItmDrp();
        popTarDrp();
        updatePan.Update();
    }//end after combat main sequence

    private void newCombat() {

        HttpContext.Current.Session["Team"] = combat.getAllies();
        HttpContext.Current.Session["Combat"] = null;
        HttpContext.Current.Session["CombLbls"] = null;

        updatePan.Update();
    }//end new combat

    private void popItmDrp() {

        HttpContext.Current.Session["selectedItem"] = drpItem.SelectedIndex;

        drpItem.Items.Clear();
        drpItem.Items.Add("sm. potion");
        drpItem.Items.Add("med. potion");
        drpItem.Items.Add("lrg. potion");
        drpItem.Items.Add("buff F");
        drpItem.Items.Add("buff L");
        drpItem.Items.Add("buff A");
        drpItem.Items.Add("buff S");
        drpItem.Items.Add("buff K");
        drpItem.Items.Add("Revive");

        try
        {
            drpItem.SelectedIndex = Convert.ToInt32(Session["selectedItem"]);
        }
        catch { }
    }

    private void popTarDrp() {

        HttpContext.Current.Session["selectedTarget"] = drpTarget.SelectedIndex;
        drpTarget.Items.Clear();

        string[] tmp = combat.getListOfTargets();

        for (int i = 0; i < tmp.Length; i++ ) {
            drpTarget.Items.Add(tmp[i]);
        }//end for

        try
        {
            drpTarget.SelectedIndex = Convert.ToInt32(Session["selectedTarget"]);
        }
        catch { }

    }//end popDrp

    private void teamSessToVar() {

        if (Session["Team"] != "" && Session["Team"] != null)
        {
            playerTeam = Session["Team"] as Team;
        }
    }//end teamSessToVar

    private void teamVarToSess() {

        if (playerTeam != null)
        { 
            teamToDB();//puts team into db
            HttpContext.Current.Session["Team"] = playerTeam; 
        }
    }//end teamVarToSess

    private void callCombat(Team t, int AI_Lvl, string mode)
    {
        previousMode = mode;
        HttpContext.Current.Session["previousMode"] = previousMode;
        hideAllPanels();
        newCombat();
        playerTeam = Session["Team"] as Team;
        combat = new Combat(t, playerTeam, AI_Lvl);
        HttpContext.Current.Session["Combat"] = combat;
        afterMain(combat.getBasicGui());
        showCombat();
    }//end call combat

    private void returnFromCombat()
    {

        previousMode = Session["previousMode"] as string;

        if (previousMode != null && previousMode != "")
        {
            hideAllPanels();

            if (previousMode == "text") { showTextAdv();
            lblOutput.Text += "<br />" + lblGeneralText.Text;
            }
            if (previousMode == "overw")
            {
                showOverworld();
                //Script manager is being used to call javascript directly. Will attempt to 
                //use this to redraw the canvas. Displays an alert right now
            }

        }
        
    }//end returnFromCombat

    public void deathHandle() {

        teamSessToVar();

        Creature tmp = playerTeam.getDeadCreature(0);
        playerTeam.removeDeadCreature(0);
        tmp.recieveHeals(10);
        playerTeam.addCreature(tmp);
        Inventory inv = playerTeam.getInventory();
        int penalty = ((playerTeam.deadLength() + 1) * playerTeam.getAvgLvl()); 
        inv.addCurrency(penalty);
        playerTeam.setInventory(inv);

        showTextAdv();

        lblOutput.Text = tmp.getName() + " wakes up in " + playerTeam.getTextAdv().getCurrTownName() + ".<br />";
        lblOutput.Text += tmp.getName() + " also notices that " + penalty + " credits are missing.";
        UpdatePanTextAdv.Update();

        teamVarToSess();

    }//end death handle

    private int teamFromDB() {
        DBPerson tmp = new DBPerson();
        Team tmp2 = tmp.getGameData((Session["Uname"].ToString()));
        if (tmp2 != null && tmp2.ToString() != "")
        {
            HttpContext.Current.Session["Team"] = tmp2;
            return 1;
        }
        else { return 0; }
    }

    private void teamToDB() {
        DBPerson tmp = new DBPerson();
        tmp.setGameData(playerTeam, (Session["Uname"].ToString()));
    }

    #endregion

    #region Combat related buttons

    protected void btnStart_Click(object sender, EventArgs e)
    {
        teamSessToVar();
        updatePan.Update();
        string[] tmpLbls = combat.mainSequence(0, drpTarget.SelectedIndex);
        afterMain(tmpLbls);

        if (combat.getWinRes()) { returnFromCombat(); }

        else if (tmpLbls[2].Contains("you lose")) { deathHandle(); }

        teamVarToSess();
    }//end btnStart

    protected void btnDefend_Click(object sender, EventArgs e)
    {
        updatePan.Update();

        string[] tmpLbls = combat.mainSequence(1, drpTarget.SelectedIndex);

        afterMain(tmpLbls);

        if (combat.getWinRes()) { returnFromCombat(); }

        else if (tmpLbls[2].Contains("you lose")) { deathHandle(); }

        teamVarToSess();

    }

    protected void btnUseItem_Click(object sender, EventArgs e)
    {
        string[] tmpLbls = combat.mainSequence(drpItem.SelectedIndex + 2, drpTarget.SelectedIndex);//added target///////////////////////
        afterMain(tmpLbls);

        if (combat.getWinRes()) { returnFromCombat(); }

        else if (tmpLbls[2].Contains("you lose")) { deathHandle(); }

        teamVarToSess();
    }

    protected void btnFlee_Click(object sender, EventArgs e)
    {
        //newCombat();
        string[] tmpLbls = combat.mainSequence(999, drpTarget.SelectedIndex);
        afterMain(tmpLbls);
        if (tmpLbls[2].Contains("Coward")) { returnFromCombat(); }

        if (combat.getWinRes()) { returnFromCombat(); }

        else if (tmpLbls[2].Contains("you lose")) { deathHandle(); }

        teamVarToSess();
    }

    #endregion

    #region panel funtions

    public void hideAllPanels() 
    {
        panCombat.Visible = false;
        panOverworld.Visible = false;
        panTextAdv.Visible = false;
        panInv.Visible = false;
        //btnStartTxtAdv.Visible = false;
        //btnJsStartCombat.Visible = false;
        Button1.Visible = false;
        Button2.Visible = false;
        Button3.Visible = false;
        Button4.Visible = false;

        updatePan.Update();
        updatePanOver.Update();
        UpdatePanTextAdv.Update();
        updatePanInv.Update();
    }

    public void showCombat() 
    {
        hideAllPanels();
        panCombat.Visible = true;
        updatePan.Update();
    }

    public void showOverworld()
    {
        hideAllPanels();
        panOverworld.Visible = true;
        //updatePanOver.Update();
        ScriptManager.RegisterStartupScript(this,
                   typeof(Page),
                   "UpdateMsg",
                   "$(document).ready(function(){reCallEverything();});", true);

        Button4.Visible = true;
        updatePanOver.Update();
    }

    public void showTextAdv()
    {
        hideAllPanels();
        panTextAdv.Visible = true;
        Button4.Visible = true;
        UpdatePanTextAdv.Update();
    }

    public void showInventory()
    {
        hideAllPanels();

        if (playerTeam != null){lblInvOutput.Text = playerTeam.displayAll();}

        else if (Session["Team"] != "" && Session["Team"] != null) 
        {Team t = Session["Team"] as Team;
        lblInvOutput.Text = t.displayAll();}

        Button2.Visible = true;
        Button3.Visible = true;

        panInv.Visible = true;
        updatePanInv.Update();
    }

    #endregion

    #region overworld stuff

    int[] overworldPos; //0 = x, 1 = y, 2 = cellPos
    int test;
    public void setOverWSess()
    {
        overworldPos = new int[3] {Convert.ToInt32(shapeX.Value), Convert.ToInt32(shapeY.Value), Convert.ToInt32(cell.Value)};
        HttpContext.Current.Session["overworld"] = overworldPos;
    }

    public void getOverWSess() 
    {
        if (Session["overworld"] != null)
        {
            overworldPos = Session["overworld"] as int[];

            shapeX.Value = Convert.ToString(overworldPos.GetValue(0));
            shapeY.Value = Convert.ToString(overworldPos.GetValue(1));
            cell.Value = Convert.ToString(overworldPos.GetValue(2));
        }
    }

    #endregion

    #region inventory stuff

    private void popEquipeeDrp()
    {
        HttpContext.Current.Session["Equipee"] = drpEquipee.SelectedIndex;

        if (playerTeam != null)
        {
            drpEquipee.Items.Clear();

            string[] tmp = playerTeam.getListOfCreatures(); //combat.getListOfTargets();

            for (int i = 0; i < tmp.Length; i++)
            {
                drpEquipee.Items.Add(tmp[i]);
            }//end for
        }//end if not null

        else if (Session["Team"] != "" && Session["Team"] != null)
        {
            playerTeam = Session["Team"] as Team;
            popEquipeeDrp();
        }

        try
        {
            drpEquipee.SelectedIndex = Convert.ToInt32(Session["Equipee"]);
        }
        catch { }

    }//end popDrp

    private void popEquipItem() 
    {
        HttpContext.Current.Session["EquipItem"] = drpEquipItem.SelectedIndex;

        if (playerTeam != null)
        {
            drpEquipItem.Items.Clear();

            string[] tmp = playerTeam.getListOfItems(); //combat.getListOfTargets();

            for (int i = 0; i < tmp.Length; i++)
            {
                drpEquipItem.Items.Add(tmp[i]);
            }//end for
        }//end if not null

        else if (Session["Team"] != "" && Session["Team"] != null)
        {
            playerTeam = Session["Team"] as Team;
            popEquipItem();
        }

        try
        {
            drpEquipItem.SelectedIndex = Convert.ToInt32(Session["EquipItem"]);
        }
        catch { }
    }//end popEquipItem

    private void equipItem() { 
    
        teamSessToVar();
        popEquipeeDrp();
        popEquipItem();

        playerTeam.equipItem(drpEquipee.SelectedIndex, drpEquipItem.SelectedIndex);

        teamVarToSess();
        lblInvOutput.Text = playerTeam.displayAll();
        updatePanInv.Update();
    }

    protected void btnEquip_Click(object sender, EventArgs e)
    {
        equipItem();
        //lblInvOutput.Text = drpEquipee.SelectedIndex.ToString() + drpEquipItem.SelectedIndex;
        updatePanInv.Update();
        popEquipeeDrp();
        popEquipItem();
        updatePanInv.Update();
    }

    #endregion

    #region textAdv Functions
    textAdventure txtAdv;

    private void textAdvSessToVar()
    {
        if (Session["TxtAdv"] != "" && Session["TxtAdv"] != null)
        {
            txtAdv = Session["TxtAdv"] as textAdventure;
        }
    }//end teamSessToVar

    private void textAdvVarToSess()
    {
        if (txtAdv != null)
        { HttpContext.Current.Session["TxtAdv"] = txtAdv; }
    }//end teamVarToSess

    #endregion

    protected void btnTxtAdvSubmit_Click(object sender, EventArgs e)
    {
        /*textAdvSessToVar();//pulls from session

        if (txtAdv == null && Session["TxtAdv"] == null)
        {
            txtAdv = new textAdventure();
        }

        */

        //Town mountainboro = new Town();

        //if (playerTeam == null) { teamSessToVar(); }
        teamSessToVar();


        
        lblOutput.Text = playerTeam.getTextAdv().CheckText(txtTextAdventureInput.Text, playerTeam, panTextAdv); 
        UpdatePanTextAdv.Update();
        

        if (lblOutput.Text == "You leave the town")
        {
            showOverworld();
            lblOutput.Text = "";

            //testing boss ai
            //playerTeam.awardXp(999);
            //callCombat(new Team(), 2, "text");

        }//end if
        else if (lblOutput.Text == "You walked out of the town. And got attacked by a horse.")
        {
            Creature cr = new Creature("Horse", 11, 3);
            cr.setWeapon(new Weapon("shovel", 3, 2, 3));
            Team t = new Team(cr);
            callCombat(t,0,"text");

        }//end else if
        else if (lblOutput.Text.Contains("You attacked "))
        {
            if (playerTeam.getTextAdv().getCurrCreature().getTempHp() <= 0)
            {
                lblOutput.Text = "Didn't you already attack this guy? not cool";
                playerTeam.getTextAdv().getCurrCreature().recieveXp(200);
                playerTeam.getTextAdv().getCurrCreature().resetToFull();
            }
            else
            {
                Team t = new Team(playerTeam.getTextAdv().getCurrCreature());
                callCombat(t, 0, "text");
            }
        }//end else if
        
        teamVarToSess();
        
        txtTextAdventureInput.Text = "";
    }//end txt button




    protected void txtTextAdventureInput_TextChanged(object sender, EventArgs e)
    {

    }



    protected void Button1_Click(object sender, EventArgs e)
    {
        setOverWSess();
        showCombat();
       
    }
    protected void Button2_Click(object sender, EventArgs e)
    {


        getOverWSess();
        showOverworld();
       
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        setOverWSess();
        showTextAdv();
    }  
    protected void Button4_Click(object sender, EventArgs e)
    {
        setOverWSess();
        showInventory();
        
    }

    protected void btnJsStartCombat_Click(object sender, EventArgs e)
    {
        setOverWSess();

        callCombat(new Team(), 0, "overw");

        showCombat();
        
    }
    protected void btnStartTxtAdv_Click(object sender, EventArgs e)
    {
        showTextAdv();
        teamSessToVar();
        setOverWSess();
        getOverWSess();


        lblOutput.Text = playerTeam.getTextAdv().loadtown(overworldPos[0], overworldPos[1], overworldPos[2], panTextAdv);// loadTown();
        teamVarToSess();
    }
}//end page