﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;
using System.Text;


public partial class Account_Login2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Panel2.Enabled = false;
        Panel2.Visible = false;
        Panel3.Enabled = false;
        Panel3.Visible = false;

        if (Session["RegStatus"] != null && Session["RegStatus"] != "")
        {
            if (Session["RegStatus"].ToString().ToLower().Contains("error"))
            {
                showREg();
                //lblEnterUnamePass.Text = Session["RegStatus"].ToString();
                txtRegUname.Text = Session["Uname"].ToString();
                lblOutput2.Text = Session["RegStatus"].ToString();
                Session["RegStatus"] = null;
            }
            else {
                lblEnterUnamePass.Text = "Registration Successful"; //Session["RegStatus"].ToString();
            Session["RegStatus"] = null;
            }
        }//end if regStatus null


        if (Session["LoggedIn"] == "True") {

            lblEnterUnamePass.Enabled = false;
            lblEnterUnamePass.Visible = false;
            lblRegButtonText.Enabled = false;
            lblRegButtonText.Visible = false;
            btnShowReg.Enabled = false;
            btnShowReg.Visible = false;

            Panel1.Enabled = false;
            Panel1.Visible = false;
            Panel3.Enabled = true;
            Panel3.Visible = true;
        }

    }//End load Page


    protected void LoginButton_Click(object sender, EventArgs e)
    {
       txtUname.Text = txtUname.Text.ToLower();
       if (txtUname.Text != "" && txtPass.Text != "")
       {
               if (txtUname.Text.Length <= 30 && txtPass.Text.Length <= 30)
               {

                   if (isEmptyUserPass(txtUname.Text) && isEmptyUserPass(txtPass.Text))
                   {

                       //
                       DBPerson temp = new DBPerson();
                       string tmp = temp.PersonLogin(txtUname.Text, txtPass.Text);
                       string tmp2 = "";

                       if (tmp != "")
                       {
                           tmp2 = "Login Validated. Access Level = " + tmp;
                           Session["LoggedIn"] = "True";
                           Session["Uname"] = txtUname.Text;
                           Session["AccLvl"] = tmp;
                           Response.Redirect("Default.aspx");
                       }

                       else
                       {
                           tmp2 = "Login Failed.";
                           lblOutput.Text = tmp2;
                       }

                       //lblOutput.Text = tmp2;
                       //
                   }
                   else { lblOutput.Text = "Error: invalid characters in username or password"; }
               }
               else { lblOutput.Text = "Error: username or password is over 30 characters"; }
           }
       else { lblOutput.Text = "Error: blank username or password"; }

    }//end button

    private bool isEmptyUserPass(string temp)
    {

        Regex regex = new Regex(@"^[a-zA-Z0-9]+$");

        if (regex.Match(temp).Success)
        { return true; }

        else
        { return false; }

    }//end isEmptyUserPass

    protected void btnReg_Click(object sender, EventArgs e)
    {
        txtRegUname.Text = txtRegUname.Text.ToLower();

        if (txtBeta.Text.ToLower() == "group1")
        {

            if (txtRegUname.Text != "" && txtRegPass1.Text != "" && txtRegPass2.Text != "" && txtEmail.Text != "")
            {
                if (txtRegUname.Text.Length <= 30 && txtRegPass1.Text.Length <= 30 && txtRegPass2.Text.Length <= 30)
                {

                    if (isEmptyUserPass(txtRegUname.Text) && isEmptyUserPass(txtRegPass1.Text))
                    {
                        if (txtRegPass1.Text == txtRegPass2.Text)
                        {
                            if (Validation.IsValidEmail(txtEmail.Text))
                            {
                                //
                                DBPerson temp = new DBPerson();
                                string tmp = temp.AddContact(txtRegUname.Text, txtRegPass1.Text, txtEmail.Text);
                                Session["RegStatus"] = tmp;
                                Session["Uname"] = txtRegUname.Text;
                                lblOutput2.Text = tmp;
                                Response.Redirect("Login2.aspx");
                                //
                            }
                            else { lblOutput2.Text = "Error: invalid email"; showREg(); }
                        }
                        else { lblOutput2.Text = "Error: Passwords do not match"; showREg(); }
                    }
                    else { lblOutput2.Text = "Error: invalid characters in username or password"; showREg(); }
                }
                else { lblOutput2.Text = "Error: username or password is over 30 characters"; showREg(); }
            }
            else { lblOutput2.Text = "Error: blank username, password, or email"; showREg(); }
        }
        else { lblOutput2.Text = "Error: invalid beta code. A beta code is currently needed to register."; showREg(); }
    }//reg

    protected void btnShowReg_Click(object sender, EventArgs e)
    {
    showREg();
    }//end show reg btn

    private void showREg() {
        Panel1.Enabled = false;
        Panel1.Visible = false;
        Panel2.Enabled = true;
        Panel2.Visible = true;
        lblEnterUnamePass.Enabled = false;
        lblEnterUnamePass.Visible = false;
        lblRegButtonText.Enabled = false;
        lblRegButtonText.Visible = false;
        btnShowReg.Enabled = false;
        btnShowReg.Visible = false;
    }//end show reg


    protected void btnLogOut_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        /*Session.Clear();
        Session.Contents.RemoveAll();
        Session.RemoveAll();*/
        Response.Redirect("Login2.aspx");
    }


}//class