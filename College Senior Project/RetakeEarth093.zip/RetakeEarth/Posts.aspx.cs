﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient; //SQL database
using System.Data; //database

public partial class Posts : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        /*Threads temp = new Threads();
        Forums.InnerHtml = temp.ThreadsToHTML();*/
        Post temp2 = new Post();
        Posts2.InnerHtml = temp2.PostsToHTML();
        if (Session["LoggedIn"] != "True")
        {
            txtPoster.ReadOnly = true;
            txtPoster.Text = "Please login to post";
            btnPost.Visible = false;
            btnPost.Enabled = false;
        }
    }//end page load
    private string encrypt(string str)
    {
        string temp = "";

        if (str != "")
        {
            string x = @DBLogin.Passphr();
            string y = str;
            temp = _001_encrypt.service.EncryptString(y, x);
        }
        else
        { temp = ""; }
        return temp;
    }//end encrypt
    
    private string topic = System.Web.HttpContext.Current.Request["topic"];


    protected void btnPost_Click(object sender, EventArgs e)
    {
        string post = txtPoster.Text;

        if (Validation.HasCurseWordAgressive(post)) { post = Validation.censorStringRandomReplace(post); } //{ post = Validation.censorString(post); }

        //SQL Statement
        String strSQL = "Insert into Posts(post_content, post_date, post_topic, post_by) values(@pst, @dte, @top, @owner)";

        // Create a connection to DB
        SqlConnection conn = new SqlConnection();

        string strConn = @DBLogin.GetConnected();

        conn.ConnectionString = strConn;

        //send out the command
        SqlCommand comm = new SqlCommand();
        comm.CommandText = strSQL;
        comm.Connection = conn;

        comm.Parameters.AddWithValue("@pst", post);
        comm.Parameters.AddWithValue("@dte", DateTime.Now);
        comm.Parameters.AddWithValue("@top", Convert.ToInt32(topic));
        comm.Parameters.AddWithValue("@owner", encrypt(Session["Uname"].ToString()));

        try
        {
            conn.Open();
            comm.ExecuteNonQuery().ToString();

            conn.Close();
        }
        catch (Exception err)
        {
            
        }

        Response.Redirect(Request.RawUrl);
    }//end post_click



}//class posts