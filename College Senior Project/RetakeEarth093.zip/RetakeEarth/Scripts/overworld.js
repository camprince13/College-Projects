﻿

       
if (document.getElementById("canvOverworld") != null) {
    var c = document.getElementById("canvOverworld");
    var ctx = c.getContext("2d");
    //getting session locations. may not be working correctly, more testing will be done
    getVariables();
    var keyBoardOn = 0;
    //Array to hold the overworld grid
    var gridCellBackgrounds = new Array();

    gridCellBackgrounds[0] = new Image();
    gridCellBackgrounds[0].src = 'images/CellA1.png';

    gridCellBackgrounds[1] = new Image();
    gridCellBackgrounds[1].src = 'images/CellA2.png';

    gridCellBackgrounds[2] = new Image();
    gridCellBackgrounds[2].src = 'images/CellA3.png';

    gridCellBackgrounds[3] = new Image();
    gridCellBackgrounds[3].src = 'images/CellB1.png';

    gridCellBackgrounds[4] = new Image();
    gridCellBackgrounds[4].src = 'images/CellB2.png';

    gridCellBackgrounds[5] = new Image();
    gridCellBackgrounds[5].src = 'images/CellB3.png';

    gridCellBackgrounds[6] = new Image();
    gridCellBackgrounds[6].src = 'images/CellC1.png';

    gridCellBackgrounds[7] = new Image();
    gridCellBackgrounds[7].src = 'images/CellC2.png';

    gridCellBackgrounds[8] = new Image();
    gridCellBackgrounds[8].src = 'images/CellC3.png';

    //Getting character image
    var playerCharacter = new Image();
    playerCharacter.src = 'images/Character.png';

    


    //Background image coordinates
    var backX = 0;
    var backY = 0;
    var cellNum = 0;
    if (cellNum != hidCell) {
        cellNum = hidCell
    }
    var previousCell = 1;

    var background = new Image();

    //declaring the keys used for movment
    var Keys = {
        up: false,
        down: false,
        left: false,
        right: false
    };

    //Player shape
     var shape = {
        height: 45,
        width: 35,
        x: 200,
        y: 100,
        //color: "red",
        //char: playerCharacter,
        previousX: 0,
        previousY: 0
    }

    //grabs the locations saved in sessions
    if (shape.x != hidShapeX && shape.y != hidShapeY) {
        shape.x = hidShapeX;
        shape.y = hidShapeY;
    }
    
    //test being called by scriptmanager
   /* function testScript() {
        //alert("Please show this");
        c = document.getElementById("canvOverworld");
        ctx = c.getContext("2d");
        background.src = 'images/CellA1.png';
        backX = 0;
        backY = 0;
        ctx.drawImage(background, backX, backY);

        shape = {
            height: 20,
            width: 20,
            x: hidShapeX,
            y: hidShapeY,
            color: "red",
            previousX: 0,
            previousY: 0
        }
        gameLoop();
        testTest();
    }*/

   

    //Draw the canvas and render background based on player location
    function renderCanvas() {
        
        //move between overworld cells
        if (background.src == gridCellBackgrounds[cellNum].src) {
            background.src = gridCellBackgrounds[cellNum].src
            shape.previousX = shape.x;
            shape.previousY = shape.y;
            randomEncounter();
        }
            //make it possible to enter events
        else if (cellNum != previousCell) {
            background.src = gridCellBackgrounds[cellNum].src
            previousCell = cellNum;
        }
            //to deal with exiting special events
        else if (background.src != gridCellBackgrounds[cellNum].src) {
            if (shape.x < 0 || shape.x > 800 || shape.y < 0 || shape.y > 600) {
                background.src = gridCellBackgrounds[previousCell].src
                if (background.src == gridCellBackgrounds[previousCell].src) {
                    shape.x = shape.previousX;
                    shape.y = shape.previousY;

                }
            }
        }


        ctx.drawImage(background, backX, backY);

        if (background.src == gridCellBackgrounds[cellNum].src) {
            //Entering towns, dungeons, ect. will be handled here
            //CellA1
            if (cellNum == 0) {
                //Right border crossed
                if (shape.x > 781) {
                    shape.x = 1;
                    cellNum++;
                }
                    //Left border crossed
                else if (shape.x < 1) {
                    shape.x = 1;
                }
                    //Top border crossed
                else if (shape.y < 1) {
                    shape.y = 1;
                }
                    //Bottom border crossed
                else if (shape.y > 581) {
                    shape.y = 1;
                    cellNum += 3;
                }
                //Special events specific to cells will be handled here
                //Enter Falsewind
                enterLocation(38, 154, 43, 140, 'images/VillageTownEct.png');
                //Enter Temple of the Faithless
                enterLocation(93, 140, 490, 540, 'images/TemplePlaceHolder.png');

            }

            //CellA2
            if (cellNum == 1) {
                //Right border crossed
                if (shape.x > 781) {
                    shape.x = 1;
                    cellNum++;
                }
                    //Left border crossed
                else if (shape.x < 0) {
                    shape.x = 780;
                    cellNum--;
                }
                    //Top border crossed
                else if (shape.y < 1) {
                    shape.y = 1;
                }
                    //Bottom border crossed
                else if (shape.y > 581) {
                    shape.y = 1;
                    cellNum += 3;
                }
                //Special events specific to cells will be handled here
                riverCollision(510, 480, 450, 270, 425, boat);
                //Entering temple2
                enterLocation(190, 245, 420, 499, 'images/TemplePlaceHolder.png');
                //Enter large town
                enterLocation(307, 430, 120, 410, 'images/VillageTownEct.png');
            }

            //CellA3
            if (cellNum == 2) {
                //Right border crossed
                if (shape.x > 781) {
                    shape.x = 781;
                }
                    //Left border crossed
                else if (shape.x < 0) {
                    shape.x = 780;
                    cellNum--;
                }
                    //Top border crossed
                else if (shape.y < 1) {
                    shape.y = 1;
                }
                    //Bottom border crossed
                else if (shape.y > 581) {
                    shape.y = 1;
                    cellNum += 3;
                }
                //Special events specific to cells will be handled here
                
            }

            //CellB1
            if (cellNum == 3) {
                //Right border crossed
                if (shape.x > 781) {
                    shape.x = 1;
                    cellNum++;
                }
                    //Left border crossed
                else if (shape.x < 1) {
                    shape.x = 1;
                }
                    //Top border crossed
                else if (shape.y < 0) {
                    shape.y = 580;
                    cellNum -= 3;
                }
                    //Bottom border crossed
                else if (shape.y > 581) {
                    shape.y = 1;
                    cellNum += 3;
                }
                //Special events specific to cells will be handled here
                //Enter woodland village
                enterLocation(4, 175, 148, 215, 'images/VillageTownEct.png');
            }

            //CellB2
            if (cellNum == 4) {
                //Right border crossed
                if (shape.x > 781) {
                    shape.x = 1;
                    cellNum++;
                }
                    //Left border crossed
                else if (shape.x < 0) {
                    shape.x = 780;
                    cellNum--;
                }
                    //Top border crossed
                else if (shape.y < 1) {
                    shape.y = 580;
                    cellNum -= 3
                }
                    //Bottom border crossed
                else if (shape.y > 581) {
                    shape.y = 1;
                    cellNum += 3;
                }

                //Special events specific to cells will be handled here
                //Enter tower
                enterLocation(617, 655, 207, 270, 'images/VillageTownEct.png');
                riverCollision(430, 410, 455, 229, 410, boat);


            }

            //CellB3
            if (cellNum == 5) {
                //Right border crossed
                if (shape.x > 781) {
                    shape.x = 781;
                }
                    //Left border crossed
                else if (shape.x < 0) {
                    shape.x = 780;
                    cellNum--;
                }
                    //Top border crossed
                else if (shape.y < 1) {
                    shape.y = 580;
                    cellNum -= 3
                }
                    //Bottom border crossed
                else if (shape.y > 581) {
                    shape.y = 1;
                    cellNum += 3;
                }
                //Special events specific to cells will be handled here
                
            }

            //CellC1
            if (cellNum == 6) {
                //Right border crossed
                if (shape.x > 781) {
                    shape.x = 1;
                    cellNum++;
                }
                    //Left border crossed
                else if (shape.x < 1) {
                    shape.x = 1;
                }
                    //Top border crossed
                else if (shape.y < 1) {
                    shape.y = 580;
                    cellNum -= 3;
                }
                    //Bottom border crossed
                else if (shape.y > 581) {
                    shape.y = 581;
                }
                //Special events specific to cells will be handled here
                //Enter nomad camp
                enterLocation(261, 344, 429, 515, 'images/VillageTownEct.png');
            }

            //CellC2
            if (cellNum == 7) {
                //Right border crossed
                if (shape.x > 781) {
                    shape.x = 1;
                    cellNum++;
                }
                    //Left border crossed
                else if (shape.x < 0) {
                    shape.x = 780;
                    cellNum--;
                }
                    //Top border crossed
                else if (shape.y < 1) {
                    shape.y = 580;
                    cellNum -= 3;
                }
                    //Bottom border crossed
                else if (shape.y > 581) {
                    shape.y = 581;
                }
                //Special events specific to cells will be handled here
                riverCollision(465, 430, 388, 200, 390, boat);
            }

            //CellC3
            if (cellNum == 8) {
                //Right border crossed
                if (shape.x > 781) {
                    shape.x = 781;
                }
                    //Left border crossed
                else if (shape.x < 0) {
                    shape.x = 780;
                    cellNum--;
                }
                    //Top border crossed
                else if (shape.y < 1) {
                    shape.y = 580;
                    cellNum -= 3;
                }
                    //Bottom border crossed
                else if (shape.y > 581) {
                    shape.y = 581;
                }
                //Special events specific to cells will be handled here
                
            }
        }
        else if (background.src != gridCellBackgrounds[cellNum].src) {
            //Exiting towns, dungeons, ect. will be handled here
            //(Left, Right, Top, Bottom)

            //CellA1
            if (cellNum == 0) {
                exitLocation(33, 159, 38, 145, 77, 85, 'images/VillageTownEct.png');
                exitLocation(88, 145, 485, 545, 110, 505, 'images/TemplePlaceHolder.png');

            }

                //CellA2
            else if (cellNum == 1) {
            }

                //CellA3
            else if (cellNum == 2) {
            }

                //CellB1
            else if (cellNum == 3) {
            }

                //CellB2
                /*else if (cellNum == 4) {
                    if (background.src.indexOf('images/VillageTownEct.png') != -1) {
    
                        //exiting villageTownEct.png
                        if (shape.x < 3) {
                            shape.previousX = 250;
                            shape.previousY = 475;
                        }
                        else if (shape.x > 797) {
                            shape.previousX = 392;
                            shape.previousY = 475;
                        }
                        else if (shape.y < 3) {
                            shape.previousY = 450;
                            shape.previousX = 300;
                        }
                        else if (shape.y > 597) {
                            shape.previousY = 510;
                            shape.previousX = 300;
                        }
                    }
                }*/



                //CellB3
            else if (cellNum == 5) {
            }

                //CellC1
            else if (cellNum == 6) {
            }

                //CellC2
            else if (cellNum == 7) {
            }

                //CellC3
            else if (cellNum == 8) {
            }



        }
        //################################
    }//end render canvas #####################################################
    //###################################

    //Handles entering locations. Can handle transistion to text adventure when the time comes.
    function enterLocation(left, right, top, bottom, location) {
        if (shape.x > left && shape.x < right && shape.y > top && shape.y < bottom) {

            //determine where the player entered from
            //left
            if (shape.previousX == left + 1) {
                //shape.x = 4;    // Will set textAdventure sector here once linked.
                //shape.y = 300;
                shape.x = left - 10;
            }
                //right
            else if (shape.previousX == right - 1) {
               // shape.x = 795;
                //shape.y = 300;
                shape.x = right + 10;
            }
                //top
            else if (shape.previousY == top + 1) {
               // shape.x = 400;
                //shape.y = 4;
                shape.y = top - 10;
            }
                //bottom
            else if (shape.previousY == bottom - 1) {
               // shape.x = 400;
                // shape.y = 595;
                shape.y = bottom + 10;
            }
            //background.src = location;

             startTextAdventure();
             checkFocus();
        }
    }//end enter location

    //Handles exiting non textAdventure or combat locations.
    function exitLocation(exitLeft, exitRight, exitTop, exitBottom, midX, midY, location) {
        if (background.src.indexOf(location) != -1) {

            //exiting villageTownEct.png
            if (shape.x < 3) {
                shape.previousX = exitLeft;
                shape.previousY = midY;
            }
            else if (shape.x > 797) {
                shape.previousX = exitRight;
                shape.previousY = midY;
            }
            else if (shape.y < 3) {
                shape.previousY = exitTop;
                shape.previousX = midX;
            }
            else if (shape.y > 597) {
                shape.previousY = exitBottom;
                shape.previousX = midX;
            }
        }
    }//end exit location

    //Provides collision for the river and checks if the player has a boat
    function riverCollision(left, left2, left3, verticalPos1, verticalPos2, boat) {
        if(shape.x > 250 && shape.x < 700){
         if (boat == false) {
                if (shape.x >= left && shape.y < verticalPos1) {
                    shape.x = left;
                }
                else if (shape.x >= left2 && shape.y > verticalPos1 && shape.y < verticalPos2) {
                    shape.x = left2;
                }
                else if (shape.x >= left3 && shape.y > verticalPos2) {
                    shape.x = left3;
                }          
            }
       }
            //Player has boat and can cross the river
        
    }

    // checking to see if the text adventure text box is selected
    function checkFocus() {
        if ($(document.activeElement).attr("type") == "text" || $(document.activeElement).attr("type") == "textarea") {
            return true;

        }

    }

    //Move when keys are pressed
    window.onkeydown = function (e) {
        if (checkFocus() != true && keyBoardOn == 0) {
            var kc = e.keyCode;
            e.preventDefault();

            if (kc === 37) Keys.left = true;
            else if (kc === 38) Keys.down = true;
            else if (kc === 39) Keys.right = true;
            else if (kc === 40) Keys.up = true;
        }
    };
    //Stop movement when key is released
    window.onkeyup = function (e) {
        if (checkFocus() != true) {
            var kc = e.keyCode;
            e.preventDefault();

            if (kc === 37) Keys.left = false;
            else if (kc === 38) Keys.down = false;
            else if (kc === 39) Keys.right = false;
            else if (kc === 40) Keys.up = false;
        }
    };

    //Generates a random enemy encounter
    function randomEncounter() {
        var randomNum = Math.random();
        if (Keys.left == true || Keys.right == true || Keys.up == true || Keys.down == true) {
            if (randomNum > .99899) {
                // background.src = 'images/RandomEncounter.png';
                startCombat();
            }
        }
    }

    //Draw the player shape on the canvas
    function renderShape() {
        ctx.clearRect(0, 0, c.width, c.height)
        renderCanvas();
        ctx.beginPath();
        getVariables();
        
       //drawing image
        ctx.drawImage(playerCharacter, shape.x, shape.y, shape.width, shape.height);
        ctx.fill();
        ctx.closePath();
    }

    

    //Game loop to ensure the game refreshes to create smooth gameplay and check for player movement
    function gameLoop() {
        if (Keys.up) {
            shape.y += 1;
        }
        else if (Keys.down) {
            shape.y -= 1;
        }

        else if (Keys.left) {
            shape.x -= 1;
        }
        else if (Keys.right) {
            shape.x += 1;
        }
        
        renderShape();
        
        console.log("ShapeX: " + hidShapeX + " ShapeY: " + hidShapeY + " Cell: " + hidCell
            + "previous: " + shape.previousX);
        passVariables(shape.x, shape.y, cellNum); //new
        setTimeout(gameLoop, 10);

    }
  
        gameLoop();
   



}
    