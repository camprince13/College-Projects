﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SiteMaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        btn_Logout.Enabled = false;
        btn_Logout.Visible = false;

        if (Session["LoggedIn"] == "True")
        {
            HeadLoginStatus.InnerHtml = "Welcome " + Session["Uname"].ToString();


            if (Convert.ToString(Session["AccLvl"]) == "1")
            {
                NavigationMenu.Items.Add(new MenuItem
                {
                    Text = "Administer",
                    NavigateUrl = "~/Admin.aspx"
                });
            }//end if admin


            btn_Logout.Enabled = true;
            btn_Logout.Visible = true;

        }//end if logged in

    }//End page load


    protected void btn_Logout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("Default.aspx");
    }
}//end page
