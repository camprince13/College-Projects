
To run the scripts:
1. Choose the 32 or 64 bit zip and unpack it
2. Open the python folder and run the getCMDhere.bat
3. Type: python 11MyScripts\scriptName.py
   and hit enter to run the script
	example to run the hello world script
	ex:> python 11MyScripts\000hello.py


The 11MyScripts contains my scripts and a data folder
	that some of the scripts read/write to.

The 099.py script was an early non-functional version of
	099Sudoku.py

The 099SudokuPeps.py script is a later version of 099Sudoku.py
	that follows most of the pep8 python coding standards