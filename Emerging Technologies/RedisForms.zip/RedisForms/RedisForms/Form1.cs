﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ServiceStack.Redis;
using ServiceStack.Text;//for the dump
using System.Diagnostics;
using System.Linq;

namespace RedisForms
{

    //set framework to 4.5
    //tools --> NuGet package manager --> package manager console
    //Install-Package ServiceStack.Server
    //Install-Package ServiceStack.Redis

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string connString = "mQENBFfFIX8BCAD1FBKMt5oUV1L55wU8JepkVGEmhyqSvSbjqP8rFrfygUCYzjvQ@24.250.30.8:6379";

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            int times = 100;

            //var redis = new RedisClient("24.250.30.8", 6379); //worked before password implemented
            //password@localhost:6379
            var redis = new RedisClient(connString);

            var redisPeople = redis.As<Person>();

            PersonMaker p = new PersonMaker();

            for(int i = 0; i < times; i++)
            {
                Person tmp = p.makePerson(redisPeople.GetNextSequence()); //new Person();
                redisPeople.Store(tmp);
            }

            MessageBox.Show("100 people generated.");

        }//end button

        private void btnGet_Click(object sender, EventArgs e)
        {

            //var redis = new RedisClient("24.250.30.8", 6379);
            var redis = new RedisClient(connString);
            var redisPeople = redis.As<Person>();

            var peopleAll = redisPeople.GetAll();

            List<Person> s = peopleAll as List<Person>;

            string f = "";
            for (int i = 0; i < s.Count; i++) {
                f += personToString(s[i]) + "\n";
            }

            MessageBox.Show(f);

        }//end button 2

        private string personToString(Person p) {
            return p.Id + ", " + p.FirstNm + ", " + p.LastNm + ", " + p.Email;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //var redis = new RedisClient("24.250.30.8", 6379);
            var redis = new RedisClient(connString);
            var redisPeople = redis.As<Person>();

            var peopleAll = redisPeople.GetAll();

            List<Person> s = peopleAll as List<Person>;

            List<Person> results = new List<Person>();

            if (radioButton1.Checked) 
            {
                int x;
                try
                {
                    x = Convert.ToInt32(txtSearch.Text);
                }
                catch { return; }

                for (int i = 0; i < s.Count; i++)
                {
                    if (s[i].Id == x) { results.Add(s[i]); }
                }//end for

            }//end if

            else if (radioButton2.Checked) 
            {
                for (int i = 0; i < s.Count; i++)
                {
                    if (s[i].FirstNm.Contains(txtSearch.Text)) { results.Add(s[i]); }
                }//end for
            }//end elseif

            else if (radioButton3.Checked) {
                for (int i = 0; i < s.Count; i++)
                {
                    if (s[i].LastNm.Contains(txtSearch.Text)) { results.Add(s[i]); }
                }//end for
            }//end elseif

            else if (radioButton4.Checked) {
                for (int i = 0; i < s.Count; i++)
                {
                    if (s[i].Email.Contains(txtSearch.Text)) { results.Add(s[i]); }
                }//end for
            }//end elseif

            string f = "";
            for (int i = 0; i < results.Count; i++)
            {
                f += personToString(results[i]) + "\n";
            }

            MessageBox.Show(f);

        }//end search

        private void btnFlush_Click(object sender, EventArgs e)
        {
            var redis = new RedisClient(connString);

            redis.FlushDb();

            MessageBox.Show("Contents of database flushed");

        }//end Flush

    }//end class

}//end namespace
