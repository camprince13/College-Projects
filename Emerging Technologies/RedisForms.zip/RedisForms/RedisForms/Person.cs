﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RedisForms
{
    public class Person
    {
        public Person() {}

        long id;

public long Id
{
  get { return id; }
  set { id = value; }
}
        string firstNm, lastNm, email;

public string Email
{
  get { return email; }
  set { email = value; }
}

public string LastNm
{
  get { return lastNm; }
  set { lastNm = value; }
}

public string FirstNm
{
  get { return firstNm; }
  set { firstNm = value; }
}

    }//end class

}//end namespace
