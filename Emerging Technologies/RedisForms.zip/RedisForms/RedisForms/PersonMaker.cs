﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RedisForms
{

    public class PersonMaker
    {

        string[] first = { "Jim", "Tom", "Frank", "Rick", "Jeff", "Randy", "Leonard", "Guy", "Samuel", "Craig", "Bob", "Edmond" };
        string[] last = { "Smith", "Castillo", "Bates", "Duncan", "Dean", "McDougal", "Webster", "Mann", "Cutter", "Hatterman", "Harrington" };

        string tmpFirst, tmpLast;

        public Person makePerson(long idx){
            Person tmp = new Person{Id = idx, FirstNm = genFirstName(), LastNm = genLastName(), Email = genEmail()};
            return tmp;
        }

        public string genFirstName() {
            tmpFirst = first[(genRandomNum(0, first.Length))];
            return tmpFirst;
        }

        public string genLastName()
        {
            tmpLast = last[(genRandomNum(0, last.Length))];
            return tmpLast;
        }

        public string genEmail() 
        {
            return tmpFirst + tmpLast + genRandomNum(0, 6000) + "@email.com";
        }

        private Random rnd = new Random();
        private static readonly object syncLock = new object();
        public int genRandomNum(int low, int max)
        {
            lock (syncLock)
            { // synchronize
                for (int i = 0; i < rnd.Next(30, 150); i++) { }

                int randy = rnd.Next(low, max);
                return randy;
            }
        }//end genRandomNum     This is more random


    }//end class

}//end namespace
